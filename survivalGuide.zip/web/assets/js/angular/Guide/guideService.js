guideModule.service('guideService', [ function () {

}]);