guideModule.service('guideRequest', ['$http', function ($http) {

}]);