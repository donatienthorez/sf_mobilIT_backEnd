notificationModule.service('notificationService', [ function () {

}]);