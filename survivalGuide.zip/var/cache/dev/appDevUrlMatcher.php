<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_login
                if ($pathinfo === '/login') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_security_login;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::loginAction',  '_route' => 'fos_user_security_login',);
                }
                not_fos_user_security_login:

                // fos_user_security_check
                if ($pathinfo === '/login_check') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_security_check;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::checkAction',  '_route' => 'fos_user_security_check',);
                }
                not_fos_user_security_check:

            }

            // fos_user_security_logout
            if ($pathinfo === '/logout') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_security_logout;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'fos_user_security_logout',);
            }
            not_fos_user_security_logout:

        }

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if (rtrim($pathinfo, '/') === '/profile') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ($pathinfo === '/profile/edit') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_fos_user_profile_edit;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  '_route' => 'fos_user_profile_edit',);
            }
            not_fos_user_profile_edit:

        }

        if (0 === strpos($pathinfo, '/re')) {
            if (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if (rtrim($pathinfo, '/') === '/register') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_registration_register;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'fos_user_registration_register');
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  '_route' => 'fos_user_registration_register',);
                }
                not_fos_user_registration_register:

                if (0 === strpos($pathinfo, '/register/c')) {
                    // fos_user_registration_check_email
                    if ($pathinfo === '/register/check-email') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_fos_user_registration_check_email;
                        }

                        return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                    }
                    not_fos_user_registration_check_email:

                    if (0 === strpos($pathinfo, '/register/confirm')) {
                        // fos_user_registration_confirm
                        if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirm;
                            }

                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',));
                        }
                        not_fos_user_registration_confirm:

                        // fos_user_registration_confirmed
                        if ($pathinfo === '/register/confirmed') {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirmed;
                            }

                            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                        }
                        not_fos_user_registration_confirmed:

                    }

                }

            }

            if (0 === strpos($pathinfo, '/resetting')) {
                // fos_user_resetting_request
                if ($pathinfo === '/resetting/request') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_request;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  '_route' => 'fos_user_resetting_request',);
                }
                not_fos_user_resetting_request:

                // fos_user_resetting_send_email
                if ($pathinfo === '/resetting/send-email') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_resetting_send_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                }
                not_fos_user_resetting_send_email:

                // fos_user_resetting_check_email
                if ($pathinfo === '/resetting/check-email') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_check_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                }
                not_fos_user_resetting_check_email:

                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_resetting_reset;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',));
                }
                not_fos_user_resetting_reset:

            }

        }

        // fos_user_change_password
        if ($pathinfo === '/profile/change-password') {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_fos_user_change_password;
            }

            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  '_route' => 'fos_user_change_password',);
        }
        not_fos_user_change_password:

        if (0 === strpos($pathinfo, '/admin')) {
            // esn_guide
            if (rtrim($pathinfo, '/') === '/admin/guide') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'esn_guide');
                }

                return array (  '_controller' => 'MainBundle\\Controller\\Front\\GuideController::indexAction',  '_route' => 'esn_guide',);
            }

            // esn_notifications
            if (rtrim($pathinfo, '/') === '/admin/notifications') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'esn_notifications');
                }

                return array (  '_controller' => 'MainBundle\\Controller\\Front\\NotificationController::indexAction',  '_route' => 'esn_notifications',);
            }

        }

        // esn_login_homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'esn_login_homepage');
            }

            return array (  '_controller' => 'MainBundle\\Controller\\Front\\SecurityController::indexAction',  '_route' => 'esn_login_homepage',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            // esn_login_check
            if ($pathinfo === '/login_check') {
                return array (  '_controller' => 'MainBundle\\Controller\\Front\\SecurityController::checkAction',  '_route' => 'esn_login_check',);
            }

            // esn_logout
            if ($pathinfo === '/logout') {
                return array (  '_controller' => 'MainBundle\\Controller\\Front\\SecurityController::logoutAction',  '_route' => 'esn_logout',);
            }

        }

        if (0 === strpos($pathinfo, '/api')) {
            if (0 === strpos($pathinfo, '/api/android')) {
                if (0 === strpos($pathinfo, '/api/android/sections')) {
                    // api_android_sections_get
                    if (rtrim($pathinfo, '/') === '/api/android/sections') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_api_android_sections_get;
                        }

                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'api_android_sections_get');
                        }

                        return array (  '_controller' => 'MainBundle\\Controller\\AndroidApi\\SectionController::getAction',  '_format' => 'json',  '_route' => 'api_android_sections_get',);
                    }
                    not_api_android_sections_get:

                    // api_android_sections_details
                    if ($pathinfo === '/api/android/sections/details') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_api_android_sections_details;
                        }

                        return array (  '_controller' => 'MainBundle\\Controller\\AndroidApi\\SectionController::detailsAction',  '_format' => 'json',  '_route' => 'api_android_sections_details',);
                    }
                    not_api_android_sections_details:

                }

                // api_android_countries_get
                if (rtrim($pathinfo, '/') === '/api/android/countries') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_android_countries_get;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'api_android_countries_get');
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\AndroidApi\\CountryController::getAction',  '_format' => 'json',  '_route' => 'api_android_countries_get',);
                }
                not_api_android_countries_get:

                // api_android_regids_create
                if ($pathinfo === '/api/android/regids/create') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_api_android_regids_create;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\AndroidApi\\RegIdController::createAction',  '_format' => 'json',  '_route' => 'api_android_regids_create',);
                }
                not_api_android_regids_create:

            }

            if (0 === strpos($pathinfo, '/api/countries')) {
                // api_countries_get
                if (rtrim($pathinfo, '/') === '/api/countries') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_countries_get;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'api_countries_get');
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\CountryController::getAction',  '_format' => 'json',  '_route' => 'api_countries_get',);
                }
                not_api_countries_get:

                // api_countries_details
                if ($pathinfo === '/api/countries/details') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_countries_details;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\CountryController::detailsAction',  '_format' => 'json',  '_route' => 'api_countries_details',);
                }
                not_api_countries_details:

            }

            if (0 === strpos($pathinfo, '/api/notifications')) {
                // api_notifications_list
                if ($pathinfo === '/api/notifications/list') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_notifications_list;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\NotificationController::listAction',  '_format' => 'json',  '_route' => 'api_notifications_list',);
                }
                not_api_notifications_list:

                // api_notifications_send
                if ($pathinfo === '/api/notifications/send') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_api_notifications_send;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\NotificationController::sendAction',  '_format' => 'json',  '_route' => 'api_notifications_send',);
                }
                not_api_notifications_send:

                // api_notifications_count
                if ($pathinfo === '/api/notifications/count') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_notifications_count;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\NotificationController::countAction',  '_format' => 'json',  '_route' => 'api_notifications_count',);
                }
                not_api_notifications_count:

            }

            if (0 === strpos($pathinfo, '/api/sections')) {
                // api_sections_get
                if (rtrim($pathinfo, '/') === '/api/sections') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_sections_get;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'api_sections_get');
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\SectionController::getAction',  '_format' => 'json',  '_route' => 'api_sections_get',);
                }
                not_api_sections_get:

                // api_sections_details
                if ($pathinfo === '/api/sections/details') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_sections_details;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\SectionController::detailsAction',  '_format' => 'json',  '_route' => 'api_sections_details',);
                }
                not_api_sections_details:

            }

            // api_regids_count
            if ($pathinfo === '/api/regids/count') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_api_regids_count;
                }

                return array (  '_controller' => 'MainBundle\\Controller\\Api\\RegIdController::countAction',  '_format' => 'json',  '_route' => 'api_regids_count',);
            }
            not_api_regids_count:

            if (0 === strpos($pathinfo, '/api/guides')) {
                // api_guides_get
                if (rtrim($pathinfo, '/') === '/api/guides') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_guides_get;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'api_guides_get');
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\GuideController::getAction',  '_format' => 'json',  '_route' => 'api_guides_get',);
                }
                not_api_guides_get:

                // api_guides_change_status
                if ($pathinfo === '/api/guides/statuses/change') {
                    if ($this->context->getMethod() != 'PUT') {
                        $allow[] = 'PUT';
                        goto not_api_guides_change_status;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\GuideController::changeStatusAction',  '_format' => 'json',  '_route' => 'api_guides_change_status',);
                }
                not_api_guides_change_status:

                // api_guides_count
                if ($pathinfo === '/api/guides/count') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_api_guides_count;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\GuideController::countAction',  '_format' => 'json',  '_route' => 'api_guides_count',);
                }
                not_api_guides_count:

            }

            if (0 === strpos($pathinfo, '/api/categories')) {
                // api_categories_add_child
                if (preg_match('#^/api/categories/(?P<category>\\d+)/addChild$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_api_categories_add_child;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_categories_add_child')), array (  '_controller' => 'MainBundle\\Controller\\Api\\CategoryController::addChildAction',  '_format' => 'json',));
                }
                not_api_categories_add_child:

                // api_categories_add
                if ($pathinfo === '/api/categories/add') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_api_categories_add;
                    }

                    return array (  '_controller' => 'MainBundle\\Controller\\Api\\CategoryController::addAction',  '_format' => 'json',  '_route' => 'api_categories_add',);
                }
                not_api_categories_add:

                // api_categories_edit_category
                if (preg_match('#^/api/categories/(?P<category>\\d+)/edit$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_api_categories_edit_category;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_categories_edit_category')), array (  '_controller' => 'MainBundle\\Controller\\Api\\CategoryController::editCategoryAction',  '_format' => 'json',));
                }
                not_api_categories_edit_category:

                // api_categories_move_category
                if (preg_match('#^/api/categories/(?P<category>\\d+)/move$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_api_categories_move_category;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_categories_move_category')), array (  '_controller' => 'MainBundle\\Controller\\Api\\CategoryController::moveCategoryAction',  '_format' => 'json',));
                }
                not_api_categories_move_category:

                // api_categories_remove
                if (preg_match('#^/api/categories/(?P<category>\\d+)/remove$#s', $pathinfo, $matches)) {
                    if ($this->context->getMethod() != 'DELETE') {
                        $allow[] = 'DELETE';
                        goto not_api_categories_remove;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'api_categories_remove')), array (  '_controller' => 'MainBundle\\Controller\\Api\\CategoryController::removeAction',  '_format' => 'json',));
                }
                not_api_categories_remove:

            }

        }

        // fos_js_routing_js
        if (0 === strpos($pathinfo, '/js/routing') && preg_match('#^/js/routing(?:\\.(?P<_format>js|json))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_js_routing_js')), array (  '_controller' => 'fos_js_routing.controller:indexAction',  '_format' => 'js',));
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
