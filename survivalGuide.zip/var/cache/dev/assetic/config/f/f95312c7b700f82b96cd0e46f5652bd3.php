<?php

// MainBundle:Notifications:index.html.twig
return array (
);
