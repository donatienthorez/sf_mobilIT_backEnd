<?php

// WebProfilerBundle:Collector:config.html.twig
return array (
);
