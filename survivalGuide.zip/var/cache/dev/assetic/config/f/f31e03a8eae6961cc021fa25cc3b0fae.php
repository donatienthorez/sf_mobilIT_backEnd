<?php

// WebProfilerBundle:Collector:memory.html.twig
return array (
);
