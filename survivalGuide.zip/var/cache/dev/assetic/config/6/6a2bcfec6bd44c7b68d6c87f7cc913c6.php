<?php

// FOSUserBundle:Registration:register_content.html.twig
return array (
);
