<?php

// FOSUserBundle:Registration:confirmed.html.twig
return array (
);
