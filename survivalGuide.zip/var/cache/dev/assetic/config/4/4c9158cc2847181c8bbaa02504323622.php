<?php

// WebProfilerBundle:Profiler:base_js.html.twig
return array (
);
