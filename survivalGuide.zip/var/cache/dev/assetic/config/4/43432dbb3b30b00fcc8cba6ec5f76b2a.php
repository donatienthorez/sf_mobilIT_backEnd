<?php

// WebProfilerBundle:Collector:logger.html.twig
return array (
);
