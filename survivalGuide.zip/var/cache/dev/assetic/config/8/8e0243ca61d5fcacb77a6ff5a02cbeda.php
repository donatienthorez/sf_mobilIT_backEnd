<?php

// MainBundle::homepage.html.twig
return array (
);
