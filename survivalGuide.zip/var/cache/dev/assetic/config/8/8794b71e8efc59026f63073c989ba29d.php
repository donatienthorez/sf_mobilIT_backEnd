<?php

// WebProfilerBundle:Collector:time.html.twig
return array (
);
