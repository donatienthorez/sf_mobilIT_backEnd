<?php

// FOSUserBundle:Resetting:checkEmail.html.twig
return array (
);
