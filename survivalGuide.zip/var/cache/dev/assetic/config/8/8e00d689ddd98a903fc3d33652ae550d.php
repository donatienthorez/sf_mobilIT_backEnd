<?php

// MainBundle:Guide:index.html.twig
return array (
);
