<?php

// FOSUserBundle:Group:show.html.twig
return array (
);
