<?php

// TwigBundle:Exception:exception.rdf.twig
return array (
);
