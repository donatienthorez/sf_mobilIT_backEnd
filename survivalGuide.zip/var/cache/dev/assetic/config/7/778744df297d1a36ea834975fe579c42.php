<?php

// FOSUserBundle:ChangePassword:changePassword.html.twig
return array (
);
