<?php

// FOSUserBundle:Group:edit_content.html.twig
return array (
);
