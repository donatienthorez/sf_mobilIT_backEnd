<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_375e4510f10f553f3219a5555bb03350dee4008cd900393be0e9ab37055ea9e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_95cc74781db5418bdebddbe636adb2817c64889e2be577b3817aa94ac8ea32a0 = $this->env->getExtension("native_profiler");
        $__internal_95cc74781db5418bdebddbe636adb2817c64889e2be577b3817aa94ac8ea32a0->enter($__internal_95cc74781db5418bdebddbe636adb2817c64889e2be577b3817aa94ac8ea32a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_95cc74781db5418bdebddbe636adb2817c64889e2be577b3817aa94ac8ea32a0->leave($__internal_95cc74781db5418bdebddbe636adb2817c64889e2be577b3817aa94ac8ea32a0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
