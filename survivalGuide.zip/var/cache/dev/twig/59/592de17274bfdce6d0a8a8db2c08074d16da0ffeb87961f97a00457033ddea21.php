<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_de150d6fdde96d4289c5ba9af8983b9921ea162db3ee5b5e0743ebc6ef88c855 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ed7139a0008ef05747096f3cc568a193ae0b5dfe2b37aa194274de094271abc = $this->env->getExtension("native_profiler");
        $__internal_3ed7139a0008ef05747096f3cc568a193ae0b5dfe2b37aa194274de094271abc->enter($__internal_3ed7139a0008ef05747096f3cc568a193ae0b5dfe2b37aa194274de094271abc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_3ed7139a0008ef05747096f3cc568a193ae0b5dfe2b37aa194274de094271abc->leave($__internal_3ed7139a0008ef05747096f3cc568a193ae0b5dfe2b37aa194274de094271abc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
