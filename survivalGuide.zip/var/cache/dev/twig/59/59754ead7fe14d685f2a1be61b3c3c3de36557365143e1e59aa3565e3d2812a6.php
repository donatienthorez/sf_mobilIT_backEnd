<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_bbb9b8611196efadd48623b80ced8b7ff5377052be44bbaf83473e8c5b39463b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c0138fa610bb31ca7c46fb2ca808b60efb483c33abb118e7500dc8ce4e253386 = $this->env->getExtension("native_profiler");
        $__internal_c0138fa610bb31ca7c46fb2ca808b60efb483c33abb118e7500dc8ce4e253386->enter($__internal_c0138fa610bb31ca7c46fb2ca808b60efb483c33abb118e7500dc8ce4e253386_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_c0138fa610bb31ca7c46fb2ca808b60efb483c33abb118e7500dc8ce4e253386->leave($__internal_c0138fa610bb31ca7c46fb2ca808b60efb483c33abb118e7500dc8ce4e253386_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
