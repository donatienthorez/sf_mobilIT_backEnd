<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_bbb9b8611196efadd48623b80ced8b7ff5377052be44bbaf83473e8c5b39463b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d287988ec2604bb6a8a41bb68d024fa92f129e305527314704f8c16be65da9b9 = $this->env->getExtension("native_profiler");
        $__internal_d287988ec2604bb6a8a41bb68d024fa92f129e305527314704f8c16be65da9b9->enter($__internal_d287988ec2604bb6a8a41bb68d024fa92f129e305527314704f8c16be65da9b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_d287988ec2604bb6a8a41bb68d024fa92f129e305527314704f8c16be65da9b9->leave($__internal_d287988ec2604bb6a8a41bb68d024fa92f129e305527314704f8c16be65da9b9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
