<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_54df1a4b970a049e626ccd8cfac96e8da28ad09e8c2d2f4ff9d3e1c7999054ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22801c8624bc566d4da2332600a0f814571c2f8754e8b5f0ee9db56b8ec30f5f = $this->env->getExtension("native_profiler");
        $__internal_22801c8624bc566d4da2332600a0f814571c2f8754e8b5f0ee9db56b8ec30f5f->enter($__internal_22801c8624bc566d4da2332600a0f814571c2f8754e8b5f0ee9db56b8ec30f5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_22801c8624bc566d4da2332600a0f814571c2f8754e8b5f0ee9db56b8ec30f5f->leave($__internal_22801c8624bc566d4da2332600a0f814571c2f8754e8b5f0ee9db56b8ec30f5f_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_3936ff70f3e6e550cb0fc6302bedce4386aab90c51ceea6c02bfbe38948cf1fe = $this->env->getExtension("native_profiler");
        $__internal_3936ff70f3e6e550cb0fc6302bedce4386aab90c51ceea6c02bfbe38948cf1fe->enter($__internal_3936ff70f3e6e550cb0fc6302bedce4386aab90c51ceea6c02bfbe38948cf1fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_3936ff70f3e6e550cb0fc6302bedce4386aab90c51ceea6c02bfbe38948cf1fe->leave($__internal_3936ff70f3e6e550cb0fc6302bedce4386aab90c51ceea6c02bfbe38948cf1fe_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:reset_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
