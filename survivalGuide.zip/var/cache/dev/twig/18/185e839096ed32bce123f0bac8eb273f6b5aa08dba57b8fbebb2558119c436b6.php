<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_54df1a4b970a049e626ccd8cfac96e8da28ad09e8c2d2f4ff9d3e1c7999054ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c929f155d97aa36e06b1e0417208e901f6772f6f0f23c22f977de6c73124f20a = $this->env->getExtension("native_profiler");
        $__internal_c929f155d97aa36e06b1e0417208e901f6772f6f0f23c22f977de6c73124f20a->enter($__internal_c929f155d97aa36e06b1e0417208e901f6772f6f0f23c22f977de6c73124f20a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c929f155d97aa36e06b1e0417208e901f6772f6f0f23c22f977de6c73124f20a->leave($__internal_c929f155d97aa36e06b1e0417208e901f6772f6f0f23c22f977de6c73124f20a_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_eea801001bfaaae3dc3a9b77ef870078593030b02bad4b85e7bf9db8e5dfbec3 = $this->env->getExtension("native_profiler");
        $__internal_eea801001bfaaae3dc3a9b77ef870078593030b02bad4b85e7bf9db8e5dfbec3->enter($__internal_eea801001bfaaae3dc3a9b77ef870078593030b02bad4b85e7bf9db8e5dfbec3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_eea801001bfaaae3dc3a9b77ef870078593030b02bad4b85e7bf9db8e5dfbec3->leave($__internal_eea801001bfaaae3dc3a9b77ef870078593030b02bad4b85e7bf9db8e5dfbec3_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:reset_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
