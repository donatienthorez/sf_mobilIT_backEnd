<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_94e5bbbb3476aae247ed20cc66b4b49ff32ad6fc7e6d76db8e25c1ce7f77b683 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "TwigBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_160b64d660dadab4ef8f3d7eb67f8c212a5493e7901f2815a9a7bc1fb2885a37 = $this->env->getExtension("native_profiler");
        $__internal_160b64d660dadab4ef8f3d7eb67f8c212a5493e7901f2815a9a7bc1fb2885a37->enter($__internal_160b64d660dadab4ef8f3d7eb67f8c212a5493e7901f2815a9a7bc1fb2885a37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_160b64d660dadab4ef8f3d7eb67f8c212a5493e7901f2815a9a7bc1fb2885a37->leave($__internal_160b64d660dadab4ef8f3d7eb67f8c212a5493e7901f2815a9a7bc1fb2885a37_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_182590118c055a1357c58f299bdb0f2987ccc358c5e7c12e86b1057972296af2 = $this->env->getExtension("native_profiler");
        $__internal_182590118c055a1357c58f299bdb0f2987ccc358c5e7c12e86b1057972296af2->enter($__internal_182590118c055a1357c58f299bdb0f2987ccc358c5e7c12e86b1057972296af2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_182590118c055a1357c58f299bdb0f2987ccc358c5e7c12e86b1057972296af2->leave($__internal_182590118c055a1357c58f299bdb0f2987ccc358c5e7c12e86b1057972296af2_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_3aec0f789cfb88e36d1a9534b40a7ce91b257c3954dad78b6c7d996a3b277468 = $this->env->getExtension("native_profiler");
        $__internal_3aec0f789cfb88e36d1a9534b40a7ce91b257c3954dad78b6c7d996a3b277468->enter($__internal_3aec0f789cfb88e36d1a9534b40a7ce91b257c3954dad78b6c7d996a3b277468_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_3aec0f789cfb88e36d1a9534b40a7ce91b257c3954dad78b6c7d996a3b277468->leave($__internal_3aec0f789cfb88e36d1a9534b40a7ce91b257c3954dad78b6c7d996a3b277468_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_4e86fdf2dc35f0997ae5cf6e3c84b8028385318afb9b315df89a1feb401cc5a5 = $this->env->getExtension("native_profiler");
        $__internal_4e86fdf2dc35f0997ae5cf6e3c84b8028385318afb9b315df89a1feb401cc5a5->enter($__internal_4e86fdf2dc35f0997ae5cf6e3c84b8028385318afb9b315df89a1feb401cc5a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "TwigBundle:Exception:exception_full.html.twig", 12)->display($context);
        
        $__internal_4e86fdf2dc35f0997ae5cf6e3c84b8028385318afb9b315df89a1feb401cc5a5->leave($__internal_4e86fdf2dc35f0997ae5cf6e3c84b8028385318afb9b315df89a1feb401cc5a5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block head %}*/
/*     <link href="{{ absolute_url(asset('bundles/framework/css/exception.css')) }}" rel="stylesheet" type="text/css" media="all" />*/
/* {% endblock %}*/
/* */
/* {% block title %}*/
/*     {{ exception.message }} ({{ status_code }} {{ status_text }})*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {% include '@Twig/Exception/exception.html.twig' %}*/
/* {% endblock %}*/
/* */
