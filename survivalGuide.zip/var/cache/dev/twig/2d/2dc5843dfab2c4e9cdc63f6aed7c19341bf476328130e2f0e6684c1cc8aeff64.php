<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_c0be483be8f9b7de68653f406272a95100865bbaa1749ddef35d3eb662c08619 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8daac31b3eed964d973cfd1d9fba0448968fca74227f629a7da1ef4fbdb3fe23 = $this->env->getExtension("native_profiler");
        $__internal_8daac31b3eed964d973cfd1d9fba0448968fca74227f629a7da1ef4fbdb3fe23->enter($__internal_8daac31b3eed964d973cfd1d9fba0448968fca74227f629a7da1ef4fbdb3fe23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_8daac31b3eed964d973cfd1d9fba0448968fca74227f629a7da1ef4fbdb3fe23->leave($__internal_8daac31b3eed964d973cfd1d9fba0448968fca74227f629a7da1ef4fbdb3fe23_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
