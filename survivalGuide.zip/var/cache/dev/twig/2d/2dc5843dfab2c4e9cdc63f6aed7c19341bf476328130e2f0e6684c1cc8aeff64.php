<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_c0be483be8f9b7de68653f406272a95100865bbaa1749ddef35d3eb662c08619 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2b12fcf87ede413f3f9db6640a68cfdeead096332e7f6113a68810bbe82382b5 = $this->env->getExtension("native_profiler");
        $__internal_2b12fcf87ede413f3f9db6640a68cfdeead096332e7f6113a68810bbe82382b5->enter($__internal_2b12fcf87ede413f3f9db6640a68cfdeead096332e7f6113a68810bbe82382b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_2b12fcf87ede413f3f9db6640a68cfdeead096332e7f6113a68810bbe82382b5->leave($__internal_2b12fcf87ede413f3f9db6640a68cfdeead096332e7f6113a68810bbe82382b5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
