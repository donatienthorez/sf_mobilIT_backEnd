<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_c0be483be8f9b7de68653f406272a95100865bbaa1749ddef35d3eb662c08619 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_838863fa3b93a9a6104b40974c48a8433ca21aceac93400eca329055b1a37d7d = $this->env->getExtension("native_profiler");
        $__internal_838863fa3b93a9a6104b40974c48a8433ca21aceac93400eca329055b1a37d7d->enter($__internal_838863fa3b93a9a6104b40974c48a8433ca21aceac93400eca329055b1a37d7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_838863fa3b93a9a6104b40974c48a8433ca21aceac93400eca329055b1a37d7d->leave($__internal_838863fa3b93a9a6104b40974c48a8433ca21aceac93400eca329055b1a37d7d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
