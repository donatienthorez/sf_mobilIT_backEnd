<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_f2547324f09635cfe47b93ad6f7cf18b249626a38cd498e5eba060f07fc2dd4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_69b04223f7edbb09aab8ed3ac8755c71e1eef4647f90a1e1c4ceeda23d7d2db1 = $this->env->getExtension("native_profiler");
        $__internal_69b04223f7edbb09aab8ed3ac8755c71e1eef4647f90a1e1c4ceeda23d7d2db1->enter($__internal_69b04223f7edbb09aab8ed3ac8755c71e1eef4647f90a1e1c4ceeda23d7d2db1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_69b04223f7edbb09aab8ed3ac8755c71e1eef4647f90a1e1c4ceeda23d7d2db1->leave($__internal_69b04223f7edbb09aab8ed3ac8755c71e1eef4647f90a1e1c4ceeda23d7d2db1_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_80336bfaa220bd0d04e5b0734006b40039a6de128e2903b76e2379c37080b71e = $this->env->getExtension("native_profiler");
        $__internal_80336bfaa220bd0d04e5b0734006b40039a6de128e2903b76e2379c37080b71e->enter($__internal_80336bfaa220bd0d04e5b0734006b40039a6de128e2903b76e2379c37080b71e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_80336bfaa220bd0d04e5b0734006b40039a6de128e2903b76e2379c37080b71e->leave($__internal_80336bfaa220bd0d04e5b0734006b40039a6de128e2903b76e2379c37080b71e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_c2e2b6a9539a7bf1f131608554831e8d06524be9150dd0b05536deec3684c0ea = $this->env->getExtension("native_profiler");
        $__internal_c2e2b6a9539a7bf1f131608554831e8d06524be9150dd0b05536deec3684c0ea->enter($__internal_c2e2b6a9539a7bf1f131608554831e8d06524be9150dd0b05536deec3684c0ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_c2e2b6a9539a7bf1f131608554831e8d06524be9150dd0b05536deec3684c0ea->leave($__internal_c2e2b6a9539a7bf1f131608554831e8d06524be9150dd0b05536deec3684c0ea_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
