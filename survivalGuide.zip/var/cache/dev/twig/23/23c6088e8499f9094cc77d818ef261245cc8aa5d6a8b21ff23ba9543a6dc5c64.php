<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_f2547324f09635cfe47b93ad6f7cf18b249626a38cd498e5eba060f07fc2dd4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b595b5b67db29c94a45ff09c003649d50287e5a32e3bc8e584ec740ca6e29b7a = $this->env->getExtension("native_profiler");
        $__internal_b595b5b67db29c94a45ff09c003649d50287e5a32e3bc8e584ec740ca6e29b7a->enter($__internal_b595b5b67db29c94a45ff09c003649d50287e5a32e3bc8e584ec740ca6e29b7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b595b5b67db29c94a45ff09c003649d50287e5a32e3bc8e584ec740ca6e29b7a->leave($__internal_b595b5b67db29c94a45ff09c003649d50287e5a32e3bc8e584ec740ca6e29b7a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_6acd2d153414606aa427a0d3e3ffc90aba71a3038e7c58358fc7c28c1e39af14 = $this->env->getExtension("native_profiler");
        $__internal_6acd2d153414606aa427a0d3e3ffc90aba71a3038e7c58358fc7c28c1e39af14->enter($__internal_6acd2d153414606aa427a0d3e3ffc90aba71a3038e7c58358fc7c28c1e39af14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_6acd2d153414606aa427a0d3e3ffc90aba71a3038e7c58358fc7c28c1e39af14->leave($__internal_6acd2d153414606aa427a0d3e3ffc90aba71a3038e7c58358fc7c28c1e39af14_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_ec7732f92925a0df8039562bf4fa820c4f7edb6e37d9e807241ffed5fc0ae7aa = $this->env->getExtension("native_profiler");
        $__internal_ec7732f92925a0df8039562bf4fa820c4f7edb6e37d9e807241ffed5fc0ae7aa->enter($__internal_ec7732f92925a0df8039562bf4fa820c4f7edb6e37d9e807241ffed5fc0ae7aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_ec7732f92925a0df8039562bf4fa820c4f7edb6e37d9e807241ffed5fc0ae7aa->leave($__internal_ec7732f92925a0df8039562bf4fa820c4f7edb6e37d9e807241ffed5fc0ae7aa_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
