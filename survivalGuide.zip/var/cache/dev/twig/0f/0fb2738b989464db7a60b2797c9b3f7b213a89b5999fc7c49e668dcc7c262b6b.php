<?php

/* MainBundle::navbar.html.twig */
class __TwigTemplate_5e30241ba02444f6944dc29dde51b409f11fdc67e75e58d78ed823a1e444f972 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a6540bb4c2fb0dd33e78cff65d8113ada0222129e114c7e97e1fc38c6a5cceb3 = $this->env->getExtension("native_profiler");
        $__internal_a6540bb4c2fb0dd33e78cff65d8113ada0222129e114c7e97e1fc38c6a5cceb3->enter($__internal_a6540bb4c2fb0dd33e78cff65d8113ada0222129e114c7e97e1fc38c6a5cceb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle::navbar.html.twig"));

        // line 1
        echo "<header></header>
<div class=\"navbar navbar-fixed-top\">
    <div class=\"navbar-inner\">
        <div class=\"container\">
            <a class=\"btn btn-navbar\" data-toggle=\"collapse\" data-target=\".nav-collapse\">
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </a>
            <a class=\"brand\" href=\"\">";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.name-site"), "html", null, true);
        echo "</a>
            ";
        // line 11
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 12
            echo "                <div class=\"nav-collapse\">
                    <ul class=\"nav pull-right\">
                        <li class=\"dropdown\">
                            <a href=\"\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">
                                <i class=\"icon-user\"></i>
                                ";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo "
                                <b class=\"caret\"></b>
                            </a>
                            <ul class=\"dropdown-menu\">
                                <li><a href=\"";
            // line 21
            echo $this->env->getExtension('routing')->getPath("esn_logout");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.logout"), "html", null, true);
            echo "</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            ";
        }
        // line 27
        echo "        </div>
    </div>
</div>";
        
        $__internal_a6540bb4c2fb0dd33e78cff65d8113ada0222129e114c7e97e1fc38c6a5cceb3->leave($__internal_a6540bb4c2fb0dd33e78cff65d8113ada0222129e114c7e97e1fc38c6a5cceb3_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle::navbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 27,  53 => 21,  46 => 17,  39 => 12,  37 => 11,  33 => 10,  22 => 1,);
    }
}
/* <header></header>*/
/* <div class="navbar navbar-fixed-top">*/
/*     <div class="navbar-inner">*/
/*         <div class="container">*/
/*             <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*             </a>*/
/*             <a class="brand" href="">{{ 'menu.name-site' | trans }}</a>*/
/*             {% if app.user %}*/
/*                 <div class="nav-collapse">*/
/*                     <ul class="nav pull-right">*/
/*                         <li class="dropdown">*/
/*                             <a href="" class="dropdown-toggle" data-toggle="dropdown">*/
/*                                 <i class="icon-user"></i>*/
/*                                 {{ app.user.username }}*/
/*                                 <b class="caret"></b>*/
/*                             </a>*/
/*                             <ul class="dropdown-menu">*/
/*                                 <li><a href="{{ path('esn_logout') }}">{{ 'menu.logout' | trans }}</a></li>*/
/*                             </ul>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </div>*/
/*             {% endif %}*/
/*         </div>*/
/*     </div>*/
/* </div>*/
