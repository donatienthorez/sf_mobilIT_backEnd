<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_d8bc8d0563e5f28b78d721d6ac8bf6d8d65e563dcf8e5c82aa02fbc80d732e3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_21dd9a4f1d2c89085522389ee0d5563b2805d972fcaea425abda4aec49b408fa = $this->env->getExtension("native_profiler");
        $__internal_21dd9a4f1d2c89085522389ee0d5563b2805d972fcaea425abda4aec49b408fa->enter($__internal_21dd9a4f1d2c89085522389ee0d5563b2805d972fcaea425abda4aec49b408fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_21dd9a4f1d2c89085522389ee0d5563b2805d972fcaea425abda4aec49b408fa->leave($__internal_21dd9a4f1d2c89085522389ee0d5563b2805d972fcaea425abda4aec49b408fa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
