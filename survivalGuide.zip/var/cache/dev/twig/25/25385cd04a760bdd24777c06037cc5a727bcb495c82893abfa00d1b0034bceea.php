<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_d8bc8d0563e5f28b78d721d6ac8bf6d8d65e563dcf8e5c82aa02fbc80d732e3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67040f5348d12e09abdecb0120ef7cbbceba80c0e56a7fb4743bd520db3b07c0 = $this->env->getExtension("native_profiler");
        $__internal_67040f5348d12e09abdecb0120ef7cbbceba80c0e56a7fb4743bd520db3b07c0->enter($__internal_67040f5348d12e09abdecb0120ef7cbbceba80c0e56a7fb4743bd520db3b07c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_67040f5348d12e09abdecb0120ef7cbbceba80c0e56a7fb4743bd520db3b07c0->leave($__internal_67040f5348d12e09abdecb0120ef7cbbceba80c0e56a7fb4743bd520db3b07c0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
