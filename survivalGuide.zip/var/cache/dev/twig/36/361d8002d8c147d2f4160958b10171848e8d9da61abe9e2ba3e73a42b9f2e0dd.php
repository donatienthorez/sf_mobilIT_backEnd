<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_31a106405d31be7ea6646c32e386be01bbebeed5a54023637d0b7c53978eeb50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14150a0308e1883f6c1d45f67f998bb63f585afda8fa8677d311d1d3b023c809 = $this->env->getExtension("native_profiler");
        $__internal_14150a0308e1883f6c1d45f67f998bb63f585afda8fa8677d311d1d3b023c809->enter($__internal_14150a0308e1883f6c1d45f67f998bb63f585afda8fa8677d311d1d3b023c809_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_14150a0308e1883f6c1d45f67f998bb63f585afda8fa8677d311d1d3b023c809->leave($__internal_14150a0308e1883f6c1d45f67f998bb63f585afda8fa8677d311d1d3b023c809_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_346ce624ce590439198aa048066896690271554b4e79ef7d577c1e58ac3d90f7 = $this->env->getExtension("native_profiler");
        $__internal_346ce624ce590439198aa048066896690271554b4e79ef7d577c1e58ac3d90f7->enter($__internal_346ce624ce590439198aa048066896690271554b4e79ef7d577c1e58ac3d90f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_346ce624ce590439198aa048066896690271554b4e79ef7d577c1e58ac3d90f7->leave($__internal_346ce624ce590439198aa048066896690271554b4e79ef7d577c1e58ac3d90f7_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
