<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_31a106405d31be7ea6646c32e386be01bbebeed5a54023637d0b7c53978eeb50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_104623fdcae9d24ca97776979925f57ce1be80149663e30cfdc895c76dbd930b = $this->env->getExtension("native_profiler");
        $__internal_104623fdcae9d24ca97776979925f57ce1be80149663e30cfdc895c76dbd930b->enter($__internal_104623fdcae9d24ca97776979925f57ce1be80149663e30cfdc895c76dbd930b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_104623fdcae9d24ca97776979925f57ce1be80149663e30cfdc895c76dbd930b->leave($__internal_104623fdcae9d24ca97776979925f57ce1be80149663e30cfdc895c76dbd930b_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c5d513ca36f087fd8c0e1428a8cd875dd47a47972982cda51989dcd03b534b0d = $this->env->getExtension("native_profiler");
        $__internal_c5d513ca36f087fd8c0e1428a8cd875dd47a47972982cda51989dcd03b534b0d->enter($__internal_c5d513ca36f087fd8c0e1428a8cd875dd47a47972982cda51989dcd03b534b0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_c5d513ca36f087fd8c0e1428a8cd875dd47a47972982cda51989dcd03b534b0d->leave($__internal_c5d513ca36f087fd8c0e1428a8cd875dd47a47972982cda51989dcd03b534b0d_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
