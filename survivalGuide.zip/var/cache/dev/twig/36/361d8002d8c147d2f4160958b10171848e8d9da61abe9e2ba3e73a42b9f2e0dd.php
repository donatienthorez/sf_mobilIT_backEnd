<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_31a106405d31be7ea6646c32e386be01bbebeed5a54023637d0b7c53978eeb50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de0fbb6f90555bc351e0e80d7951369f872694c2587bba8a22f265e64c4b3046 = $this->env->getExtension("native_profiler");
        $__internal_de0fbb6f90555bc351e0e80d7951369f872694c2587bba8a22f265e64c4b3046->enter($__internal_de0fbb6f90555bc351e0e80d7951369f872694c2587bba8a22f265e64c4b3046_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_de0fbb6f90555bc351e0e80d7951369f872694c2587bba8a22f265e64c4b3046->leave($__internal_de0fbb6f90555bc351e0e80d7951369f872694c2587bba8a22f265e64c4b3046_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_609fc771cb810b2bb6df4ded65d25144974e1ff80560bb4ccfb23467b757fa56 = $this->env->getExtension("native_profiler");
        $__internal_609fc771cb810b2bb6df4ded65d25144974e1ff80560bb4ccfb23467b757fa56->enter($__internal_609fc771cb810b2bb6df4ded65d25144974e1ff80560bb4ccfb23467b757fa56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_609fc771cb810b2bb6df4ded65d25144974e1ff80560bb4ccfb23467b757fa56->leave($__internal_609fc771cb810b2bb6df4ded65d25144974e1ff80560bb4ccfb23467b757fa56_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
