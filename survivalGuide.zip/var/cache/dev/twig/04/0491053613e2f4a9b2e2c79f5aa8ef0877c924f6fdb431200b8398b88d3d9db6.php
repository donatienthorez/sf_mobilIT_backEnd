<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_5b114813560b0112b9245ee331dcf56a420d330aad26ad353723907a9d5bc958 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2adb86c06b7f161d921fcbfae866ce8d70d8743a4ac3909611c3869339697b71 = $this->env->getExtension("native_profiler");
        $__internal_2adb86c06b7f161d921fcbfae866ce8d70d8743a4ac3909611c3869339697b71->enter($__internal_2adb86c06b7f161d921fcbfae866ce8d70d8743a4ac3909611c3869339697b71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_2adb86c06b7f161d921fcbfae866ce8d70d8743a4ac3909611c3869339697b71->leave($__internal_2adb86c06b7f161d921fcbfae866ce8d70d8743a4ac3909611c3869339697b71_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
