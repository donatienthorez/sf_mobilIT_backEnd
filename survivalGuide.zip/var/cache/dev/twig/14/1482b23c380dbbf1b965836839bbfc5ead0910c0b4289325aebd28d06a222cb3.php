<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_8e88ff60d3fa5faf7692c6630b2e0de99a7f3a1372e6074025075f42717da2d4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_871c8fd3d9592690af423cb57d79701710236ca370e2f50a3242ec602789fd1c = $this->env->getExtension("native_profiler");
        $__internal_871c8fd3d9592690af423cb57d79701710236ca370e2f50a3242ec602789fd1c->enter($__internal_871c8fd3d9592690af423cb57d79701710236ca370e2f50a3242ec602789fd1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_871c8fd3d9592690af423cb57d79701710236ca370e2f50a3242ec602789fd1c->leave($__internal_871c8fd3d9592690af423cb57d79701710236ca370e2f50a3242ec602789fd1c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
