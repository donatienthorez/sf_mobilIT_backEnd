<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_8e88ff60d3fa5faf7692c6630b2e0de99a7f3a1372e6074025075f42717da2d4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8dc27efd68329704e21b1da3a31639a3be7bbc0ca3894d448d380ad6dd3ad981 = $this->env->getExtension("native_profiler");
        $__internal_8dc27efd68329704e21b1da3a31639a3be7bbc0ca3894d448d380ad6dd3ad981->enter($__internal_8dc27efd68329704e21b1da3a31639a3be7bbc0ca3894d448d380ad6dd3ad981_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_8dc27efd68329704e21b1da3a31639a3be7bbc0ca3894d448d380ad6dd3ad981->leave($__internal_8dc27efd68329704e21b1da3a31639a3be7bbc0ca3894d448d380ad6dd3ad981_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
