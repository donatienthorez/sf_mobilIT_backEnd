<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_436b21e443986bdfe41cd4d3206e5513bf09dc84cf0d383afce960161fa31c23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b546b824632ec9e555499446bdba5c2c59f439ce841760d8f038cff86707fe20 = $this->env->getExtension("native_profiler");
        $__internal_b546b824632ec9e555499446bdba5c2c59f439ce841760d8f038cff86707fe20->enter($__internal_b546b824632ec9e555499446bdba5c2c59f439ce841760d8f038cff86707fe20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_b546b824632ec9e555499446bdba5c2c59f439ce841760d8f038cff86707fe20->leave($__internal_b546b824632ec9e555499446bdba5c2c59f439ce841760d8f038cff86707fe20_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
