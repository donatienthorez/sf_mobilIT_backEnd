<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_436b21e443986bdfe41cd4d3206e5513bf09dc84cf0d383afce960161fa31c23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a758ba229cc3a1fad6762854e56c45ce7273e622d3469660492c9931c243691c = $this->env->getExtension("native_profiler");
        $__internal_a758ba229cc3a1fad6762854e56c45ce7273e622d3469660492c9931c243691c->enter($__internal_a758ba229cc3a1fad6762854e56c45ce7273e622d3469660492c9931c243691c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_a758ba229cc3a1fad6762854e56c45ce7273e622d3469660492c9931c243691c->leave($__internal_a758ba229cc3a1fad6762854e56c45ce7273e622d3469660492c9931c243691c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
