<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_436b21e443986bdfe41cd4d3206e5513bf09dc84cf0d383afce960161fa31c23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2a9d4dd6407f2bc5bbf957d7c4e6c3bab4226ab66dd00d9fec316e75ad6d5bcf = $this->env->getExtension("native_profiler");
        $__internal_2a9d4dd6407f2bc5bbf957d7c4e6c3bab4226ab66dd00d9fec316e75ad6d5bcf->enter($__internal_2a9d4dd6407f2bc5bbf957d7c4e6c3bab4226ab66dd00d9fec316e75ad6d5bcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_2a9d4dd6407f2bc5bbf957d7c4e6c3bab4226ab66dd00d9fec316e75ad6d5bcf->leave($__internal_2a9d4dd6407f2bc5bbf957d7c4e6c3bab4226ab66dd00d9fec316e75ad6d5bcf_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
