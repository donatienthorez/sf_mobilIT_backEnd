<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_3e29788a52adc1d81e522dbce99e59671bde493ef7c34cbf02c76db53f63437f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_baba7cc42fbfbd84dccd8c960e5c2eb7efbb640d25d021002866d1ea944521cd = $this->env->getExtension("native_profiler");
        $__internal_baba7cc42fbfbd84dccd8c960e5c2eb7efbb640d25d021002866d1ea944521cd->enter($__internal_baba7cc42fbfbd84dccd8c960e5c2eb7efbb640d25d021002866d1ea944521cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_baba7cc42fbfbd84dccd8c960e5c2eb7efbb640d25d021002866d1ea944521cd->leave($__internal_baba7cc42fbfbd84dccd8c960e5c2eb7efbb640d25d021002866d1ea944521cd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
