<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_3e29788a52adc1d81e522dbce99e59671bde493ef7c34cbf02c76db53f63437f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19dbe493cb183b5ff8d8e90c36fdea0a73756fca52343f451fc74ee57e7ccacb = $this->env->getExtension("native_profiler");
        $__internal_19dbe493cb183b5ff8d8e90c36fdea0a73756fca52343f451fc74ee57e7ccacb->enter($__internal_19dbe493cb183b5ff8d8e90c36fdea0a73756fca52343f451fc74ee57e7ccacb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_19dbe493cb183b5ff8d8e90c36fdea0a73756fca52343f451fc74ee57e7ccacb->leave($__internal_19dbe493cb183b5ff8d8e90c36fdea0a73756fca52343f451fc74ee57e7ccacb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
