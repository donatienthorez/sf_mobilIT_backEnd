<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_3e29788a52adc1d81e522dbce99e59671bde493ef7c34cbf02c76db53f63437f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_41b6e487582859813cf97b8ced61a2d77d2d37ab0199f943c66a63651d2fbd97 = $this->env->getExtension("native_profiler");
        $__internal_41b6e487582859813cf97b8ced61a2d77d2d37ab0199f943c66a63651d2fbd97->enter($__internal_41b6e487582859813cf97b8ced61a2d77d2d37ab0199f943c66a63651d2fbd97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_41b6e487582859813cf97b8ced61a2d77d2d37ab0199f943c66a63651d2fbd97->leave($__internal_41b6e487582859813cf97b8ced61a2d77d2d37ab0199f943c66a63651d2fbd97_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
