<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_b4e9878c795ffcf130fa932b42a41d3f2e9b0cfed5ddd1f3bc5d6b0bfbc82a61 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b1529d5a5e47009f2cf4b0c03475b8b6be074f9183aa9f6310dd5e353790f74a = $this->env->getExtension("native_profiler");
        $__internal_b1529d5a5e47009f2cf4b0c03475b8b6be074f9183aa9f6310dd5e353790f74a->enter($__internal_b1529d5a5e47009f2cf4b0c03475b8b6be074f9183aa9f6310dd5e353790f74a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_b1529d5a5e47009f2cf4b0c03475b8b6be074f9183aa9f6310dd5e353790f74a->leave($__internal_b1529d5a5e47009f2cf4b0c03475b8b6be074f9183aa9f6310dd5e353790f74a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
