<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_c11c691882803829c16750aa4348d1353a66dbddcf16979f599dec1720a17b36 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_042d65d42372e0007773628a14350e06fdf6e680780c7d98d9501cded2444b90 = $this->env->getExtension("native_profiler");
        $__internal_042d65d42372e0007773628a14350e06fdf6e680780c7d98d9501cded2444b90->enter($__internal_042d65d42372e0007773628a14350e06fdf6e680780c7d98d9501cded2444b90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_042d65d42372e0007773628a14350e06fdf6e680780c7d98d9501cded2444b90->leave($__internal_042d65d42372e0007773628a14350e06fdf6e680780c7d98d9501cded2444b90_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b4c77a71482a0441ba3655027683662f42475ada9a9ceb65ffdb07760c7e6c87 = $this->env->getExtension("native_profiler");
        $__internal_b4c77a71482a0441ba3655027683662f42475ada9a9ceb65ffdb07760c7e6c87->enter($__internal_b4c77a71482a0441ba3655027683662f42475ada9a9ceb65ffdb07760c7e6c87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_b4c77a71482a0441ba3655027683662f42475ada9a9ceb65ffdb07760c7e6c87->leave($__internal_b4c77a71482a0441ba3655027683662f42475ada9a9ceb65ffdb07760c7e6c87_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
