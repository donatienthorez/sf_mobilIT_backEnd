<?php

/* MainBundle::homepage.html.twig */
class __TwigTemplate_a752e3d7f9f15518f4ee2a0a69a6cd5d21bd5ffb0111b0840e50969b90146d49 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MainBundle::base.html.twig", "MainBundle::homepage.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MainBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22b0e9e7012f4b282ded2d2b9e8317bf7a3381a86ff200e49e66c1fd99f28bd4 = $this->env->getExtension("native_profiler");
        $__internal_22b0e9e7012f4b282ded2d2b9e8317bf7a3381a86ff200e49e66c1fd99f28bd4->enter($__internal_22b0e9e7012f4b282ded2d2b9e8317bf7a3381a86ff200e49e66c1fd99f28bd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle::homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_22b0e9e7012f4b282ded2d2b9e8317bf7a3381a86ff200e49e66c1fd99f28bd4->leave($__internal_22b0e9e7012f4b282ded2d2b9e8317bf7a3381a86ff200e49e66c1fd99f28bd4_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_63f85393414c5f405283be8c243bfc62141b72dccb7680508472a37be3f9fb3f = $this->env->getExtension("native_profiler");
        $__internal_63f85393414c5f405283be8c243bfc62141b72dccb7680508472a37be3f9fb3f->enter($__internal_63f85393414c5f405283be8c243bfc62141b72dccb7680508472a37be3f9fb3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"account-container\"  style=\"width:700px;\">
        <div class=\"content clearfix\">
            <h1 style=\"text-align:center;\">";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.first.welcome-1"), "html", null, true);
        echo "</h1><br/>
            <h3 style=\"text-align:center\">";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.first.welcome-2"), "html", null, true);
        echo "</h3><br/>
            <h3 style=\"text-align:center\">";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.first.connect.text"), "html", null, true);
        echo "</h3><br/>
            <center>
                <a href=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("esn_login_check");
        echo "\">
                    <button class=\"button btn btn-success btn-medium btn-galaxy\">";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.first.connect.button"), "html", null, true);
        echo "</button>
                </a>
            </center>
        </div>
    </div>

    <div class=\"account-container\" style=\"width:700px;\">
        <div class=\"content clearfix\">
            <h3 style=\"text-align:center\">";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.second.functionnalities"), "html", null, true);
        echo "</h3><br/>

            <div id=\"big_stats\" class=\"cf\">
                <div class=\"stat\"> <i class=\"icon-book\"></i> <span class=\"value\"><span id=\"layout_guides\">3</span> ";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.second.guide"), "html", null, true);
        echo "</span></div>
                <!-- .stat -->

                <div class=\"stat\"> <i class=\"icon-user\"></i> <span class=\"value\"><span id=\"layout_users\">25</span> ";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.second.users"), "html", null, true);
        echo "</span> </div>
                <!-- .stat -->

                <div class=\"stat\"> <i class=\"icon-exclamation-sign\"></i> <span class=\"value\"><span id=\"layout_notifications\">74</span> ";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.second.notifications"), "html", null, true);
        echo "</span> </div>
                <!-- .stat -->
                <!-- /widget-content -->
            </div>
            <br>
            <h3 style=\"text-align:center\"> ";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("homepage.second.comments"), "html", null, true);
        echo " <a href=\"mailto:";
        echo twig_escape_filter($this->env, (isset($context["webmastermail"]) ? $context["webmastermail"] : $this->getContext($context, "webmastermail")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["webmastermail"]) ? $context["webmastermail"] : $this->getContext($context, "webmastermail")), "html", null, true);
        echo "</a></h3>
        </div>
    </div>
";
        
        $__internal_63f85393414c5f405283be8c243bfc62141b72dccb7680508472a37be3f9fb3f->leave($__internal_63f85393414c5f405283be8c243bfc62141b72dccb7680508472a37be3f9fb3f_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle::homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 32,  90 => 27,  84 => 24,  78 => 21,  72 => 18,  61 => 10,  57 => 9,  52 => 7,  48 => 6,  44 => 5,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'MainBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <div class="account-container"  style="width:700px;">*/
/*         <div class="content clearfix">*/
/*             <h1 style="text-align:center;">{{ 'homepage.first.welcome-1' | trans}}</h1><br/>*/
/*             <h3 style="text-align:center">{{ 'homepage.first.welcome-2' | trans}}</h3><br/>*/
/*             <h3 style="text-align:center">{{ 'homepage.first.connect.text' | trans}}</h3><br/>*/
/*             <center>*/
/*                 <a href="{{ path('esn_login_check') }}">*/
/*                     <button class="button btn btn-success btn-medium btn-galaxy">{{ 'homepage.first.connect.button' | trans}}</button>*/
/*                 </a>*/
/*             </center>*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="account-container" style="width:700px;">*/
/*         <div class="content clearfix">*/
/*             <h3 style="text-align:center">{{ 'homepage.second.functionnalities' | trans}}</h3><br/>*/
/* */
/*             <div id="big_stats" class="cf">*/
/*                 <div class="stat"> <i class="icon-book"></i> <span class="value"><span id="layout_guides">3</span> {{ 'homepage.second.guide' | trans}}</span></div>*/
/*                 <!-- .stat -->*/
/* */
/*                 <div class="stat"> <i class="icon-user"></i> <span class="value"><span id="layout_users">25</span> {{ 'homepage.second.users' | trans}}</span> </div>*/
/*                 <!-- .stat -->*/
/* */
/*                 <div class="stat"> <i class="icon-exclamation-sign"></i> <span class="value"><span id="layout_notifications">74</span> {{ 'homepage.second.notifications' | trans}}</span> </div>*/
/*                 <!-- .stat -->*/
/*                 <!-- /widget-content -->*/
/*             </div>*/
/*             <br>*/
/*             <h3 style="text-align:center"> {{ 'homepage.second.comments' | trans}} <a href="mailto:{{ webmastermail }}">{{ webmastermail }}</a></h3>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
