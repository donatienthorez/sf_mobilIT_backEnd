<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_daef63319114aef81eaffa5b28aea63f5659b34bd339bafbec41d93bb4d834b0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ea14499df61a19ef4585e60bfff11999f7aa2a712c8edd3f356ff7a584325419 = $this->env->getExtension("native_profiler");
        $__internal_ea14499df61a19ef4585e60bfff11999f7aa2a712c8edd3f356ff7a584325419->enter($__internal_ea14499df61a19ef4585e60bfff11999f7aa2a712c8edd3f356ff7a584325419_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_ea14499df61a19ef4585e60bfff11999f7aa2a712c8edd3f356ff7a584325419->leave($__internal_ea14499df61a19ef4585e60bfff11999f7aa2a712c8edd3f356ff7a584325419_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
