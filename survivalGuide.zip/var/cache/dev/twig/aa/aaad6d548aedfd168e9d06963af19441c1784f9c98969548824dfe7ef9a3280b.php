<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_daef63319114aef81eaffa5b28aea63f5659b34bd339bafbec41d93bb4d834b0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1156c83a663eb3677a0add9a30fdfc593cc57950608c14d6a8ccffabb2b709d7 = $this->env->getExtension("native_profiler");
        $__internal_1156c83a663eb3677a0add9a30fdfc593cc57950608c14d6a8ccffabb2b709d7->enter($__internal_1156c83a663eb3677a0add9a30fdfc593cc57950608c14d6a8ccffabb2b709d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_1156c83a663eb3677a0add9a30fdfc593cc57950608c14d6a8ccffabb2b709d7->leave($__internal_1156c83a663eb3677a0add9a30fdfc593cc57950608c14d6a8ccffabb2b709d7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
