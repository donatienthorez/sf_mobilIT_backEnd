<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_daef63319114aef81eaffa5b28aea63f5659b34bd339bafbec41d93bb4d834b0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dffe657c23c36983bed0935cf326082fb1be47d30529a3559f26851c3e8a27ee = $this->env->getExtension("native_profiler");
        $__internal_dffe657c23c36983bed0935cf326082fb1be47d30529a3559f26851c3e8a27ee->enter($__internal_dffe657c23c36983bed0935cf326082fb1be47d30529a3559f26851c3e8a27ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_dffe657c23c36983bed0935cf326082fb1be47d30529a3559f26851c3e8a27ee->leave($__internal_dffe657c23c36983bed0935cf326082fb1be47d30529a3559f26851c3e8a27ee_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
