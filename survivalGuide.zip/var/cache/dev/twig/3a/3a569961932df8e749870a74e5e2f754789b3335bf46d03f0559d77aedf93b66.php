<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_b53c7b01779bcfc9b8e355a70444f1e84883dc7a0e2a183b0071468f29858f8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_55efbb8d1886f63489fdde98f32c55311b40b3d20f63acc69fb67d791777084c = $this->env->getExtension("native_profiler");
        $__internal_55efbb8d1886f63489fdde98f32c55311b40b3d20f63acc69fb67d791777084c->enter($__internal_55efbb8d1886f63489fdde98f32c55311b40b3d20f63acc69fb67d791777084c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_55efbb8d1886f63489fdde98f32c55311b40b3d20f63acc69fb67d791777084c->leave($__internal_55efbb8d1886f63489fdde98f32c55311b40b3d20f63acc69fb67d791777084c_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_46c8be7d13a7fab4410b1844d663a8502f6483822cd18805e57d62dfad23fb9a = $this->env->getExtension("native_profiler");
        $__internal_46c8be7d13a7fab4410b1844d663a8502f6483822cd18805e57d62dfad23fb9a->enter($__internal_46c8be7d13a7fab4410b1844d663a8502f6483822cd18805e57d62dfad23fb9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_46c8be7d13a7fab4410b1844d663a8502f6483822cd18805e57d62dfad23fb9a->leave($__internal_46c8be7d13a7fab4410b1844d663a8502f6483822cd18805e57d62dfad23fb9a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
