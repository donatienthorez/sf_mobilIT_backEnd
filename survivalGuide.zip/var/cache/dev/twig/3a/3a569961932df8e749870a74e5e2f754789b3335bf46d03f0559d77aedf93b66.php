<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_b53c7b01779bcfc9b8e355a70444f1e84883dc7a0e2a183b0071468f29858f8f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_33df212da16191ae8a7c6e517bd4a7a47f7978d645c973cfce27ad0a9f0d7b05 = $this->env->getExtension("native_profiler");
        $__internal_33df212da16191ae8a7c6e517bd4a7a47f7978d645c973cfce27ad0a9f0d7b05->enter($__internal_33df212da16191ae8a7c6e517bd4a7a47f7978d645c973cfce27ad0a9f0d7b05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_33df212da16191ae8a7c6e517bd4a7a47f7978d645c973cfce27ad0a9f0d7b05->leave($__internal_33df212da16191ae8a7c6e517bd4a7a47f7978d645c973cfce27ad0a9f0d7b05_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_437c58b2ca55c8fe8758e466f74ade2a6de2bed79bc1a71f5be1ae74c2150150 = $this->env->getExtension("native_profiler");
        $__internal_437c58b2ca55c8fe8758e466f74ade2a6de2bed79bc1a71f5be1ae74c2150150->enter($__internal_437c58b2ca55c8fe8758e466f74ade2a6de2bed79bc1a71f5be1ae74c2150150_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_437c58b2ca55c8fe8758e466f74ade2a6de2bed79bc1a71f5be1ae74c2150150->leave($__internal_437c58b2ca55c8fe8758e466f74ade2a6de2bed79bc1a71f5be1ae74c2150150_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
