<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_73d7b82cca68d64999d7c455581d2a253b843851a7538956f4db5e628b4a92da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9702037a953833c709fd6522b23f24b933e9913f02eaa1cadd11f3b83be2c470 = $this->env->getExtension("native_profiler");
        $__internal_9702037a953833c709fd6522b23f24b933e9913f02eaa1cadd11f3b83be2c470->enter($__internal_9702037a953833c709fd6522b23f24b933e9913f02eaa1cadd11f3b83be2c470_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9702037a953833c709fd6522b23f24b933e9913f02eaa1cadd11f3b83be2c470->leave($__internal_9702037a953833c709fd6522b23f24b933e9913f02eaa1cadd11f3b83be2c470_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_9d50f01fc0d9d06697ba81db6ee0fe3bad890d524bea515b35996f9738edd81c = $this->env->getExtension("native_profiler");
        $__internal_9d50f01fc0d9d06697ba81db6ee0fe3bad890d524bea515b35996f9738edd81c->enter($__internal_9d50f01fc0d9d06697ba81db6ee0fe3bad890d524bea515b35996f9738edd81c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_9d50f01fc0d9d06697ba81db6ee0fe3bad890d524bea515b35996f9738edd81c->leave($__internal_9d50f01fc0d9d06697ba81db6ee0fe3bad890d524bea515b35996f9738edd81c_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
