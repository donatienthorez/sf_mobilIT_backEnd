<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_73d7b82cca68d64999d7c455581d2a253b843851a7538956f4db5e628b4a92da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b001a9814ebedb845948cafbfcac28afb8ed0c37ee01d60ea242b14643f7951 = $this->env->getExtension("native_profiler");
        $__internal_1b001a9814ebedb845948cafbfcac28afb8ed0c37ee01d60ea242b14643f7951->enter($__internal_1b001a9814ebedb845948cafbfcac28afb8ed0c37ee01d60ea242b14643f7951_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1b001a9814ebedb845948cafbfcac28afb8ed0c37ee01d60ea242b14643f7951->leave($__internal_1b001a9814ebedb845948cafbfcac28afb8ed0c37ee01d60ea242b14643f7951_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_80a6be880a74ce5a07e0ac12de0ca1a38f09a220f97ff20c1b6ad9f66906d4c2 = $this->env->getExtension("native_profiler");
        $__internal_80a6be880a74ce5a07e0ac12de0ca1a38f09a220f97ff20c1b6ad9f66906d4c2->enter($__internal_80a6be880a74ce5a07e0ac12de0ca1a38f09a220f97ff20c1b6ad9f66906d4c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_80a6be880a74ce5a07e0ac12de0ca1a38f09a220f97ff20c1b6ad9f66906d4c2->leave($__internal_80a6be880a74ce5a07e0ac12de0ca1a38f09a220f97ff20c1b6ad9f66906d4c2_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
