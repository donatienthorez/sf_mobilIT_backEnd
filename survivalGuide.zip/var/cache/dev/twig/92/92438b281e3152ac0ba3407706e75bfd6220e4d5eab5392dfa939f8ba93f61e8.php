<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_73d7b82cca68d64999d7c455581d2a253b843851a7538956f4db5e628b4a92da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b572fe6ba13dccffbe9e0deb292f04af1c5f0f7661769d81d4e99960400f25a9 = $this->env->getExtension("native_profiler");
        $__internal_b572fe6ba13dccffbe9e0deb292f04af1c5f0f7661769d81d4e99960400f25a9->enter($__internal_b572fe6ba13dccffbe9e0deb292f04af1c5f0f7661769d81d4e99960400f25a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b572fe6ba13dccffbe9e0deb292f04af1c5f0f7661769d81d4e99960400f25a9->leave($__internal_b572fe6ba13dccffbe9e0deb292f04af1c5f0f7661769d81d4e99960400f25a9_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_98e85036e3365493b8c36029bf594cdb7ae66b083f6d98845a367c73b0218d8a = $this->env->getExtension("native_profiler");
        $__internal_98e85036e3365493b8c36029bf594cdb7ae66b083f6d98845a367c73b0218d8a->enter($__internal_98e85036e3365493b8c36029bf594cdb7ae66b083f6d98845a367c73b0218d8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_98e85036e3365493b8c36029bf594cdb7ae66b083f6d98845a367c73b0218d8a->leave($__internal_98e85036e3365493b8c36029bf594cdb7ae66b083f6d98845a367c73b0218d8a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
