<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_fd5e63096fa431f7c5d839c8a9b9a27dc171cef9f789c294e3855d1c0c9e9f69 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38c8eaed75b4fe8490ac19aa915238acb5f249c3e3131e445c3bdabf90401b59 = $this->env->getExtension("native_profiler");
        $__internal_38c8eaed75b4fe8490ac19aa915238acb5f249c3e3131e445c3bdabf90401b59->enter($__internal_38c8eaed75b4fe8490ac19aa915238acb5f249c3e3131e445c3bdabf90401b59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_38c8eaed75b4fe8490ac19aa915238acb5f249c3e3131e445c3bdabf90401b59->leave($__internal_38c8eaed75b4fe8490ac19aa915238acb5f249c3e3131e445c3bdabf90401b59_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
