<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_fd5e63096fa431f7c5d839c8a9b9a27dc171cef9f789c294e3855d1c0c9e9f69 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df54faec9847a1d693d51ccf15c90a2b28ac3d7a8cce40d82bbd94601a75c3cb = $this->env->getExtension("native_profiler");
        $__internal_df54faec9847a1d693d51ccf15c90a2b28ac3d7a8cce40d82bbd94601a75c3cb->enter($__internal_df54faec9847a1d693d51ccf15c90a2b28ac3d7a8cce40d82bbd94601a75c3cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_df54faec9847a1d693d51ccf15c90a2b28ac3d7a8cce40d82bbd94601a75c3cb->leave($__internal_df54faec9847a1d693d51ccf15c90a2b28ac3d7a8cce40d82bbd94601a75c3cb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
