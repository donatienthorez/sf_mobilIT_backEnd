<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_fd5e63096fa431f7c5d839c8a9b9a27dc171cef9f789c294e3855d1c0c9e9f69 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90379f1ab01ac6ca2a7d08a611a5f02375496982948e162ba0032188c7b53191 = $this->env->getExtension("native_profiler");
        $__internal_90379f1ab01ac6ca2a7d08a611a5f02375496982948e162ba0032188c7b53191->enter($__internal_90379f1ab01ac6ca2a7d08a611a5f02375496982948e162ba0032188c7b53191_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_90379f1ab01ac6ca2a7d08a611a5f02375496982948e162ba0032188c7b53191->leave($__internal_90379f1ab01ac6ca2a7d08a611a5f02375496982948e162ba0032188c7b53191_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
