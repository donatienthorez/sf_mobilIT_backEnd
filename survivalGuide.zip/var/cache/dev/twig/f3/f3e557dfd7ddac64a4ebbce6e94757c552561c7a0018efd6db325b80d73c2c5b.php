<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_0b08cdffe3a4c641e8f39418d7e83f1aa67889a8e94d95b44798ce9db71a864e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9587a0779c25559b89d7bbbfc03da2ddfbc6bf9c4e44714f135c5a7cdf10fe8e = $this->env->getExtension("native_profiler");
        $__internal_9587a0779c25559b89d7bbbfc03da2ddfbc6bf9c4e44714f135c5a7cdf10fe8e->enter($__internal_9587a0779c25559b89d7bbbfc03da2ddfbc6bf9c4e44714f135c5a7cdf10fe8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_9587a0779c25559b89d7bbbfc03da2ddfbc6bf9c4e44714f135c5a7cdf10fe8e->leave($__internal_9587a0779c25559b89d7bbbfc03da2ddfbc6bf9c4e44714f135c5a7cdf10fe8e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
