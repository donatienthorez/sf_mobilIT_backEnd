<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_0b08cdffe3a4c641e8f39418d7e83f1aa67889a8e94d95b44798ce9db71a864e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d624f79e6bc3873d230158ac98ac11b4bf5aafffd5f1e36e3343e799b5339343 = $this->env->getExtension("native_profiler");
        $__internal_d624f79e6bc3873d230158ac98ac11b4bf5aafffd5f1e36e3343e799b5339343->enter($__internal_d624f79e6bc3873d230158ac98ac11b4bf5aafffd5f1e36e3343e799b5339343_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_d624f79e6bc3873d230158ac98ac11b4bf5aafffd5f1e36e3343e799b5339343->leave($__internal_d624f79e6bc3873d230158ac98ac11b4bf5aafffd5f1e36e3343e799b5339343_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
