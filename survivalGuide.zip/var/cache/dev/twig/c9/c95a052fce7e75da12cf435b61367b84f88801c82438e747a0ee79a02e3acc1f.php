<?php

/* MainBundle::header.html.twig */
class __TwigTemplate_8e951398272ded9282d30b500dccb8a168c998c0f0e2b18d9dfd43178612b28b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'css' => array($this, 'block_css'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6826a117c3ba45960716ba7bba5f3e708d5820637fac121460e88b76828aa5d8 = $this->env->getExtension("native_profiler");
        $__internal_6826a117c3ba45960716ba7bba5f3e708d5820637fac121460e88b76828aa5d8->enter($__internal_6826a117c3ba45960716ba7bba5f3e708d5820637fac121460e88b76828aa5d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle::header.html.twig"));

        // line 1
        echo "<head>
    <title>ESN - Survival Guide</title>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">
    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">

    ";
        // line 8
        $this->displayBlock('javascripts', $context, $blocks);
        // line 29
        echo "
    ";
        // line 30
        $this->displayBlock('css', $context, $blocks);
        // line 45
        echo "</head>
";
        
        $__internal_6826a117c3ba45960716ba7bba5f3e708d5820637fac121460e88b76828aa5d8->leave($__internal_6826a117c3ba45960716ba7bba5f3e708d5820637fac121460e88b76828aa5d8_prof);

    }

    // line 8
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_45d683a6008a478f362f175303d82e10b2450528c9e0f3102db25363d733b747 = $this->env->getExtension("native_profiler");
        $__internal_45d683a6008a478f362f175303d82e10b2450528c9e0f3102db25363d733b747->enter($__internal_45d683a6008a478f362f175303d82e10b2450528c9e0f3102db25363d733b747_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 9
        echo "        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js\"></script>
        <script src=\"http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js\"></script>
        <script src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/fosjsrouting/js/router.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/app.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Notification/notificationController.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Notification/notificationService.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Notification/notificationRequest.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Guide/guideController.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Guide/guideService.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Guide/guideRequest.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Homepage/homepageController.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Homepage/homepageRequest.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/chosen/chosen.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/angular-chosen-localytics/chosen.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/angular-ui-tree/dist/angular-ui-tree.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/ckeditor/ckeditor.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/ng-ckeditor/ng-ckeditor.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 27
        echo $this->env->getExtension('routing')->getPath("fos_js_routing_js", array("callback" => "fos.Router.setData"));
        echo "\"></script>
    ";
        
        $__internal_45d683a6008a478f362f175303d82e10b2450528c9e0f3102db25363d733b747->leave($__internal_45d683a6008a478f362f175303d82e10b2450528c9e0f3102db25363d733b747_prof);

    }

    // line 30
    public function block_css($context, array $blocks = array())
    {
        $__internal_aa8b214d261d45ff0f939591591af00d52694049378571c6ca9d43169220454a = $this->env->getExtension("native_profiler");
        $__internal_aa8b214d261d45ff0f939591591af00d52694049378571c6ca9d43169220454a->enter($__internal_aa8b214d261d45ff0f939591591af00d52694049378571c6ca9d43169220454a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "css"));

        // line 31
        echo "        <link rel=\"shortcut icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo.ico"), "html", null, true);
        echo "\" type=\"image/vnd.microsoft.icon\" />
        <link href=\"http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600\" rel=\"stylesheet\">
        <link href=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/bootstrap-responsive.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/font-awesome.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/pages/dashboard.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/pages/signin.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/chosen/chosen.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/angular-chosen-localytics/chosen-spinner.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/custom.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link rel=\"stylesheet\" href=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/angular-ui-tree/dist/angular-ui-tree.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    ";
        
        $__internal_aa8b214d261d45ff0f939591591af00d52694049378571c6ca9d43169220454a->leave($__internal_aa8b214d261d45ff0f939591591af00d52694049378571c6ca9d43169220454a_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle::header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  179 => 42,  175 => 41,  171 => 40,  167 => 39,  163 => 38,  159 => 37,  155 => 36,  151 => 35,  147 => 34,  143 => 33,  137 => 31,  131 => 30,  122 => 27,  118 => 26,  114 => 25,  110 => 24,  106 => 23,  102 => 22,  98 => 21,  94 => 20,  90 => 19,  86 => 18,  82 => 17,  78 => 16,  74 => 15,  70 => 14,  66 => 13,  62 => 12,  58 => 11,  54 => 9,  48 => 8,  40 => 45,  38 => 30,  35 => 29,  33 => 8,  24 => 1,);
    }
}
/* <head>*/
/*     <title>ESN - Survival Guide</title>*/
/* */
/*     <meta charset="utf-8">*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">*/
/*     <meta name="apple-mobile-web-app-capable" content="yes">*/
/* */
/*     {% block javascripts %}*/
/*         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>*/
/*         <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>*/
/*         <script src="{{ asset('bundles/fosjsrouting/js/router.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular.min.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/app.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Notification/notificationController.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Notification/notificationService.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Notification/notificationRequest.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Guide/guideController.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Guide/guideService.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Guide/guideRequest.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Homepage/homepageController.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Homepage/homepageRequest.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/chosen/chosen.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/angular-chosen-localytics/chosen.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/angular-ui-tree/dist/angular-ui-tree.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/ckeditor/ckeditor.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/ng-ckeditor/ng-ckeditor.js') }}"></script>*/
/*         <script src="{{ path('fos_js_routing_js', {'callback': 'fos.Router.setData'}) }}"></script>*/
/*     {% endblock %}*/
/* */
/*     {% block css %}*/
/*         <link rel="shortcut icon" href="{{ asset('assets/images/logo.ico') }}" type="image/vnd.microsoft.icon" />*/
/*         <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/bootstrap-responsive.min.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/font-awesome.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/pages/dashboard.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/pages/signin.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/vendor/chosen/chosen.min.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/vendor/angular-chosen-localytics/chosen-spinner.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet">*/
/*         <link rel="stylesheet" href="{{ asset('assets/vendor/angular-ui-tree/dist/angular-ui-tree.min.css') }}" rel="stylesheet">*/
/* */
/*     {% endblock %}*/
/* </head>*/
/* */
