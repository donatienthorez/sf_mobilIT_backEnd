<?php

/* MainBundle::header.html.twig */
class __TwigTemplate_8e951398272ded9282d30b500dccb8a168c998c0f0e2b18d9dfd43178612b28b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'javascripts' => array($this, 'block_javascripts'),
            'css' => array($this, 'block_css'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06cea3258f5b40850b519fa774098cd8aefff929b87c0ec52d5ae91362ce3864 = $this->env->getExtension("native_profiler");
        $__internal_06cea3258f5b40850b519fa774098cd8aefff929b87c0ec52d5ae91362ce3864->enter($__internal_06cea3258f5b40850b519fa774098cd8aefff929b87c0ec52d5ae91362ce3864_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle::header.html.twig"));

        // line 1
        echo "<head>
    <title>ESN - Survival Guide</title>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">
    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">

    ";
        // line 8
        $this->displayBlock('javascripts', $context, $blocks);
        // line 32
        echo "
    ";
        // line 33
        $this->displayBlock('css', $context, $blocks);
        // line 47
        echo "</head>
";
        
        $__internal_06cea3258f5b40850b519fa774098cd8aefff929b87c0ec52d5ae91362ce3864->leave($__internal_06cea3258f5b40850b519fa774098cd8aefff929b87c0ec52d5ae91362ce3864_prof);

    }

    // line 8
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4193bd34ce9ad1e090c2949028c7ae1e81bd061ef39b60b48dd7e0828fc493aa = $this->env->getExtension("native_profiler");
        $__internal_4193bd34ce9ad1e090c2949028c7ae1e81bd061ef39b60b48dd7e0828fc493aa->enter($__internal_4193bd34ce9ad1e090c2949028c7ae1e81bd061ef39b60b48dd7e0828fc493aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 9
        echo "        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js\"></script>
        <script src=\"http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js\"></script>
        <script src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/fosjsrouting/js/router.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/app.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("fos_js_routing_js", array("callback" => "fos.Router.setData"));
        echo "\"></script>
        ";
        // line 16
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Notification/notificationController.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Notification/notificationService.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Notification/notificationRequest.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/angular-chosen-localytics/chosen.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/chosen/chosen.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 22
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Guide/guideController.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Guide/guideService.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Guide/guideRequest.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/ckeditor/ckeditor.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/ng-ckeditor/ng-ckeditor.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/angular-ui-tree/dist/angular-ui-tree.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 29
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Homepage/homepageController.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/js/angular/Homepage/homepageRequest.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_4193bd34ce9ad1e090c2949028c7ae1e81bd061ef39b60b48dd7e0828fc493aa->leave($__internal_4193bd34ce9ad1e090c2949028c7ae1e81bd061ef39b60b48dd7e0828fc493aa_prof);

    }

    // line 33
    public function block_css($context, array $blocks = array())
    {
        $__internal_406815578c391d60539beaee61df84dcdc65a161d3dc8f370dae27df45f74c21 = $this->env->getExtension("native_profiler");
        $__internal_406815578c391d60539beaee61df84dcdc65a161d3dc8f370dae27df45f74c21->enter($__internal_406815578c391d60539beaee61df84dcdc65a161d3dc8f370dae27df45f74c21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "css"));

        // line 34
        echo "        <link rel=\"shortcut icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/logo.ico"), "html", null, true);
        echo "\" type=\"image/vnd.microsoft.icon\" />
        <link href=\"http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600\" rel=\"stylesheet\">
        <link href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/bootstrap-responsive.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/font-awesome.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/pages/dashboard.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/pages/signin.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/chosen/chosen.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/angular-chosen-localytics/chosen-spinner.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/css/custom.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link rel=\"stylesheet\" href=\"";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/angular-ui-tree/dist/angular-ui-tree.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    ";
        
        $__internal_406815578c391d60539beaee61df84dcdc65a161d3dc8f370dae27df45f74c21->leave($__internal_406815578c391d60539beaee61df84dcdc65a161d3dc8f370dae27df45f74c21_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle::header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  182 => 45,  178 => 44,  174 => 43,  170 => 42,  166 => 41,  162 => 40,  158 => 39,  154 => 38,  150 => 37,  146 => 36,  140 => 34,  134 => 33,  125 => 30,  120 => 29,  116 => 27,  112 => 26,  108 => 25,  104 => 24,  100 => 23,  95 => 22,  91 => 20,  87 => 19,  83 => 18,  79 => 17,  74 => 16,  70 => 14,  66 => 13,  62 => 12,  58 => 11,  54 => 9,  48 => 8,  40 => 47,  38 => 33,  35 => 32,  33 => 8,  24 => 1,);
    }
}
/* <head>*/
/*     <title>ESN - Survival Guide</title>*/
/* */
/*     <meta charset="utf-8">*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">*/
/*     <meta name="apple-mobile-web-app-capable" content="yes">*/
/* */
/*     {% block javascripts %}*/
/*         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>*/
/*         <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>*/
/*         <script src="{{ asset('bundles/fosjsrouting/js/router.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular.min.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/app.js') }}"></script>*/
/*         <script src="{{ path('fos_js_routing_js', {'callback': 'fos.Router.setData'}) }}"></script>*/
/*         {# notifications #}*/
/*         <script src="{{ asset('assets/js/angular/Notification/notificationController.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Notification/notificationService.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Notification/notificationRequest.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/angular-chosen-localytics/chosen.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/chosen/chosen.js') }}"></script>*/
/*         {# guide #}*/
/*         <script src="{{ asset('assets/js/angular/Guide/guideController.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Guide/guideService.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Guide/guideRequest.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/ckeditor/ckeditor.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/ng-ckeditor/ng-ckeditor.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/angular-ui-tree/dist/angular-ui-tree.js') }}"></script>*/
/*         {# homepage #}*/
/*         <script src="{{ asset('assets/js/angular/Homepage/homepageController.js') }}"></script>*/
/*         <script src="{{ asset('assets/js/angular/Homepage/homepageRequest.js') }}"></script>*/
/*     {% endblock %}*/
/* */
/*     {% block css %}*/
/*         <link rel="shortcut icon" href="{{ asset('assets/images/logo.ico') }}" type="image/vnd.microsoft.icon" />*/
/*         <link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/bootstrap-responsive.min.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/font-awesome.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/pages/dashboard.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/pages/signin.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/vendor/chosen/chosen.min.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/vendor/angular-chosen-localytics/chosen-spinner.css') }}" rel="stylesheet">*/
/*         <link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet">*/
/*         <link rel="stylesheet" href="{{ asset('assets/vendor/angular-ui-tree/dist/angular-ui-tree.min.css') }}" rel="stylesheet">*/
/*     {% endblock %}*/
/* </head>*/
/* */
