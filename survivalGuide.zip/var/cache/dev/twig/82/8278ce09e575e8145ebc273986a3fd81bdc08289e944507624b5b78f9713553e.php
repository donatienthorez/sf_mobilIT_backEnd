<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_0cebc5e4baab8023901b27f697d37a216f1061e51213e652981600e182916bbd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_181046b948339a6172fa98c971b4d99c29dd49b0a30af290fb2713ca04e78932 = $this->env->getExtension("native_profiler");
        $__internal_181046b948339a6172fa98c971b4d99c29dd49b0a30af290fb2713ca04e78932->enter($__internal_181046b948339a6172fa98c971b4d99c29dd49b0a30af290fb2713ca04e78932_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_181046b948339a6172fa98c971b4d99c29dd49b0a30af290fb2713ca04e78932->leave($__internal_181046b948339a6172fa98c971b4d99c29dd49b0a30af290fb2713ca04e78932_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */
