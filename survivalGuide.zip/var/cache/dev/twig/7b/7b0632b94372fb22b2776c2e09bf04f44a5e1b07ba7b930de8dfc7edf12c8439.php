<?php

/* FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig */
class __TwigTemplate_8ddff223eceee0196c6ca6a26f0aa8a09d15b9bf2017d2252c78bdcc777ac149 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b7b2e0abe83e95dc9fa260eeb4fb2b4febb2a140cc2cfb133d691588c663fbcf = $this->env->getExtension("native_profiler");
        $__internal_b7b2e0abe83e95dc9fa260eeb4fb2b4febb2a140cc2cfb133d691588c663fbcf->enter($__internal_b7b2e0abe83e95dc9fa260eeb4fb2b4febb2a140cc2cfb133d691588c663fbcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b7b2e0abe83e95dc9fa260eeb4fb2b4febb2a140cc2cfb133d691588c663fbcf->leave($__internal_b7b2e0abe83e95dc9fa260eeb4fb2b4febb2a140cc2cfb133d691588c663fbcf_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_444474457ef83e9e20e8da69bd2962a4510063e21e25036a008bd8cb16c29df2 = $this->env->getExtension("native_profiler");
        $__internal_444474457ef83e9e20e8da69bd2962a4510063e21e25036a008bd8cb16c29df2->enter($__internal_444474457ef83e9e20e8da69bd2962a4510063e21e25036a008bd8cb16c29df2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_444474457ef83e9e20e8da69bd2962a4510063e21e25036a008bd8cb16c29df2->leave($__internal_444474457ef83e9e20e8da69bd2962a4510063e21e25036a008bd8cb16c29df2_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
