<?php

/* FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig */
class __TwigTemplate_8ddff223eceee0196c6ca6a26f0aa8a09d15b9bf2017d2252c78bdcc777ac149 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aedc378f8a29f5a48922de8a4009c431edd9c72a79a279e4418a294766c0802b = $this->env->getExtension("native_profiler");
        $__internal_aedc378f8a29f5a48922de8a4009c431edd9c72a79a279e4418a294766c0802b->enter($__internal_aedc378f8a29f5a48922de8a4009c431edd9c72a79a279e4418a294766c0802b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aedc378f8a29f5a48922de8a4009c431edd9c72a79a279e4418a294766c0802b->leave($__internal_aedc378f8a29f5a48922de8a4009c431edd9c72a79a279e4418a294766c0802b_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_cbe8e27f871a4a1cbde7da39a6b80de9f14c4d8134599b7575ba4f30fa39ebf1 = $this->env->getExtension("native_profiler");
        $__internal_cbe8e27f871a4a1cbde7da39a6b80de9f14c4d8134599b7575ba4f30fa39ebf1->enter($__internal_cbe8e27f871a4a1cbde7da39a6b80de9f14c4d8134599b7575ba4f30fa39ebf1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_cbe8e27f871a4a1cbde7da39a6b80de9f14c4d8134599b7575ba4f30fa39ebf1->leave($__internal_cbe8e27f871a4a1cbde7da39a6b80de9f14c4d8134599b7575ba4f30fa39ebf1_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
