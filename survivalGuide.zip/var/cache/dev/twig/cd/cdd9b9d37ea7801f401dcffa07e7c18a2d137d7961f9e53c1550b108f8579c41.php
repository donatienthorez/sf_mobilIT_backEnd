<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_ba338afc04f82f66702ffb31d687f48b6d00c3d8739fc40d2f3cb00408f7d1b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_74c70ca68763671506b9b4469b9202a2c757bfcf49988b0a0bf82203ea6984f0 = $this->env->getExtension("native_profiler");
        $__internal_74c70ca68763671506b9b4469b9202a2c757bfcf49988b0a0bf82203ea6984f0->enter($__internal_74c70ca68763671506b9b4469b9202a2c757bfcf49988b0a0bf82203ea6984f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_74c70ca68763671506b9b4469b9202a2c757bfcf49988b0a0bf82203ea6984f0->leave($__internal_74c70ca68763671506b9b4469b9202a2c757bfcf49988b0a0bf82203ea6984f0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */
