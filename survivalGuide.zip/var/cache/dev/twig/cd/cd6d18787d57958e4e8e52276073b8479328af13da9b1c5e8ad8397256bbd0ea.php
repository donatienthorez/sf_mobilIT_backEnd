<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_8cc0cd27296b94d92afefeab55f28d522f2b281dc883dcd3b1e91a12db1e6d1b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1967d3c7a6e67828fb668c293d20e99fe180d3a1e070bc7ad6a848f43bf3c0fa = $this->env->getExtension("native_profiler");
        $__internal_1967d3c7a6e67828fb668c293d20e99fe180d3a1e070bc7ad6a848f43bf3c0fa->enter($__internal_1967d3c7a6e67828fb668c293d20e99fe180d3a1e070bc7ad6a848f43bf3c0fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1967d3c7a6e67828fb668c293d20e99fe180d3a1e070bc7ad6a848f43bf3c0fa->leave($__internal_1967d3c7a6e67828fb668c293d20e99fe180d3a1e070bc7ad6a848f43bf3c0fa_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_31a38d85c92e0def78bee626949bcd693131d00f1d253ec2f64db272a2a26684 = $this->env->getExtension("native_profiler");
        $__internal_31a38d85c92e0def78bee626949bcd693131d00f1d253ec2f64db272a2a26684->enter($__internal_31a38d85c92e0def78bee626949bcd693131d00f1d253ec2f64db272a2a26684_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_31a38d85c92e0def78bee626949bcd693131d00f1d253ec2f64db272a2a26684->leave($__internal_31a38d85c92e0def78bee626949bcd693131d00f1d253ec2f64db272a2a26684_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b4c3a44fd3ecc9b4e657aa360e88e95b7ec693012c222fe7b1e0a2beecebb36c = $this->env->getExtension("native_profiler");
        $__internal_b4c3a44fd3ecc9b4e657aa360e88e95b7ec693012c222fe7b1e0a2beecebb36c->enter($__internal_b4c3a44fd3ecc9b4e657aa360e88e95b7ec693012c222fe7b1e0a2beecebb36c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_b4c3a44fd3ecc9b4e657aa360e88e95b7ec693012c222fe7b1e0a2beecebb36c->leave($__internal_b4c3a44fd3ecc9b4e657aa360e88e95b7ec693012c222fe7b1e0a2beecebb36c_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_b91eb9290c3c4cc6f49aebf7445005c26ccb8d7727e204fbe25a75af0cf23ee2 = $this->env->getExtension("native_profiler");
        $__internal_b91eb9290c3c4cc6f49aebf7445005c26ccb8d7727e204fbe25a75af0cf23ee2->enter($__internal_b91eb9290c3c4cc6f49aebf7445005c26ccb8d7727e204fbe25a75af0cf23ee2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_b91eb9290c3c4cc6f49aebf7445005c26ccb8d7727e204fbe25a75af0cf23ee2->leave($__internal_b91eb9290c3c4cc6f49aebf7445005c26ccb8d7727e204fbe25a75af0cf23ee2_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
