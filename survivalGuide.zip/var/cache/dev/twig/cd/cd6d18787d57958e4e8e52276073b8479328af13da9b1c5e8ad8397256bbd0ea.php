<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_8cc0cd27296b94d92afefeab55f28d522f2b281dc883dcd3b1e91a12db1e6d1b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_28cbd4f7d261363bae6d48a27ec2eb3671cde4dbd575838423a40bbb40a182e4 = $this->env->getExtension("native_profiler");
        $__internal_28cbd4f7d261363bae6d48a27ec2eb3671cde4dbd575838423a40bbb40a182e4->enter($__internal_28cbd4f7d261363bae6d48a27ec2eb3671cde4dbd575838423a40bbb40a182e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_28cbd4f7d261363bae6d48a27ec2eb3671cde4dbd575838423a40bbb40a182e4->leave($__internal_28cbd4f7d261363bae6d48a27ec2eb3671cde4dbd575838423a40bbb40a182e4_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_249c3bc6a026216130fb51f2a9ff166088c116e63fe79c5cb1b0b27ac3da1f5b = $this->env->getExtension("native_profiler");
        $__internal_249c3bc6a026216130fb51f2a9ff166088c116e63fe79c5cb1b0b27ac3da1f5b->enter($__internal_249c3bc6a026216130fb51f2a9ff166088c116e63fe79c5cb1b0b27ac3da1f5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_249c3bc6a026216130fb51f2a9ff166088c116e63fe79c5cb1b0b27ac3da1f5b->leave($__internal_249c3bc6a026216130fb51f2a9ff166088c116e63fe79c5cb1b0b27ac3da1f5b_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_4f43a51b39fca1816590f439ae63fcff4740667244ac2b0a31e8c0b3569879f9 = $this->env->getExtension("native_profiler");
        $__internal_4f43a51b39fca1816590f439ae63fcff4740667244ac2b0a31e8c0b3569879f9->enter($__internal_4f43a51b39fca1816590f439ae63fcff4740667244ac2b0a31e8c0b3569879f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_4f43a51b39fca1816590f439ae63fcff4740667244ac2b0a31e8c0b3569879f9->leave($__internal_4f43a51b39fca1816590f439ae63fcff4740667244ac2b0a31e8c0b3569879f9_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_288f55f209e2113d81bd1404de475f18bd63f3c506d6ffda46ace8cecdd6ecee = $this->env->getExtension("native_profiler");
        $__internal_288f55f209e2113d81bd1404de475f18bd63f3c506d6ffda46ace8cecdd6ecee->enter($__internal_288f55f209e2113d81bd1404de475f18bd63f3c506d6ffda46ace8cecdd6ecee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_288f55f209e2113d81bd1404de475f18bd63f3c506d6ffda46ace8cecdd6ecee->leave($__internal_288f55f209e2113d81bd1404de475f18bd63f3c506d6ffda46ace8cecdd6ecee_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
