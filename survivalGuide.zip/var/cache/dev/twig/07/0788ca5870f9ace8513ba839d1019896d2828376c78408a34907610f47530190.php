<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_7b2432b204384118bdef1bc3217fa5d8ca93b0585086361085e27e721e354371 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a23b7ece8026a62ade02af49ef7d782838d28bca66842fd7bf3b883b90d1880c = $this->env->getExtension("native_profiler");
        $__internal_a23b7ece8026a62ade02af49ef7d782838d28bca66842fd7bf3b883b90d1880c->enter($__internal_a23b7ece8026a62ade02af49ef7d782838d28bca66842fd7bf3b883b90d1880c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_a23b7ece8026a62ade02af49ef7d782838d28bca66842fd7bf3b883b90d1880c->leave($__internal_a23b7ece8026a62ade02af49ef7d782838d28bca66842fd7bf3b883b90d1880c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
