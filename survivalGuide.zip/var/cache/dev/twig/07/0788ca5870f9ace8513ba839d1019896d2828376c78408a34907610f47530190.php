<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_7b2432b204384118bdef1bc3217fa5d8ca93b0585086361085e27e721e354371 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b5878a9fc98bab7085d991d2365e734e3c2cf71942e80b0d5da1e1b04c68c69 = $this->env->getExtension("native_profiler");
        $__internal_0b5878a9fc98bab7085d991d2365e734e3c2cf71942e80b0d5da1e1b04c68c69->enter($__internal_0b5878a9fc98bab7085d991d2365e734e3c2cf71942e80b0d5da1e1b04c68c69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_0b5878a9fc98bab7085d991d2365e734e3c2cf71942e80b0d5da1e1b04c68c69->leave($__internal_0b5878a9fc98bab7085d991d2365e734e3c2cf71942e80b0d5da1e1b04c68c69_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
