<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_03a7a1aff6688e03ac1e410a925f69fd19764f35aa5b8156c164ef4078283abe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e10ed901ea5037679c5bea11da06f977124e6fe361434552567d757b5afb582 = $this->env->getExtension("native_profiler");
        $__internal_2e10ed901ea5037679c5bea11da06f977124e6fe361434552567d757b5afb582->enter($__internal_2e10ed901ea5037679c5bea11da06f977124e6fe361434552567d757b5afb582_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_2e10ed901ea5037679c5bea11da06f977124e6fe361434552567d757b5afb582->leave($__internal_2e10ed901ea5037679c5bea11da06f977124e6fe361434552567d757b5afb582_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
