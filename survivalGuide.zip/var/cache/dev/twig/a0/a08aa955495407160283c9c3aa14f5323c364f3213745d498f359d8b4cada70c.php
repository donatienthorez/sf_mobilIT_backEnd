<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_03a7a1aff6688e03ac1e410a925f69fd19764f35aa5b8156c164ef4078283abe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_344e88c8eca42cb8696e5a85cd6bfe65758f13cdb4c3b6d50fa7676ddcc61fd2 = $this->env->getExtension("native_profiler");
        $__internal_344e88c8eca42cb8696e5a85cd6bfe65758f13cdb4c3b6d50fa7676ddcc61fd2->enter($__internal_344e88c8eca42cb8696e5a85cd6bfe65758f13cdb4c3b6d50fa7676ddcc61fd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_344e88c8eca42cb8696e5a85cd6bfe65758f13cdb4c3b6d50fa7676ddcc61fd2->leave($__internal_344e88c8eca42cb8696e5a85cd6bfe65758f13cdb4c3b6d50fa7676ddcc61fd2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
