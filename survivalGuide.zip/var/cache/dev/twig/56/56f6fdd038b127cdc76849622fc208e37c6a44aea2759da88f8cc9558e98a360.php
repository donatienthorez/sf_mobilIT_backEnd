<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_8c507e6b2f6ea42ea46bf4a33c797ac2a7bac45e4da64972cfd1826e087961de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46b4a00f7ba7c74c4cc7d38334daaaac3a492386edf73189ec1332cad6353eb0 = $this->env->getExtension("native_profiler");
        $__internal_46b4a00f7ba7c74c4cc7d38334daaaac3a492386edf73189ec1332cad6353eb0->enter($__internal_46b4a00f7ba7c74c4cc7d38334daaaac3a492386edf73189ec1332cad6353eb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_46b4a00f7ba7c74c4cc7d38334daaaac3a492386edf73189ec1332cad6353eb0->leave($__internal_46b4a00f7ba7c74c4cc7d38334daaaac3a492386edf73189ec1332cad6353eb0_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_cf31e98fee6cbe98fd35934bee45bf8fd57238098968ed83362bd9248ef7a1b1 = $this->env->getExtension("native_profiler");
        $__internal_cf31e98fee6cbe98fd35934bee45bf8fd57238098968ed83362bd9248ef7a1b1->enter($__internal_cf31e98fee6cbe98fd35934bee45bf8fd57238098968ed83362bd9248ef7a1b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        echo "
";
        
        $__internal_cf31e98fee6cbe98fd35934bee45bf8fd57238098968ed83362bd9248ef7a1b1->leave($__internal_cf31e98fee6cbe98fd35934bee45bf8fd57238098968ed83362bd9248ef7a1b1_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_471cb1dcd78ae6e297e5e4b88851d171c2ca167616a375a6440207eca9b8890e = $this->env->getExtension("native_profiler");
        $__internal_471cb1dcd78ae6e297e5e4b88851d171c2ca167616a375a6440207eca9b8890e->enter($__internal_471cb1dcd78ae6e297e5e4b88851d171c2ca167616a375a6440207eca9b8890e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_471cb1dcd78ae6e297e5e4b88851d171c2ca167616a375a6440207eca9b8890e->leave($__internal_471cb1dcd78ae6e297e5e4b88851d171c2ca167616a375a6440207eca9b8890e_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_7baa0037315c7c48bc8368871fecb160f7699eab4037c7fcaa9cd00491485be1 = $this->env->getExtension("native_profiler");
        $__internal_7baa0037315c7c48bc8368871fecb160f7699eab4037c7fcaa9cd00491485be1->enter($__internal_7baa0037315c7c48bc8368871fecb160f7699eab4037c7fcaa9cd00491485be1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_7baa0037315c7c48bc8368871fecb160f7699eab4037c7fcaa9cd00491485be1->leave($__internal_7baa0037315c7c48bc8368871fecb160f7699eab4037c7fcaa9cd00491485be1_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.subject'|trans({'%username%': user.username}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
