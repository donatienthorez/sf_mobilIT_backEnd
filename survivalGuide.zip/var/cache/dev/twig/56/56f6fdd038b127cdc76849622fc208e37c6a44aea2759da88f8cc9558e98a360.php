<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_8c507e6b2f6ea42ea46bf4a33c797ac2a7bac45e4da64972cfd1826e087961de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e031e4b6191d4ba25a1896d0834a7b20c71de2dee169f16fa4c259c6e44b7a3b = $this->env->getExtension("native_profiler");
        $__internal_e031e4b6191d4ba25a1896d0834a7b20c71de2dee169f16fa4c259c6e44b7a3b->enter($__internal_e031e4b6191d4ba25a1896d0834a7b20c71de2dee169f16fa4c259c6e44b7a3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_e031e4b6191d4ba25a1896d0834a7b20c71de2dee169f16fa4c259c6e44b7a3b->leave($__internal_e031e4b6191d4ba25a1896d0834a7b20c71de2dee169f16fa4c259c6e44b7a3b_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_29dd5af874accb4ee11dee538f55192eeae68d628227979e21894e6e2f736385 = $this->env->getExtension("native_profiler");
        $__internal_29dd5af874accb4ee11dee538f55192eeae68d628227979e21894e6e2f736385->enter($__internal_29dd5af874accb4ee11dee538f55192eeae68d628227979e21894e6e2f736385_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        echo "
";
        
        $__internal_29dd5af874accb4ee11dee538f55192eeae68d628227979e21894e6e2f736385->leave($__internal_29dd5af874accb4ee11dee538f55192eeae68d628227979e21894e6e2f736385_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_3016584c7be08d2591992402a268b268d3a9c0380dec3101ee49b6e0ee2f264c = $this->env->getExtension("native_profiler");
        $__internal_3016584c7be08d2591992402a268b268d3a9c0380dec3101ee49b6e0ee2f264c->enter($__internal_3016584c7be08d2591992402a268b268d3a9c0380dec3101ee49b6e0ee2f264c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_3016584c7be08d2591992402a268b268d3a9c0380dec3101ee49b6e0ee2f264c->leave($__internal_3016584c7be08d2591992402a268b268d3a9c0380dec3101ee49b6e0ee2f264c_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_1adcef61eae85eacf1ce72009ea0ec65478380ed5f755b91ba90b98aad59934a = $this->env->getExtension("native_profiler");
        $__internal_1adcef61eae85eacf1ce72009ea0ec65478380ed5f755b91ba90b98aad59934a->enter($__internal_1adcef61eae85eacf1ce72009ea0ec65478380ed5f755b91ba90b98aad59934a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_1adcef61eae85eacf1ce72009ea0ec65478380ed5f755b91ba90b98aad59934a->leave($__internal_1adcef61eae85eacf1ce72009ea0ec65478380ed5f755b91ba90b98aad59934a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.subject'|trans({'%username%': user.username}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
