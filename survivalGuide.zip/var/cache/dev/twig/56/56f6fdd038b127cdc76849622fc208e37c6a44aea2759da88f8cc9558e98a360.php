<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_8c507e6b2f6ea42ea46bf4a33c797ac2a7bac45e4da64972cfd1826e087961de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df9740b6a915abbc81799e15799ca0ffea1994877e2de93398da82c1a4428fe3 = $this->env->getExtension("native_profiler");
        $__internal_df9740b6a915abbc81799e15799ca0ffea1994877e2de93398da82c1a4428fe3->enter($__internal_df9740b6a915abbc81799e15799ca0ffea1994877e2de93398da82c1a4428fe3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_df9740b6a915abbc81799e15799ca0ffea1994877e2de93398da82c1a4428fe3->leave($__internal_df9740b6a915abbc81799e15799ca0ffea1994877e2de93398da82c1a4428fe3_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_d1e1ce7ccbf3ae7648250f2ad26ca387d39a381dbd262f019217a31c003c7a69 = $this->env->getExtension("native_profiler");
        $__internal_d1e1ce7ccbf3ae7648250f2ad26ca387d39a381dbd262f019217a31c003c7a69->enter($__internal_d1e1ce7ccbf3ae7648250f2ad26ca387d39a381dbd262f019217a31c003c7a69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        echo "
";
        
        $__internal_d1e1ce7ccbf3ae7648250f2ad26ca387d39a381dbd262f019217a31c003c7a69->leave($__internal_d1e1ce7ccbf3ae7648250f2ad26ca387d39a381dbd262f019217a31c003c7a69_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_d5cb5d222c68ab7909c643210663d5f8f8514851509e34104192ec628536f761 = $this->env->getExtension("native_profiler");
        $__internal_d5cb5d222c68ab7909c643210663d5f8f8514851509e34104192ec628536f761->enter($__internal_d5cb5d222c68ab7909c643210663d5f8f8514851509e34104192ec628536f761_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_d5cb5d222c68ab7909c643210663d5f8f8514851509e34104192ec628536f761->leave($__internal_d5cb5d222c68ab7909c643210663d5f8f8514851509e34104192ec628536f761_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_3a75da463cd2fb53c94fc733348c197d494aaeb907e2c4901462e049d00fd834 = $this->env->getExtension("native_profiler");
        $__internal_3a75da463cd2fb53c94fc733348c197d494aaeb907e2c4901462e049d00fd834->enter($__internal_3a75da463cd2fb53c94fc733348c197d494aaeb907e2c4901462e049d00fd834_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_3a75da463cd2fb53c94fc733348c197d494aaeb907e2c4901462e049d00fd834->leave($__internal_3a75da463cd2fb53c94fc733348c197d494aaeb907e2c4901462e049d00fd834_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.subject'|trans({'%username%': user.username}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
