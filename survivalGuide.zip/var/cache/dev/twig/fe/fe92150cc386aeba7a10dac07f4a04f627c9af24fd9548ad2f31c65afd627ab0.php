<?php

/* MainBundle::base.html.twig */
class __TwigTemplate_a1dcd110e0718ccc66c6bf19d6bc8c4878bfaa9795aee2726a0c14652f4c809e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_09dfe94af03a1f4a155b2515ab7802e9edb275409193c8fae12e7dc482575317 = $this->env->getExtension("native_profiler");
        $__internal_09dfe94af03a1f4a155b2515ab7802e9edb275409193c8fae12e7dc482575317->enter($__internal_09dfe94af03a1f4a155b2515ab7802e9edb275409193c8fae12e7dc482575317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle::base.html.twig"));

        // line 1
        echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">
<html ng-app=\"survivalGuideApp\">
";
        // line 3
        echo twig_include($this->env, $context, "MainBundle::header.html.twig");
        echo "

    <body>
        ";
        // line 6
        echo twig_include($this->env, $context, "MainBundle::navbar.html.twig");
        echo "
        ";
        // line 7
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 8
            echo "            ";
            echo twig_include($this->env, $context, "MainBundle::subnavbar.html.twig");
            echo "
        ";
        }
        // line 10
        echo "
        ";
        // line 11
        $this->displayBlock('body', $context, $blocks);
        // line 13
        echo "    </body>
</html>";
        
        $__internal_09dfe94af03a1f4a155b2515ab7802e9edb275409193c8fae12e7dc482575317->leave($__internal_09dfe94af03a1f4a155b2515ab7802e9edb275409193c8fae12e7dc482575317_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_85b4eeb889628b0fe8d7b4fabf3fa687192d54db114ead9d9d807d84d7b3c2cc = $this->env->getExtension("native_profiler");
        $__internal_85b4eeb889628b0fe8d7b4fabf3fa687192d54db114ead9d9d807d84d7b3c2cc->enter($__internal_85b4eeb889628b0fe8d7b4fabf3fa687192d54db114ead9d9d807d84d7b3c2cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "        ";
        
        $__internal_85b4eeb889628b0fe8d7b4fabf3fa687192d54db114ead9d9d807d84d7b3c2cc->leave($__internal_85b4eeb889628b0fe8d7b4fabf3fa687192d54db114ead9d9d807d84d7b3c2cc_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 12,  58 => 11,  50 => 13,  48 => 11,  45 => 10,  39 => 8,  37 => 7,  33 => 6,  27 => 3,  23 => 1,);
    }
}
/* <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">*/
/* <html ng-app="survivalGuideApp">*/
/* {{ include('MainBundle::header.html.twig') }}*/
/* */
/*     <body>*/
/*         {{ include('MainBundle::navbar.html.twig') }}*/
/*         {% if app.user %}*/
/*             {{ include('MainBundle::subnavbar.html.twig') }}*/
/*         {% endif %}*/
/* */
/*         {% block body %}*/
/*         {% endblock %}*/
/*     </body>*/
/* </html>*/
