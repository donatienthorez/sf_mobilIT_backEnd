<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_58760cd72f9d0f08e7efa2555c9c122ec9626aae3d7f26c6e13806f3705a444b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e1b4207eea2efce362a673c07d34ae3c63a9a103dd3ed54157c2b8bf5fa794c5 = $this->env->getExtension("native_profiler");
        $__internal_e1b4207eea2efce362a673c07d34ae3c63a9a103dd3ed54157c2b8bf5fa794c5->enter($__internal_e1b4207eea2efce362a673c07d34ae3c63a9a103dd3ed54157c2b8bf5fa794c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_e1b4207eea2efce362a673c07d34ae3c63a9a103dd3ed54157c2b8bf5fa794c5->leave($__internal_e1b4207eea2efce362a673c07d34ae3c63a9a103dd3ed54157c2b8bf5fa794c5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
