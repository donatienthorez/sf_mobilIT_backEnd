<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_58760cd72f9d0f08e7efa2555c9c122ec9626aae3d7f26c6e13806f3705a444b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_60aa8b88c472406dd269d64a2e389622b021129edffcdda18d8f343be1f4a029 = $this->env->getExtension("native_profiler");
        $__internal_60aa8b88c472406dd269d64a2e389622b021129edffcdda18d8f343be1f4a029->enter($__internal_60aa8b88c472406dd269d64a2e389622b021129edffcdda18d8f343be1f4a029_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_60aa8b88c472406dd269d64a2e389622b021129edffcdda18d8f343be1f4a029->leave($__internal_60aa8b88c472406dd269d64a2e389622b021129edffcdda18d8f343be1f4a029_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
