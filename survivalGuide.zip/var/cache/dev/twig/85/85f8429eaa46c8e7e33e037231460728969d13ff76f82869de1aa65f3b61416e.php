<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_831486dc0b340e8b32595e7d82f97329911e1311d47aa65e18806da55d58978b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ee57107216c3c92587569d2093f9aef71ed7ceaa6c972bba2c91754b9267047 = $this->env->getExtension("native_profiler");
        $__internal_0ee57107216c3c92587569d2093f9aef71ed7ceaa6c972bba2c91754b9267047->enter($__internal_0ee57107216c3c92587569d2093f9aef71ed7ceaa6c972bba2c91754b9267047_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_0ee57107216c3c92587569d2093f9aef71ed7ceaa6c972bba2c91754b9267047->leave($__internal_0ee57107216c3c92587569d2093f9aef71ed7ceaa6c972bba2c91754b9267047_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($widget == 'single_text'): ?>*/
/*     <?php echo $view['form']->block($form, 'form_widget_simple'); ?>*/
/* <?php else: ?>*/
/*     <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*         <?php echo $view['form']->widget($form['date']).' '.$view['form']->widget($form['time']) ?>*/
/*     </div>*/
/* <?php endif ?>*/
/* */
