<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_9fc2f658de99f96eaee9a33055da11143c988aa5764b7c1a5b190fab9a9b9fed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4f1c026f4f9026354ea9030150ab65f60e4034848de517239708f49d9ad749d4 = $this->env->getExtension("native_profiler");
        $__internal_4f1c026f4f9026354ea9030150ab65f60e4034848de517239708f49d9ad749d4->enter($__internal_4f1c026f4f9026354ea9030150ab65f60e4034848de517239708f49d9ad749d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_4f1c026f4f9026354ea9030150ab65f60e4034848de517239708f49d9ad749d4->leave($__internal_4f1c026f4f9026354ea9030150ab65f60e4034848de517239708f49d9ad749d4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
