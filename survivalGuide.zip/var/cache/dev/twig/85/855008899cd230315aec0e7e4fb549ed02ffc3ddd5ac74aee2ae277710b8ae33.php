<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_9fc2f658de99f96eaee9a33055da11143c988aa5764b7c1a5b190fab9a9b9fed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c4f095698779c1bb3f6becc0cea51d02337783b09f8c6dc78d2944234975bdc = $this->env->getExtension("native_profiler");
        $__internal_5c4f095698779c1bb3f6becc0cea51d02337783b09f8c6dc78d2944234975bdc->enter($__internal_5c4f095698779c1bb3f6becc0cea51d02337783b09f8c6dc78d2944234975bdc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_5c4f095698779c1bb3f6becc0cea51d02337783b09f8c6dc78d2944234975bdc->leave($__internal_5c4f095698779c1bb3f6becc0cea51d02337783b09f8c6dc78d2944234975bdc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
