<?php

/* FOSUserBundle:Group:show_content.html.twig */
class __TwigTemplate_580a39e9e955bdca6db827f922e0148a4d43f9f9d1ba7c53bd5747de2c67b443 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05e799774c86ddbfdd1aa3b9d1800f6c489335250dc05ab60dbf104c41d003a5 = $this->env->getExtension("native_profiler");
        $__internal_05e799774c86ddbfdd1aa3b9d1800f6c489335250dc05ab60dbf104c41d003a5->enter($__internal_05e799774c86ddbfdd1aa3b9d1800f6c489335250dc05ab60dbf104c41d003a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_group_show\">
    <p>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("group.show.name", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "getName", array(), "method"), "html", null, true);
        echo "</p>
</div>
";
        
        $__internal_05e799774c86ddbfdd1aa3b9d1800f6c489335250dc05ab60dbf104c41d003a5->leave($__internal_05e799774c86ddbfdd1aa3b9d1800f6c489335250dc05ab60dbf104c41d003a5_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 4,  22 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* <div class="fos_user_group_show">*/
/*     <p>{{ 'group.show.name'|trans }}: {{ group.getName() }}</p>*/
/* </div>*/
/* */
