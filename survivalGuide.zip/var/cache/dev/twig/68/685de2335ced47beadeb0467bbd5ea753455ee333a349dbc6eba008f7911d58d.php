<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_a7cc2f2367118cf8c815e39f36bc9f444ffe15db4fa7d36be785ac3057342a73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_972af5aaee5404ff4ae10f6a4c2fb41af96d50cf293b486c3fdecf5d3290bf61 = $this->env->getExtension("native_profiler");
        $__internal_972af5aaee5404ff4ae10f6a4c2fb41af96d50cf293b486c3fdecf5d3290bf61->enter($__internal_972af5aaee5404ff4ae10f6a4c2fb41af96d50cf293b486c3fdecf5d3290bf61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_972af5aaee5404ff4ae10f6a4c2fb41af96d50cf293b486c3fdecf5d3290bf61->leave($__internal_972af5aaee5404ff4ae10f6a4c2fb41af96d50cf293b486c3fdecf5d3290bf61_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
