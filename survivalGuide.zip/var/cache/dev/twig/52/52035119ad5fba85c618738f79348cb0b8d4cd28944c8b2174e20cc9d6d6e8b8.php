<?php

/* FOSUserBundle:Registration:checkEmail.html.twig */
class __TwigTemplate_253c1459f8c4a7d1c5f56a7e1c11180d188e41b20e419772d984a117c3af87fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a34933559f14a5f170a6e3813a6c834ae4dcb73aec21771b7bfc261b8be94d90 = $this->env->getExtension("native_profiler");
        $__internal_a34933559f14a5f170a6e3813a6c834ae4dcb73aec21771b7bfc261b8be94d90->enter($__internal_a34933559f14a5f170a6e3813a6c834ae4dcb73aec21771b7bfc261b8be94d90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a34933559f14a5f170a6e3813a6c834ae4dcb73aec21771b7bfc261b8be94d90->leave($__internal_a34933559f14a5f170a6e3813a6c834ae4dcb73aec21771b7bfc261b8be94d90_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_03aead5ff4254a8d1d923f9d6a1b5d7479d55889118df479da90014ce00dec83 = $this->env->getExtension("native_profiler");
        $__internal_03aead5ff4254a8d1d923f9d6a1b5d7479d55889118df479da90014ce00dec83->enter($__internal_03aead5ff4254a8d1d923f9d6a1b5d7479d55889118df479da90014ce00dec83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_03aead5ff4254a8d1d923f9d6a1b5d7479d55889118df479da90014ce00dec83->leave($__internal_03aead5ff4254a8d1d923f9d6a1b5d7479d55889118df479da90014ce00dec83_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/*     <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
