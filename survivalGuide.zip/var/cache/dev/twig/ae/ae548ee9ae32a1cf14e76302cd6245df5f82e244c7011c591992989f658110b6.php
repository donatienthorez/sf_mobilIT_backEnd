<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_024a8d03591cfe2f94bd9edd4f5a17b80ace794cc8b1ac13381dcb8a0b7367cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9627ea445e6ea7b7b2c7a96881aef7573326371c71669c6c06ce88460718248d = $this->env->getExtension("native_profiler");
        $__internal_9627ea445e6ea7b7b2c7a96881aef7573326371c71669c6c06ce88460718248d->enter($__internal_9627ea445e6ea7b7b2c7a96881aef7573326371c71669c6c06ce88460718248d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9627ea445e6ea7b7b2c7a96881aef7573326371c71669c6c06ce88460718248d->leave($__internal_9627ea445e6ea7b7b2c7a96881aef7573326371c71669c6c06ce88460718248d_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_10d59dac0a125f40cb362474a22bbe84a00e750d19f2603485ce629c0be8a143 = $this->env->getExtension("native_profiler");
        $__internal_10d59dac0a125f40cb362474a22bbe84a00e750d19f2603485ce629c0be8a143->enter($__internal_10d59dac0a125f40cb362474a22bbe84a00e750d19f2603485ce629c0be8a143_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_10d59dac0a125f40cb362474a22bbe84a00e750d19f2603485ce629c0be8a143->leave($__internal_10d59dac0a125f40cb362474a22bbe84a00e750d19f2603485ce629c0be8a143_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
