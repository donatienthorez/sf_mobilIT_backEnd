<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_024a8d03591cfe2f94bd9edd4f5a17b80ace794cc8b1ac13381dcb8a0b7367cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e7ea7b77d2452345ae49e40a337a16b432accd055b8277720ea9f69b1a9692e = $this->env->getExtension("native_profiler");
        $__internal_1e7ea7b77d2452345ae49e40a337a16b432accd055b8277720ea9f69b1a9692e->enter($__internal_1e7ea7b77d2452345ae49e40a337a16b432accd055b8277720ea9f69b1a9692e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1e7ea7b77d2452345ae49e40a337a16b432accd055b8277720ea9f69b1a9692e->leave($__internal_1e7ea7b77d2452345ae49e40a337a16b432accd055b8277720ea9f69b1a9692e_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f0534eef79a492d93fa3b6aa67a548f8a39a4e804abb63133f411f94d08c0fc8 = $this->env->getExtension("native_profiler");
        $__internal_f0534eef79a492d93fa3b6aa67a548f8a39a4e804abb63133f411f94d08c0fc8->enter($__internal_f0534eef79a492d93fa3b6aa67a548f8a39a4e804abb63133f411f94d08c0fc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_f0534eef79a492d93fa3b6aa67a548f8a39a4e804abb63133f411f94d08c0fc8->leave($__internal_f0534eef79a492d93fa3b6aa67a548f8a39a4e804abb63133f411f94d08c0fc8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
