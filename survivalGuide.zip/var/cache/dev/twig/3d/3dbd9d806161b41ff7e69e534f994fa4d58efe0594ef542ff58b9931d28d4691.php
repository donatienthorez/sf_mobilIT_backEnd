<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_7b64cc2db2e4487aae654fdaadae4f7a5ab3d6ea9c588a6fcc2363510edc3fe2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c07149a9a1941a355bffa63e4e877a2143e719b33f92d122aacae5f25a94186 = $this->env->getExtension("native_profiler");
        $__internal_3c07149a9a1941a355bffa63e4e877a2143e719b33f92d122aacae5f25a94186->enter($__internal_3c07149a9a1941a355bffa63e4e877a2143e719b33f92d122aacae5f25a94186_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_3c07149a9a1941a355bffa63e4e877a2143e719b33f92d122aacae5f25a94186->leave($__internal_3c07149a9a1941a355bffa63e4e877a2143e719b33f92d122aacae5f25a94186_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
