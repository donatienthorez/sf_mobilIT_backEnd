<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_7b64cc2db2e4487aae654fdaadae4f7a5ab3d6ea9c588a6fcc2363510edc3fe2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5bccc2c83576087b3e321b8e474f7a669a341faaf1ae6602d2425771dad5e5d2 = $this->env->getExtension("native_profiler");
        $__internal_5bccc2c83576087b3e321b8e474f7a669a341faaf1ae6602d2425771dad5e5d2->enter($__internal_5bccc2c83576087b3e321b8e474f7a669a341faaf1ae6602d2425771dad5e5d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_5bccc2c83576087b3e321b8e474f7a669a341faaf1ae6602d2425771dad5e5d2->leave($__internal_5bccc2c83576087b3e321b8e474f7a669a341faaf1ae6602d2425771dad5e5d2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
