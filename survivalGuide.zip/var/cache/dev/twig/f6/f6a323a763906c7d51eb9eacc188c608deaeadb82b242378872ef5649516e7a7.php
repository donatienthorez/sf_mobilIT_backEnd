<?php

/* FOSUserBundle:Resetting:checkEmail.html.twig */
class __TwigTemplate_fe0db8f5a55d779c072d31f0fc95f6d52995e9ea9d2ab1ef9e73d271e55f5d26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9061080f07fcecccdf31b13a25b99834e369991bf9e84e819e75bfd6be241202 = $this->env->getExtension("native_profiler");
        $__internal_9061080f07fcecccdf31b13a25b99834e369991bf9e84e819e75bfd6be241202->enter($__internal_9061080f07fcecccdf31b13a25b99834e369991bf9e84e819e75bfd6be241202_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9061080f07fcecccdf31b13a25b99834e369991bf9e84e819e75bfd6be241202->leave($__internal_9061080f07fcecccdf31b13a25b99834e369991bf9e84e819e75bfd6be241202_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_6883cd852e937f7805b9e3476d3b66943223ddcb64a7cb1e85403165fdf88267 = $this->env->getExtension("native_profiler");
        $__internal_6883cd852e937f7805b9e3476d3b66943223ddcb64a7cb1e85403165fdf88267->enter($__internal_6883cd852e937f7805b9e3476d3b66943223ddcb64a7cb1e85403165fdf88267_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.check_email", array("%email%" => (isset($context["email"]) ? $context["email"] : $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "
</p>
";
        
        $__internal_6883cd852e937f7805b9e3476d3b66943223ddcb64a7cb1e85403165fdf88267->leave($__internal_6883cd852e937f7805b9e3476d3b66943223ddcb64a7cb1e85403165fdf88267_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>*/
/* {{ 'resetting.check_email'|trans({'%email%': email}) }}*/
/* </p>*/
/* {% endblock %}*/
/* */
