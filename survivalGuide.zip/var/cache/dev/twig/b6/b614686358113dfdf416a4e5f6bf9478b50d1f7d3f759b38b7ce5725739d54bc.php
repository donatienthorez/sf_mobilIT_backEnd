<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_8d07e55f849b1b8078cc74da932e58be6f59e2ec6b78905c19342897e31133c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e2c9a526a5ccc1ede4fe79abe025dd40294cbaf7d7baa8ec6d630c979521767 = $this->env->getExtension("native_profiler");
        $__internal_5e2c9a526a5ccc1ede4fe79abe025dd40294cbaf7d7baa8ec6d630c979521767->enter($__internal_5e2c9a526a5ccc1ede4fe79abe025dd40294cbaf7d7baa8ec6d630c979521767_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_5e2c9a526a5ccc1ede4fe79abe025dd40294cbaf7d7baa8ec6d630c979521767->leave($__internal_5e2c9a526a5ccc1ede4fe79abe025dd40294cbaf7d7baa8ec6d630c979521767_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_081c9117d825e86058740098a827893754a45faed8930b0f35ca9d20361712c4 = $this->env->getExtension("native_profiler");
        $__internal_081c9117d825e86058740098a827893754a45faed8930b0f35ca9d20361712c4->enter($__internal_081c9117d825e86058740098a827893754a45faed8930b0f35ca9d20361712c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_081c9117d825e86058740098a827893754a45faed8930b0f35ca9d20361712c4->leave($__internal_081c9117d825e86058740098a827893754a45faed8930b0f35ca9d20361712c4_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
