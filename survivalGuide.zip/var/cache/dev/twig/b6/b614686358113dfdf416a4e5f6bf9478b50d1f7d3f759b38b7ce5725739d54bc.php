<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_8d07e55f849b1b8078cc74da932e58be6f59e2ec6b78905c19342897e31133c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8d0b1e794c9456fa4a191d93552e0b8865d0dd4dfd95daf7afa14b5ce6a113c0 = $this->env->getExtension("native_profiler");
        $__internal_8d0b1e794c9456fa4a191d93552e0b8865d0dd4dfd95daf7afa14b5ce6a113c0->enter($__internal_8d0b1e794c9456fa4a191d93552e0b8865d0dd4dfd95daf7afa14b5ce6a113c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_8d0b1e794c9456fa4a191d93552e0b8865d0dd4dfd95daf7afa14b5ce6a113c0->leave($__internal_8d0b1e794c9456fa4a191d93552e0b8865d0dd4dfd95daf7afa14b5ce6a113c0_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_5345e7a1fd063e9c19041e1b4e97a82a2893134e1639d499247203d653541d3e = $this->env->getExtension("native_profiler");
        $__internal_5345e7a1fd063e9c19041e1b4e97a82a2893134e1639d499247203d653541d3e->enter($__internal_5345e7a1fd063e9c19041e1b4e97a82a2893134e1639d499247203d653541d3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_5345e7a1fd063e9c19041e1b4e97a82a2893134e1639d499247203d653541d3e->leave($__internal_5345e7a1fd063e9c19041e1b4e97a82a2893134e1639d499247203d653541d3e_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
