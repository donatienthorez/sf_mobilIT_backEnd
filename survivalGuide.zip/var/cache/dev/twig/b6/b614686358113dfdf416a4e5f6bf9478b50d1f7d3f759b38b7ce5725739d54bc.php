<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_8d07e55f849b1b8078cc74da932e58be6f59e2ec6b78905c19342897e31133c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d6a8ca87545f0ed58f590f302038b35bf5f3781a7234076d3a546c4d1c39e32 = $this->env->getExtension("native_profiler");
        $__internal_7d6a8ca87545f0ed58f590f302038b35bf5f3781a7234076d3a546c4d1c39e32->enter($__internal_7d6a8ca87545f0ed58f590f302038b35bf5f3781a7234076d3a546c4d1c39e32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_7d6a8ca87545f0ed58f590f302038b35bf5f3781a7234076d3a546c4d1c39e32->leave($__internal_7d6a8ca87545f0ed58f590f302038b35bf5f3781a7234076d3a546c4d1c39e32_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_b1dfd879708d40bd913f10a57e7ed986b3ea64a39258da2daffe32484d53fc1b = $this->env->getExtension("native_profiler");
        $__internal_b1dfd879708d40bd913f10a57e7ed986b3ea64a39258da2daffe32484d53fc1b->enter($__internal_b1dfd879708d40bd913f10a57e7ed986b3ea64a39258da2daffe32484d53fc1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_b1dfd879708d40bd913f10a57e7ed986b3ea64a39258da2daffe32484d53fc1b->leave($__internal_b1dfd879708d40bd913f10a57e7ed986b3ea64a39258da2daffe32484d53fc1b_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
