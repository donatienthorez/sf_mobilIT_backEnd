<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_c0c6e1b36c5c300f73260144d1794f832149f20daf800a7640e989be8aa591a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_954eed4f4192ef70d97ba16a093e9a4e5f145dd3f21fe14038e5f5ccbb28f532 = $this->env->getExtension("native_profiler");
        $__internal_954eed4f4192ef70d97ba16a093e9a4e5f145dd3f21fe14038e5f5ccbb28f532->enter($__internal_954eed4f4192ef70d97ba16a093e9a4e5f145dd3f21fe14038e5f5ccbb28f532_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_954eed4f4192ef70d97ba16a093e9a4e5f145dd3f21fe14038e5f5ccbb28f532->leave($__internal_954eed4f4192ef70d97ba16a093e9a4e5f145dd3f21fe14038e5f5ccbb28f532_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo str_replace('{{ widget }}', $view['form']->block($form, 'form_widget_simple'), $money_pattern) ?>*/
/* */
