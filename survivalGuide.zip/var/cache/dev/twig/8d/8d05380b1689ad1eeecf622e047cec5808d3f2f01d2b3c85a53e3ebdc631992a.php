<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_c0e1cbfd3dbad032bd25b94fba9db4fc5f28d69a28401f49950e99c41d703032 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0a6d7106845cfaf4bfa32623e50b7e123afa5515f65b32e4b26cd46811c92883 = $this->env->getExtension("native_profiler");
        $__internal_0a6d7106845cfaf4bfa32623e50b7e123afa5515f65b32e4b26cd46811c92883->enter($__internal_0a6d7106845cfaf4bfa32623e50b7e123afa5515f65b32e4b26cd46811c92883_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_0a6d7106845cfaf4bfa32623e50b7e123afa5515f65b32e4b26cd46811c92883->leave($__internal_0a6d7106845cfaf4bfa32623e50b7e123afa5515f65b32e4b26cd46811c92883_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
