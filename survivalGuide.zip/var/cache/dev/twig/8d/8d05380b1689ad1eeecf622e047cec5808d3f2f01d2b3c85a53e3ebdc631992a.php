<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_c0e1cbfd3dbad032bd25b94fba9db4fc5f28d69a28401f49950e99c41d703032 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bd5f9e5f36663352997562e0902e3bf1b14a176bf0806df7e42ef0431d59a65 = $this->env->getExtension("native_profiler");
        $__internal_8bd5f9e5f36663352997562e0902e3bf1b14a176bf0806df7e42ef0431d59a65->enter($__internal_8bd5f9e5f36663352997562e0902e3bf1b14a176bf0806df7e42ef0431d59a65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_8bd5f9e5f36663352997562e0902e3bf1b14a176bf0806df7e42ef0431d59a65->leave($__internal_8bd5f9e5f36663352997562e0902e3bf1b14a176bf0806df7e42ef0431d59a65_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
