<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_c0e1cbfd3dbad032bd25b94fba9db4fc5f28d69a28401f49950e99c41d703032 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c20efb3bb770a4dfe20204b3d40372b5f13bfb7d8a90e727242fbe9b5edac097 = $this->env->getExtension("native_profiler");
        $__internal_c20efb3bb770a4dfe20204b3d40372b5f13bfb7d8a90e727242fbe9b5edac097->enter($__internal_c20efb3bb770a4dfe20204b3d40372b5f13bfb7d8a90e727242fbe9b5edac097_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_c20efb3bb770a4dfe20204b3d40372b5f13bfb7d8a90e727242fbe9b5edac097->leave($__internal_c20efb3bb770a4dfe20204b3d40372b5f13bfb7d8a90e727242fbe9b5edac097_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
