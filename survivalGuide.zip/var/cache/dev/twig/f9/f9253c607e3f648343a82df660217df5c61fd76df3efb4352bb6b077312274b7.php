<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_e40562a4d078e26be561c023b455e611e2c4baf60a8c0d520dc6c87d4057b17b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_25cd6152e9fd53a04c7074ae7af272befde2246fe59fbeb87e3eefd90492ee64 = $this->env->getExtension("native_profiler");
        $__internal_25cd6152e9fd53a04c7074ae7af272befde2246fe59fbeb87e3eefd90492ee64->enter($__internal_25cd6152e9fd53a04c7074ae7af272befde2246fe59fbeb87e3eefd90492ee64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_25cd6152e9fd53a04c7074ae7af272befde2246fe59fbeb87e3eefd90492ee64->leave($__internal_25cd6152e9fd53a04c7074ae7af272befde2246fe59fbeb87e3eefd90492ee64_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
