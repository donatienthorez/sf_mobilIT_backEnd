<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_e40562a4d078e26be561c023b455e611e2c4baf60a8c0d520dc6c87d4057b17b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14e4290e00d30afe9bd46407aa325123278aec6432dd79af0008d3052da54782 = $this->env->getExtension("native_profiler");
        $__internal_14e4290e00d30afe9bd46407aa325123278aec6432dd79af0008d3052da54782->enter($__internal_14e4290e00d30afe9bd46407aa325123278aec6432dd79af0008d3052da54782_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_14e4290e00d30afe9bd46407aa325123278aec6432dd79af0008d3052da54782->leave($__internal_14e4290e00d30afe9bd46407aa325123278aec6432dd79af0008d3052da54782_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
