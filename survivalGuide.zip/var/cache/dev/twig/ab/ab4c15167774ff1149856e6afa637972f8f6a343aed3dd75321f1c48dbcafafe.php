<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_96c29b1f38293c5621def2609f400e3ed74081fb46392b876e15246092dca179 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a33971aac1b0edefb852079d5485e95dc351bb33a7f4dfd4048e16415f5fc691 = $this->env->getExtension("native_profiler");
        $__internal_a33971aac1b0edefb852079d5485e95dc351bb33a7f4dfd4048e16415f5fc691->enter($__internal_a33971aac1b0edefb852079d5485e95dc351bb33a7f4dfd4048e16415f5fc691_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_a33971aac1b0edefb852079d5485e95dc351bb33a7f4dfd4048e16415f5fc691->leave($__internal_a33971aac1b0edefb852079d5485e95dc351bb33a7f4dfd4048e16415f5fc691_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
