<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_96c29b1f38293c5621def2609f400e3ed74081fb46392b876e15246092dca179 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_db15f1876f58966612ddfb936786bb0eeb76a7f41bef727f36787b4e3cf788e9 = $this->env->getExtension("native_profiler");
        $__internal_db15f1876f58966612ddfb936786bb0eeb76a7f41bef727f36787b4e3cf788e9->enter($__internal_db15f1876f58966612ddfb936786bb0eeb76a7f41bef727f36787b4e3cf788e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_db15f1876f58966612ddfb936786bb0eeb76a7f41bef727f36787b4e3cf788e9->leave($__internal_db15f1876f58966612ddfb936786bb0eeb76a7f41bef727f36787b4e3cf788e9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
