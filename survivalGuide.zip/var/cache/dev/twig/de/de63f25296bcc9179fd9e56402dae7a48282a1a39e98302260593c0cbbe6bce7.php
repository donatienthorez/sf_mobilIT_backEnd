<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_99c8d7eba8b83bbd00375d5c77f69fa4c7c6ca1973202e4011507d0fb9e7de11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a5f3d79ca1ba7d6210e152be1fcfbad2272a0b88a17ca251e8a0ac30398b164d = $this->env->getExtension("native_profiler");
        $__internal_a5f3d79ca1ba7d6210e152be1fcfbad2272a0b88a17ca251e8a0ac30398b164d->enter($__internal_a5f3d79ca1ba7d6210e152be1fcfbad2272a0b88a17ca251e8a0ac30398b164d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_a5f3d79ca1ba7d6210e152be1fcfbad2272a0b88a17ca251e8a0ac30398b164d->leave($__internal_a5f3d79ca1ba7d6210e152be1fcfbad2272a0b88a17ca251e8a0ac30398b164d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
