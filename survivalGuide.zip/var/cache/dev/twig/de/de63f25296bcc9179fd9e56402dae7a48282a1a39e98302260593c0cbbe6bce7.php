<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_99c8d7eba8b83bbd00375d5c77f69fa4c7c6ca1973202e4011507d0fb9e7de11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1dbb53245e8aff7a1187022c32dfb9c1c3b282d02530fa0ef62fbe8e60e79cec = $this->env->getExtension("native_profiler");
        $__internal_1dbb53245e8aff7a1187022c32dfb9c1c3b282d02530fa0ef62fbe8e60e79cec->enter($__internal_1dbb53245e8aff7a1187022c32dfb9c1c3b282d02530fa0ef62fbe8e60e79cec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_1dbb53245e8aff7a1187022c32dfb9c1c3b282d02530fa0ef62fbe8e60e79cec->leave($__internal_1dbb53245e8aff7a1187022c32dfb9c1c3b282d02530fa0ef62fbe8e60e79cec_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
