<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_acd47828b82a4194a0f19dbd14ff064f2234060719f8f17a805991a19128d949 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b847e501572dd0017ef178ed884241576dd7a9737a63b11079a48210d8b85eb5 = $this->env->getExtension("native_profiler");
        $__internal_b847e501572dd0017ef178ed884241576dd7a9737a63b11079a48210d8b85eb5->enter($__internal_b847e501572dd0017ef178ed884241576dd7a9737a63b11079a48210d8b85eb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_b847e501572dd0017ef178ed884241576dd7a9737a63b11079a48210d8b85eb5->leave($__internal_b847e501572dd0017ef178ed884241576dd7a9737a63b11079a48210d8b85eb5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
