<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_acd47828b82a4194a0f19dbd14ff064f2234060719f8f17a805991a19128d949 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c80fceb6edb37b7690e4cc2ac33da51b38b44145b7c1e928bb2dac03bc66fc96 = $this->env->getExtension("native_profiler");
        $__internal_c80fceb6edb37b7690e4cc2ac33da51b38b44145b7c1e928bb2dac03bc66fc96->enter($__internal_c80fceb6edb37b7690e4cc2ac33da51b38b44145b7c1e928bb2dac03bc66fc96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_c80fceb6edb37b7690e4cc2ac33da51b38b44145b7c1e928bb2dac03bc66fc96->leave($__internal_c80fceb6edb37b7690e4cc2ac33da51b38b44145b7c1e928bb2dac03bc66fc96_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
