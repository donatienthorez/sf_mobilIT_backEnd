<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_02268e645b7a728a5dc830352e1ce1bc3e3a668712c11c259dfc07cf3c1d4cec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5940e49e0a398cb71f7aaf4a5af733caa3679446cf95e864b54358492ee70e9b = $this->env->getExtension("native_profiler");
        $__internal_5940e49e0a398cb71f7aaf4a5af733caa3679446cf95e864b54358492ee70e9b->enter($__internal_5940e49e0a398cb71f7aaf4a5af733caa3679446cf95e864b54358492ee70e9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_5940e49e0a398cb71f7aaf4a5af733caa3679446cf95e864b54358492ee70e9b->leave($__internal_5940e49e0a398cb71f7aaf4a5af733caa3679446cf95e864b54358492ee70e9b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
