<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_02268e645b7a728a5dc830352e1ce1bc3e3a668712c11c259dfc07cf3c1d4cec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_52748cdd12cf2d26f2ba62af18d57c3c9ac4fb83f044df855d9bb91da3a638cc = $this->env->getExtension("native_profiler");
        $__internal_52748cdd12cf2d26f2ba62af18d57c3c9ac4fb83f044df855d9bb91da3a638cc->enter($__internal_52748cdd12cf2d26f2ba62af18d57c3c9ac4fb83f044df855d9bb91da3a638cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_52748cdd12cf2d26f2ba62af18d57c3c9ac4fb83f044df855d9bb91da3a638cc->leave($__internal_52748cdd12cf2d26f2ba62af18d57c3c9ac4fb83f044df855d9bb91da3a638cc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
