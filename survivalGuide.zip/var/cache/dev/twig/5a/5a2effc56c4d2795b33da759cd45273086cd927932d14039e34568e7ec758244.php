<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_02268e645b7a728a5dc830352e1ce1bc3e3a668712c11c259dfc07cf3c1d4cec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_043a31fdb69a18f817b9e71300e8bf66aba45432acd4bad3f75471f4dd8b49ec = $this->env->getExtension("native_profiler");
        $__internal_043a31fdb69a18f817b9e71300e8bf66aba45432acd4bad3f75471f4dd8b49ec->enter($__internal_043a31fdb69a18f817b9e71300e8bf66aba45432acd4bad3f75471f4dd8b49ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_043a31fdb69a18f817b9e71300e8bf66aba45432acd4bad3f75471f4dd8b49ec->leave($__internal_043a31fdb69a18f817b9e71300e8bf66aba45432acd4bad3f75471f4dd8b49ec_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
