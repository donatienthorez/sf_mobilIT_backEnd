<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_c68bf6fb8b779b1bdaf5f8ed3439402d845a40120b7fa36a6a91b80e44b1eb5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2dec7b421aaf77195ff106eaf029f431921612295825641a17b8deefaa9a7796 = $this->env->getExtension("native_profiler");
        $__internal_2dec7b421aaf77195ff106eaf029f431921612295825641a17b8deefaa9a7796->enter($__internal_2dec7b421aaf77195ff106eaf029f431921612295825641a17b8deefaa9a7796_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_2dec7b421aaf77195ff106eaf029f431921612295825641a17b8deefaa9a7796->leave($__internal_2dec7b421aaf77195ff106eaf029f431921612295825641a17b8deefaa9a7796_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
