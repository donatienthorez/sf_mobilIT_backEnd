<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_1888027003dd94835a5f04aa224c67f1dba5d327712497fc64f4f2ced18cbdb1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_56c8cf32ece068f0cff1700d35a260680b0cb096752fc3a4c911f00bad7ecaf1 = $this->env->getExtension("native_profiler");
        $__internal_56c8cf32ece068f0cff1700d35a260680b0cb096752fc3a4c911f00bad7ecaf1->enter($__internal_56c8cf32ece068f0cff1700d35a260680b0cb096752fc3a4c911f00bad7ecaf1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_56c8cf32ece068f0cff1700d35a260680b0cb096752fc3a4c911f00bad7ecaf1->leave($__internal_56c8cf32ece068f0cff1700d35a260680b0cb096752fc3a4c911f00bad7ecaf1_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f2ac6a496c87235967e013ab9f83223a55be688a2199c169706c1b4dfec11f1c = $this->env->getExtension("native_profiler");
        $__internal_f2ac6a496c87235967e013ab9f83223a55be688a2199c169706c1b4dfec11f1c->enter($__internal_f2ac6a496c87235967e013ab9f83223a55be688a2199c169706c1b4dfec11f1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_f2ac6a496c87235967e013ab9f83223a55be688a2199c169706c1b4dfec11f1c->leave($__internal_f2ac6a496c87235967e013ab9f83223a55be688a2199c169706c1b4dfec11f1c_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:request_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
