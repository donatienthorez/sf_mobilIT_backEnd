<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_1888027003dd94835a5f04aa224c67f1dba5d327712497fc64f4f2ced18cbdb1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_007cb95da4a19702a40ff4addb3c836b78d09ee01a27672b619807b2bb8f4640 = $this->env->getExtension("native_profiler");
        $__internal_007cb95da4a19702a40ff4addb3c836b78d09ee01a27672b619807b2bb8f4640->enter($__internal_007cb95da4a19702a40ff4addb3c836b78d09ee01a27672b619807b2bb8f4640_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_007cb95da4a19702a40ff4addb3c836b78d09ee01a27672b619807b2bb8f4640->leave($__internal_007cb95da4a19702a40ff4addb3c836b78d09ee01a27672b619807b2bb8f4640_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_843504efa2996f5b818bd2d413a9a398a7a6ca53ddd1a8c6df7477105d1b93a9 = $this->env->getExtension("native_profiler");
        $__internal_843504efa2996f5b818bd2d413a9a398a7a6ca53ddd1a8c6df7477105d1b93a9->enter($__internal_843504efa2996f5b818bd2d413a9a398a7a6ca53ddd1a8c6df7477105d1b93a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_843504efa2996f5b818bd2d413a9a398a7a6ca53ddd1a8c6df7477105d1b93a9->leave($__internal_843504efa2996f5b818bd2d413a9a398a7a6ca53ddd1a8c6df7477105d1b93a9_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:request_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
