<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_47e4c749b8cfef8dfd56beda4f6800d3a5533fb5fa9e8b4abbf01d517b4ae23a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3052dbf40c1d589b532a57da4b5bd5099c6513a20bca9e743d35c8d686537375 = $this->env->getExtension("native_profiler");
        $__internal_3052dbf40c1d589b532a57da4b5bd5099c6513a20bca9e743d35c8d686537375->enter($__internal_3052dbf40c1d589b532a57da4b5bd5099c6513a20bca9e743d35c8d686537375_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3052dbf40c1d589b532a57da4b5bd5099c6513a20bca9e743d35c8d686537375->leave($__internal_3052dbf40c1d589b532a57da4b5bd5099c6513a20bca9e743d35c8d686537375_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f2eaabf4978240364c04dfa26cfc94a6ebce9b259bca468b0bac44f245d7be84 = $this->env->getExtension("native_profiler");
        $__internal_f2eaabf4978240364c04dfa26cfc94a6ebce9b259bca468b0bac44f245d7be84->enter($__internal_f2eaabf4978240364c04dfa26cfc94a6ebce9b259bca468b0bac44f245d7be84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_f2eaabf4978240364c04dfa26cfc94a6ebce9b259bca468b0bac44f245d7be84->leave($__internal_f2eaabf4978240364c04dfa26cfc94a6ebce9b259bca468b0bac44f245d7be84_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:list_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
