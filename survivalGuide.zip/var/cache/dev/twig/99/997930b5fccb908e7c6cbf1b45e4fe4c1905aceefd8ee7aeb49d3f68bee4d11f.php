<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_47e4c749b8cfef8dfd56beda4f6800d3a5533fb5fa9e8b4abbf01d517b4ae23a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3a2b488fca8063b807f04df9b3dff6ae9ef2817a6b7d7256751c7aa9180cecb6 = $this->env->getExtension("native_profiler");
        $__internal_3a2b488fca8063b807f04df9b3dff6ae9ef2817a6b7d7256751c7aa9180cecb6->enter($__internal_3a2b488fca8063b807f04df9b3dff6ae9ef2817a6b7d7256751c7aa9180cecb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3a2b488fca8063b807f04df9b3dff6ae9ef2817a6b7d7256751c7aa9180cecb6->leave($__internal_3a2b488fca8063b807f04df9b3dff6ae9ef2817a6b7d7256751c7aa9180cecb6_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_54b09a9fd4361ed3d239e2a65a12105178a6cca6cebd78b4902668981057d0b5 = $this->env->getExtension("native_profiler");
        $__internal_54b09a9fd4361ed3d239e2a65a12105178a6cca6cebd78b4902668981057d0b5->enter($__internal_54b09a9fd4361ed3d239e2a65a12105178a6cca6cebd78b4902668981057d0b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_54b09a9fd4361ed3d239e2a65a12105178a6cca6cebd78b4902668981057d0b5->leave($__internal_54b09a9fd4361ed3d239e2a65a12105178a6cca6cebd78b4902668981057d0b5_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:list_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
