<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_144051657a1e31681f0d2380e0c84a421ec6c72da1080a53cbfaf935a6f89adb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0c92f1eb8555ec654da61073cab78f47165a0ac71a47c8d7984d35362b8bfef9 = $this->env->getExtension("native_profiler");
        $__internal_0c92f1eb8555ec654da61073cab78f47165a0ac71a47c8d7984d35362b8bfef9->enter($__internal_0c92f1eb8555ec654da61073cab78f47165a0ac71a47c8d7984d35362b8bfef9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_0c92f1eb8555ec654da61073cab78f47165a0ac71a47c8d7984d35362b8bfef9->leave($__internal_0c92f1eb8555ec654da61073cab78f47165a0ac71a47c8d7984d35362b8bfef9_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}*/
/* */
