<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_4a658175cc73dd21db6a3759b631e0be9c8a473eea78cdd847a962687636e5d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_db86b278cefd594b079c456e0ed6dc5daaa534fccc706ddb7cce9c3ffba3f279 = $this->env->getExtension("native_profiler");
        $__internal_db86b278cefd594b079c456e0ed6dc5daaa534fccc706ddb7cce9c3ffba3f279->enter($__internal_db86b278cefd594b079c456e0ed6dc5daaa534fccc706ddb7cce9c3ffba3f279_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_db86b278cefd594b079c456e0ed6dc5daaa534fccc706ddb7cce9c3ffba3f279->leave($__internal_db86b278cefd594b079c456e0ed6dc5daaa534fccc706ddb7cce9c3ffba3f279_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <table <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <tr>*/
/*         <td colspan="2">*/
/*             <?php echo $view['form']->errors($form) ?>*/
/*         </td>*/
/*     </tr>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </table>*/
/* */
