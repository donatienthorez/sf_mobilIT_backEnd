<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_0f3f102a36e0820baeac7adaeade4f3b106e07792ec0e6fabdaa1c1912d3f908 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e6ea9d51e012cec37a40df8083fc796a4422ce96a039fc0b7f64d1d8a2e0937 = $this->env->getExtension("native_profiler");
        $__internal_2e6ea9d51e012cec37a40df8083fc796a4422ce96a039fc0b7f64d1d8a2e0937->enter($__internal_2e6ea9d51e012cec37a40df8083fc796a4422ce96a039fc0b7f64d1d8a2e0937_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_2e6ea9d51e012cec37a40df8083fc796a4422ce96a039fc0b7f64d1d8a2e0937->leave($__internal_2e6ea9d51e012cec37a40df8083fc796a4422ce96a039fc0b7f64d1d8a2e0937_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */
