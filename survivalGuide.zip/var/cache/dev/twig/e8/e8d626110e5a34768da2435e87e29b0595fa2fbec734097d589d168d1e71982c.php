<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_0f3f102a36e0820baeac7adaeade4f3b106e07792ec0e6fabdaa1c1912d3f908 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_606ec59a91811506f924e4e3140b876420b28f4939f5d022f58fa9f5f986938f = $this->env->getExtension("native_profiler");
        $__internal_606ec59a91811506f924e4e3140b876420b28f4939f5d022f58fa9f5f986938f->enter($__internal_606ec59a91811506f924e4e3140b876420b28f4939f5d022f58fa9f5f986938f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_606ec59a91811506f924e4e3140b876420b28f4939f5d022f58fa9f5f986938f->leave($__internal_606ec59a91811506f924e4e3140b876420b28f4939f5d022f58fa9f5f986938f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */
