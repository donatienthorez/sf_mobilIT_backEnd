<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_3df7fb6fba75d7ff1f8b4e9e8c66387494ab8f71e6563fad093d6d1909a35401 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_935b108ef8e67b104e6c8a17086d4b603b1cd1bea80667013376975857e9900a = $this->env->getExtension("native_profiler");
        $__internal_935b108ef8e67b104e6c8a17086d4b603b1cd1bea80667013376975857e9900a->enter($__internal_935b108ef8e67b104e6c8a17086d4b603b1cd1bea80667013376975857e9900a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_935b108ef8e67b104e6c8a17086d4b603b1cd1bea80667013376975857e9900a->leave($__internal_935b108ef8e67b104e6c8a17086d4b603b1cd1bea80667013376975857e9900a_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_042877c85b4a2a3cc22d95f124fce8dcbff909e5bde7cf9fde23ad8b1e45a0f2 = $this->env->getExtension("native_profiler");
        $__internal_042877c85b4a2a3cc22d95f124fce8dcbff909e5bde7cf9fde23ad8b1e45a0f2->enter($__internal_042877c85b4a2a3cc22d95f124fce8dcbff909e5bde7cf9fde23ad8b1e45a0f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_042877c85b4a2a3cc22d95f124fce8dcbff909e5bde7cf9fde23ad8b1e45a0f2->leave($__internal_042877c85b4a2a3cc22d95f124fce8dcbff909e5bde7cf9fde23ad8b1e45a0f2_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:new_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
