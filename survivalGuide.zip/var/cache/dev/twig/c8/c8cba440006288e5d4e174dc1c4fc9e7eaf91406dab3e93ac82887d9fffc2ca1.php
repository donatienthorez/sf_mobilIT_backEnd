<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_3df7fb6fba75d7ff1f8b4e9e8c66387494ab8f71e6563fad093d6d1909a35401 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93d027f6f84c01753418492fd1d82c7e56963be6242af3faf6ab9efc0952f9a0 = $this->env->getExtension("native_profiler");
        $__internal_93d027f6f84c01753418492fd1d82c7e56963be6242af3faf6ab9efc0952f9a0->enter($__internal_93d027f6f84c01753418492fd1d82c7e56963be6242af3faf6ab9efc0952f9a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_93d027f6f84c01753418492fd1d82c7e56963be6242af3faf6ab9efc0952f9a0->leave($__internal_93d027f6f84c01753418492fd1d82c7e56963be6242af3faf6ab9efc0952f9a0_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_1ca8d0b029d3f2937484f3301bb5a0214365cc48041b1a586784c77fcef74b0f = $this->env->getExtension("native_profiler");
        $__internal_1ca8d0b029d3f2937484f3301bb5a0214365cc48041b1a586784c77fcef74b0f->enter($__internal_1ca8d0b029d3f2937484f3301bb5a0214365cc48041b1a586784c77fcef74b0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_1ca8d0b029d3f2937484f3301bb5a0214365cc48041b1a586784c77fcef74b0f->leave($__internal_1ca8d0b029d3f2937484f3301bb5a0214365cc48041b1a586784c77fcef74b0f_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:new_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
