<?php

/* MainBundle:Notifications:index.html.twig */
class __TwigTemplate_202ba187c4ba2063d8b4a23c08690027f528b6fce1c5982ce9df82e64b848869 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MainBundle::base.html.twig", "MainBundle:Notifications:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MainBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_48a2b7b9b64ad40448a08ddc4dba711707d62f83bd9b00e783c993fd14d98725 = $this->env->getExtension("native_profiler");
        $__internal_48a2b7b9b64ad40448a08ddc4dba711707d62f83bd9b00e783c993fd14d98725->enter($__internal_48a2b7b9b64ad40448a08ddc4dba711707d62f83bd9b00e783c993fd14d98725_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle:Notifications:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_48a2b7b9b64ad40448a08ddc4dba711707d62f83bd9b00e783c993fd14d98725->leave($__internal_48a2b7b9b64ad40448a08ddc4dba711707d62f83bd9b00e783c993fd14d98725_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_407e83ade354346eccb24fb843aff9bb64b77eed30ba446b84b91f2907f9d042 = $this->env->getExtension("native_profiler");
        $__internal_407e83ade354346eccb24fb843aff9bb64b77eed30ba446b84b91f2907f9d042->enter($__internal_407e83ade354346eccb24fb843aff9bb64b77eed30ba446b84b91f2907f9d042_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"main-inner\" ng-controller=\"notificationController\" ng-init=\"init()\">
        <div class=\"container\">
            <div class=\"span5\">
                <div class=\"widget\">
                    <div class=\"widget-header\">
                        <i class=\"icon-book\"></i>
                        <h3>";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("notifications.send-notification"), "html", null, true);
        echo "</h3>
                    </div>
                    <div class=\"widget-content\">
                        <form method=\"post\" name=\"sendNotificationsForm\" ng-submit=\"sendNotification()\">
                            ";
        // line 13
        if ($this->env->getExtension('security')->isGranted("ROLE_ADMIN")) {
            // line 14
            echo "                            <div class=\"control-group\">
                                <label for=\"subject\" class=\"control-label\">Sections</label>
                                <div class=\"controls\">
                                    <select chosen multiple
                                            data-placeholder=\"Choose sections\"
                                            ng-model=\"sectionsSelected\"
                                            ng-options=\"section.name group by section.country.name for section in sections\"
                                            ng-disabled=\"editable\">
                                        <option value=\"\"></option>
                                    </select>
                                </div>
                            </div>
                            ";
        }
        // line 27
        echo "                            <div class=\"control-group\">
                                <label for=\"subject\" class=\"control-label\">Title</label>
                                <div class=\"controls\">
                                    <input class=\"span4\" type=\"text\" ng-model=\"notification.title\" required>
                                </div> <!-- /controls -->
                            </div>

                            <div class=\"control-group\">
                                <label for=\"message\" class=\"control-label\">Content</label>
                                <div class=\"controls\">
                                    <textarea class=\"span4\" cols=\"50\" rows=\"10\" type=\"text\" ng-model=\"notification.content\" required></textarea>
                                </div> <!-- /controls -->
                            </div>
                            <button type=\"submit\" class=\"btn btn-primary\">";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("notifications.send-notification"), "html", null, true);
        echo "</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class=\"span5\">
                <div class=\"widget\">
                    <div class=\"widget-header\">
                        <i class=\"icon-book\"></i>
                        <h3>";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("notifications.last-notifications"), "html", null, true);
        echo "</h3>
                    </div>
                    <div class=\"widget-content\">

                        <ul class=\"news-items\">
                            <li ng-repeat=\"notification in notifications\">
                                <div class=\"news-item-date\">
                                    <span class=\"news-item-month\">{[{ notification.sent_at | date:'dd/MM' }]}</span>
                                    <span class=\"news-item-month\">{[{ notification.sent_at | date:'HH:mm' }]}</span>
                                </div>
                                <div class=\"news-item-detail\">
                                    <span class=\"news-item-title\">{[{ notification.title }]}</span>
                                    <p class=\"news-item-preview\">{[{ notification.content }]}</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_407e83ade354346eccb24fb843aff9bb64b77eed30ba446b84b91f2907f9d042->leave($__internal_407e83ade354346eccb24fb843aff9bb64b77eed30ba446b84b91f2907f9d042_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle:Notifications:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 49,  87 => 40,  72 => 27,  57 => 14,  55 => 13,  48 => 9,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'MainBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <div class="main-inner" ng-controller="notificationController" ng-init="init()">*/
/*         <div class="container">*/
/*             <div class="span5">*/
/*                 <div class="widget">*/
/*                     <div class="widget-header">*/
/*                         <i class="icon-book"></i>*/
/*                         <h3>{{ 'notifications.send-notification' | trans }}</h3>*/
/*                     </div>*/
/*                     <div class="widget-content">*/
/*                         <form method="post" name="sendNotificationsForm" ng-submit="sendNotification()">*/
/*                             {% if is_granted('ROLE_ADMIN') %}*/
/*                             <div class="control-group">*/
/*                                 <label for="subject" class="control-label">Sections</label>*/
/*                                 <div class="controls">*/
/*                                     <select chosen multiple*/
/*                                             data-placeholder="Choose sections"*/
/*                                             ng-model="sectionsSelected"*/
/*                                             ng-options="section.name group by section.country.name for section in sections"*/
/*                                             ng-disabled="editable">*/
/*                                         <option value=""></option>*/
/*                                     </select>*/
/*                                 </div>*/
/*                             </div>*/
/*                             {% endif %}*/
/*                             <div class="control-group">*/
/*                                 <label for="subject" class="control-label">Title</label>*/
/*                                 <div class="controls">*/
/*                                     <input class="span4" type="text" ng-model="notification.title" required>*/
/*                                 </div> <!-- /controls -->*/
/*                             </div>*/
/* */
/*                             <div class="control-group">*/
/*                                 <label for="message" class="control-label">Content</label>*/
/*                                 <div class="controls">*/
/*                                     <textarea class="span4" cols="50" rows="10" type="text" ng-model="notification.content" required></textarea>*/
/*                                 </div> <!-- /controls -->*/
/*                             </div>*/
/*                             <button type="submit" class="btn btn-primary">{{ 'notifications.send-notification' | trans }}</button>*/
/*                         </form>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             <div class="span5">*/
/*                 <div class="widget">*/
/*                     <div class="widget-header">*/
/*                         <i class="icon-book"></i>*/
/*                         <h3>{{ 'notifications.last-notifications' | trans }}</h3>*/
/*                     </div>*/
/*                     <div class="widget-content">*/
/* */
/*                         <ul class="news-items">*/
/*                             <li ng-repeat="notification in notifications">*/
/*                                 <div class="news-item-date">*/
/*                                     <span class="news-item-month">{[{ notification.sent_at | date:'dd/MM' }]}</span>*/
/*                                     <span class="news-item-month">{[{ notification.sent_at | date:'HH:mm' }]}</span>*/
/*                                 </div>*/
/*                                 <div class="news-item-detail">*/
/*                                     <span class="news-item-title">{[{ notification.title }]}</span>*/
/*                                     <p class="news-item-preview">{[{ notification.content }]}</p>*/
/*                                 </div>*/
/*                             </li>*/
/*                         </ul>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* */
