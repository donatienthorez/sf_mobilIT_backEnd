<?php

/* MainBundle:Guide:index.html.twig */
class __TwigTemplate_ff2d3c6f4bf96b925d7d7e3740b6f20b6daa55d8c94efc4d0d51039d4b03db6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MainBundle::base.html.twig", "MainBundle:Guide:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MainBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13dccc00c1fb01adb9107134b678d9a9bbd7c44645d0186c74bb7d7a100d103a = $this->env->getExtension("native_profiler");
        $__internal_13dccc00c1fb01adb9107134b678d9a9bbd7c44645d0186c74bb7d7a100d103a->enter($__internal_13dccc00c1fb01adb9107134b678d9a9bbd7c44645d0186c74bb7d7a100d103a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle:Guide:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_13dccc00c1fb01adb9107134b678d9a9bbd7c44645d0186c74bb7d7a100d103a->leave($__internal_13dccc00c1fb01adb9107134b678d9a9bbd7c44645d0186c74bb7d7a100d103a_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_e3cc3e7be4b0734cfbb44e4091e5701ec7492ead2fef68c8458fe6aace78d27f = $this->env->getExtension("native_profiler");
        $__internal_e3cc3e7be4b0734cfbb44e4091e5701ec7492ead2fef68c8458fe6aace78d27f->enter($__internal_e3cc3e7be4b0734cfbb44e4091e5701ec7492ead2fef68c8458fe6aace78d27f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <script type=\"text/ng-template\" id=\"nodes_renderer.html\">
        <div ui-tree-handle class=\"tree-node tree-node-content angular-ui-tree-handle\">
            <a class=\"btn btn-success btn-xs\" ng-if=\"node.nodes && node.nodes.length > 0\" data-nodrag ng-click=\"toggle(this)\"><span
                        class=\"glyphicon\"
                        ng-class=\"{
          'glyphicon-chevron-right': collapsed,
          'glyphicon-chevron-down': !collapsed
        }\"></span></a>
            {[{node.title}]}
            <a class=\"pull-right btn btn-danger btn-xs\" data-nodrag ng-click=\"remove(this)\"><span
                        class=\"glyphicon glyphicon-remove\"></span></a>
            <a class=\"pull-right btn btn-primary btn-xs\" data-nodrag ng-click=\"edit(this)\" style=\"margin-right: 8px;\"><span
                        class=\"glyphicon glyphicon-edit\"></span></a>
            <a class=\"pull-right btn btn-primary btn-xs\" data-nodrag ng-click=\"newSubItem(this)\" style=\"margin-right: 8px;\"><span
                        class=\"glyphicon glyphicon-plus\"></span></a>
        </div>
        <ol class=\"ng-pristine ng-untouched ng-valid ng-scope angular-ui-tree-nodes\" ui-tree-nodes=\"\" ng-model=\"node.nodes\" ng-class=\"{hidden: collapsed}\">
            <li ng-repeat=\"node in node.nodes\" ui-tree-node ng-include=\"'nodes_renderer.html'\">
            </li>
        </ol>
    </script>
    <div class=\"main-inner\" ng-controller=\"guideController\" ng-init=\"init()\">
        <div class=\"container\">
            <div class=\"span5\">
                <div class=\"widget\">
                    <div class=\"widget-header\">
                        <i class=\"icon-book\"></i>
                        <h3>Categories</h3>
                    </div>
                    <div class=\"widget-content\">
                        <div class=\"ng-scope angular-ui-tree\" ui-tree=\"treeOptions\" id=\"tree-root\">
                            <ol ui-tree-nodes class=\"ng-pristine ng-untouched ng-valid ng-scope angular-ui-tree-nodes\" ng-model=\"data\">
                                <li ng-repeat=\"node in data\" class=\"ng-scope angular-ui-tree-node\" ui-tree-node ng-include=\"'nodes_renderer.html'\"></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"span5\">
                <div class=\"widget\">
                    <div class=\"widget-header\">
                        <i class=\"icon-book\"></i>
                        <h3>Content</h3>
                    </div>
                    <div class=\"widget-content\">
                        {[{ categorieSelected.title }]}
                    </div>
                </div>
            </div>
            ";
        // line 53
        echo "                ";
        // line 54
        echo "                    ";
        // line 55
        echo "                        ";
        // line 56
        echo "                        ";
        // line 57
        echo "                    ";
        // line 58
        echo "                    ";
        // line 59
        echo "                    ";
        // line 60
        echo "                ";
        // line 61
        echo "            ";
        // line 62
        echo "        </div>
    </div>
";
        
        $__internal_e3cc3e7be4b0734cfbb44e4091e5701ec7492ead2fef68c8458fe6aace78d27f->leave($__internal_e3cc3e7be4b0734cfbb44e4091e5701ec7492ead2fef68c8458fe6aace78d27f_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle:Guide:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 62,  107 => 61,  105 => 60,  103 => 59,  101 => 58,  99 => 57,  97 => 56,  95 => 55,  93 => 54,  91 => 53,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'MainBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <script type="text/ng-template" id="nodes_renderer.html">*/
/*         <div ui-tree-handle class="tree-node tree-node-content angular-ui-tree-handle">*/
/*             <a class="btn btn-success btn-xs" ng-if="node.nodes && node.nodes.length > 0" data-nodrag ng-click="toggle(this)"><span*/
/*                         class="glyphicon"*/
/*                         ng-class="{*/
/*           'glyphicon-chevron-right': collapsed,*/
/*           'glyphicon-chevron-down': !collapsed*/
/*         }"></span></a>*/
/*             {[{node.title}]}*/
/*             <a class="pull-right btn btn-danger btn-xs" data-nodrag ng-click="remove(this)"><span*/
/*                         class="glyphicon glyphicon-remove"></span></a>*/
/*             <a class="pull-right btn btn-primary btn-xs" data-nodrag ng-click="edit(this)" style="margin-right: 8px;"><span*/
/*                         class="glyphicon glyphicon-edit"></span></a>*/
/*             <a class="pull-right btn btn-primary btn-xs" data-nodrag ng-click="newSubItem(this)" style="margin-right: 8px;"><span*/
/*                         class="glyphicon glyphicon-plus"></span></a>*/
/*         </div>*/
/*         <ol class="ng-pristine ng-untouched ng-valid ng-scope angular-ui-tree-nodes" ui-tree-nodes="" ng-model="node.nodes" ng-class="{hidden: collapsed}">*/
/*             <li ng-repeat="node in node.nodes" ui-tree-node ng-include="'nodes_renderer.html'">*/
/*             </li>*/
/*         </ol>*/
/*     </script>*/
/*     <div class="main-inner" ng-controller="guideController" ng-init="init()">*/
/*         <div class="container">*/
/*             <div class="span5">*/
/*                 <div class="widget">*/
/*                     <div class="widget-header">*/
/*                         <i class="icon-book"></i>*/
/*                         <h3>Categories</h3>*/
/*                     </div>*/
/*                     <div class="widget-content">*/
/*                         <div class="ng-scope angular-ui-tree" ui-tree="treeOptions" id="tree-root">*/
/*                             <ol ui-tree-nodes class="ng-pristine ng-untouched ng-valid ng-scope angular-ui-tree-nodes" ng-model="data">*/
/*                                 <li ng-repeat="node in data" class="ng-scope angular-ui-tree-node" ui-tree-node ng-include="'nodes_renderer.html'"></li>*/
/*                             </ol>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             <div class="span5">*/
/*                 <div class="widget">*/
/*                     <div class="widget-header">*/
/*                         <i class="icon-book"></i>*/
/*                         <h3>Content</h3>*/
/*                     </div>*/
/*                     <div class="widget-content">*/
/*                         {[{ categorieSelected.title }]}*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             {#<div class="span3">#}*/
/*                 {#<div class="widget">#}*/
/*                     {#<div class="widget-header">#}*/
/*                         {#<i class="icon-book"></i>#}*/
/*                         {#<h3>Items</h3>#}*/
/*                     {#</div>#}*/
/*                     {#<div class="widget-content">#}*/
/*                     {#</div>#}*/
/*                 {#</div>#}*/
/*             {#</div>#}*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
