<?php

/* MainBundle:Guide:index.html.twig */
class __TwigTemplate_ff2d3c6f4bf96b925d7d7e3740b6f20b6daa55d8c94efc4d0d51039d4b03db6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MainBundle::base.html.twig", "MainBundle:Guide:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MainBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e5cf87d110310d722046f293623428b644bf60210d1f4a85bba35e4c8791d3dd = $this->env->getExtension("native_profiler");
        $__internal_e5cf87d110310d722046f293623428b644bf60210d1f4a85bba35e4c8791d3dd->enter($__internal_e5cf87d110310d722046f293623428b644bf60210d1f4a85bba35e4c8791d3dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle:Guide:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e5cf87d110310d722046f293623428b644bf60210d1f4a85bba35e4c8791d3dd->leave($__internal_e5cf87d110310d722046f293623428b644bf60210d1f4a85bba35e4c8791d3dd_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_ebba94dee9b40e03a148a729d951eb5803736c82b1e24971c41bcedc0ca063b7 = $this->env->getExtension("native_profiler");
        $__internal_ebba94dee9b40e03a148a729d951eb5803736c82b1e24971c41bcedc0ca063b7->enter($__internal_ebba94dee9b40e03a148a729d951eb5803736c82b1e24971c41bcedc0ca063b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <script type=\"text/ng-template\" id=\"nodes_renderer.html\">
        <div ui-tree-handle class=\"tree-node tree-node-content angular-ui-tree-handle\">
            <a class=\"btn btn-success btn-xs\" ng-if=\"node.nodes && node.nodes.length > 0\" data-nodrag ng-click=\"toggle(this)\"><span
                        class=\"glyphicon\"
                        ng-class=\"{
          'glyphicon-chevron-right': collapsed,
          'glyphicon-chevron-down': !collapsed
        }\"></span></a>
            {[{node.title}]}
            <a class=\"pull-right btn btn-danger btn-xs\" data-nodrag ng-click=\"delete(this)\"><span
                        class=\"glyphicon glyphicon-remove\"></span></a>
            <a class=\"pull-right btn btn-primary btn-xs\" data-nodrag ng-click=\"edit(this)\" style=\"margin-right: 8px;\"><span
                        class=\"glyphicon glyphicon-edit\"></span></a>
            <a class=\"pull-right btn btn-primary btn-xs\" ng-hide=\"depth()>2\" data-nodrag ng-click=\"newSubItem(this)\" style=\"margin-right: 8px;\"><span
                        class=\"glyphicon glyphicon-plus\"></span></a>
        </div>
        <ol class=\"ng-pristine ng-untouched ng-valid ng-scope angular-ui-tree-nodes\" ui-tree-nodes=\"\" ng-model=\"node.nodes\" ng-class=\"{hidden: collapsed}\">
            <li ng-repeat=\"node in node.nodes\" ui-tree-node ng-include=\"'nodes_renderer.html'\">
            </li>
        </ol>
    </script>
    <div class=\"main-inner\" ng-controller=\"guideController\" ng-init=\"init()\">
        <div class=\"container\">
            <div class=\"span5\">
                <div class=\"widget\">
                    <div class=\"widget-header\">
                        <i class=\"icon-book\"></i>
                        <h3>Categories</h3>
                            <span>
                                <button class=\"btn btn-default\" type=\"button\" ng-click=\"addToRoot()\">Add Category</button>
                            </span>
                            <span>
                                <div class=\"onoffswitch\">
                                    <input name=\"onoffswitch\" class=\"onoffswitch-checkbox ng-pristine ng-untouched ng-valid\" id=\"myonoffswitch\" ng-model=\"activated\" ng-change=\"changeGuideStatus()\" type=\"checkbox\">
                                    <label class=\"onoffswitch-label\" for=\"myonoffswitch\">
                                        <span class=\"onoffswitch-inner\"></span>
                                        <span class=\"onoffswitch-switch\"></span>
                                    </label>
                                </div>
                            </span>
                    </div>

                    <div class=\"widget-content\">
                        <div class=\"ng-scope angular-ui-tree\" ui-tree=\"treeOptions\" id=\"tree-root\" data-max-depth=\"3\">
                            <ol ui-tree-nodes class=\"ng-pristine ng-untouched ng-valid ng-scope angular-ui-tree-nodes\" ng-model=\"data\">
                                <li ng-repeat=\"node in data\" class=\"ng-scope angular-ui-tree-node\" ui-tree-node ng-include=\"'nodes_renderer.html'\"></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"span5\">
                <div class=\"widget\">
                    <div class=\"widget-header\">
                        <i class=\"icon-book\"></i>
                        <h3>Content</h3>
                        <input ng-if=\"categorieSelected.title\" class=\"btn btn-default\" value=\"Save\" type=\"submit\" ng-click=\"save()\">
                    </div>
                    <div class=\"widget-content\">
                        <div ng-if=\"categorieSelected.title\" class=\"ng-scope\">
                            <input type=\"hidden\" name=\"id\" required=\"\" id=\"id\" value=\"35\">
                            <label for=\"title\">Title :</label>
                            <input type=\"text\" name=\"title\" required=\"\" id=\"name\" ng-model=\"categorieSelected.title\" class=\"ng-pristine ng-valid ng-valid-required ng-touched\"><br>
                            <label for=\"content\">Content :</label>
                            <textarea ckeditor=\"editorOptions\" ng-model=\"categorieSelected.content\"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            ";
        // line 73
        echo "                ";
        // line 74
        echo "                    ";
        // line 75
        echo "                        ";
        // line 76
        echo "                        ";
        // line 77
        echo "                    ";
        // line 78
        echo "                    ";
        // line 79
        echo "                    ";
        // line 80
        echo "                ";
        // line 81
        echo "            ";
        // line 82
        echo "        </div>
    </div>
";
        
        $__internal_ebba94dee9b40e03a148a729d951eb5803736c82b1e24971c41bcedc0ca063b7->leave($__internal_ebba94dee9b40e03a148a729d951eb5803736c82b1e24971c41bcedc0ca063b7_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle:Guide:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 82,  127 => 81,  125 => 80,  123 => 79,  121 => 78,  119 => 77,  117 => 76,  115 => 75,  113 => 74,  111 => 73,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'MainBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <script type="text/ng-template" id="nodes_renderer.html">*/
/*         <div ui-tree-handle class="tree-node tree-node-content angular-ui-tree-handle">*/
/*             <a class="btn btn-success btn-xs" ng-if="node.nodes && node.nodes.length > 0" data-nodrag ng-click="toggle(this)"><span*/
/*                         class="glyphicon"*/
/*                         ng-class="{*/
/*           'glyphicon-chevron-right': collapsed,*/
/*           'glyphicon-chevron-down': !collapsed*/
/*         }"></span></a>*/
/*             {[{node.title}]}*/
/*             <a class="pull-right btn btn-danger btn-xs" data-nodrag ng-click="delete(this)"><span*/
/*                         class="glyphicon glyphicon-remove"></span></a>*/
/*             <a class="pull-right btn btn-primary btn-xs" data-nodrag ng-click="edit(this)" style="margin-right: 8px;"><span*/
/*                         class="glyphicon glyphicon-edit"></span></a>*/
/*             <a class="pull-right btn btn-primary btn-xs" ng-hide="depth()>2" data-nodrag ng-click="newSubItem(this)" style="margin-right: 8px;"><span*/
/*                         class="glyphicon glyphicon-plus"></span></a>*/
/*         </div>*/
/*         <ol class="ng-pristine ng-untouched ng-valid ng-scope angular-ui-tree-nodes" ui-tree-nodes="" ng-model="node.nodes" ng-class="{hidden: collapsed}">*/
/*             <li ng-repeat="node in node.nodes" ui-tree-node ng-include="'nodes_renderer.html'">*/
/*             </li>*/
/*         </ol>*/
/*     </script>*/
/*     <div class="main-inner" ng-controller="guideController" ng-init="init()">*/
/*         <div class="container">*/
/*             <div class="span5">*/
/*                 <div class="widget">*/
/*                     <div class="widget-header">*/
/*                         <i class="icon-book"></i>*/
/*                         <h3>Categories</h3>*/
/*                             <span>*/
/*                                 <button class="btn btn-default" type="button" ng-click="addToRoot()">Add Category</button>*/
/*                             </span>*/
/*                             <span>*/
/*                                 <div class="onoffswitch">*/
/*                                     <input name="onoffswitch" class="onoffswitch-checkbox ng-pristine ng-untouched ng-valid" id="myonoffswitch" ng-model="activated" ng-change="changeGuideStatus()" type="checkbox">*/
/*                                     <label class="onoffswitch-label" for="myonoffswitch">*/
/*                                         <span class="onoffswitch-inner"></span>*/
/*                                         <span class="onoffswitch-switch"></span>*/
/*                                     </label>*/
/*                                 </div>*/
/*                             </span>*/
/*                     </div>*/
/* */
/*                     <div class="widget-content">*/
/*                         <div class="ng-scope angular-ui-tree" ui-tree="treeOptions" id="tree-root" data-max-depth="3">*/
/*                             <ol ui-tree-nodes class="ng-pristine ng-untouched ng-valid ng-scope angular-ui-tree-nodes" ng-model="data">*/
/*                                 <li ng-repeat="node in data" class="ng-scope angular-ui-tree-node" ui-tree-node ng-include="'nodes_renderer.html'"></li>*/
/*                             </ol>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             <div class="span5">*/
/*                 <div class="widget">*/
/*                     <div class="widget-header">*/
/*                         <i class="icon-book"></i>*/
/*                         <h3>Content</h3>*/
/*                         <input ng-if="categorieSelected.title" class="btn btn-default" value="Save" type="submit" ng-click="save()">*/
/*                     </div>*/
/*                     <div class="widget-content">*/
/*                         <div ng-if="categorieSelected.title" class="ng-scope">*/
/*                             <input type="hidden" name="id" required="" id="id" value="35">*/
/*                             <label for="title">Title :</label>*/
/*                             <input type="text" name="title" required="" id="name" ng-model="categorieSelected.title" class="ng-pristine ng-valid ng-valid-required ng-touched"><br>*/
/*                             <label for="content">Content :</label>*/
/*                             <textarea ckeditor="editorOptions" ng-model="categorieSelected.content"></textarea>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             {#<div class="span3">#}*/
/*                 {#<div class="widget">#}*/
/*                     {#<div class="widget-header">#}*/
/*                         {#<i class="icon-book"></i>#}*/
/*                         {#<h3>Items</h3>#}*/
/*                     {#</div>#}*/
/*                     {#<div class="widget-content">#}*/
/*                     {#</div>#}*/
/*                 {#</div>#}*/
/*             {#</div>#}*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
