<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_41dc90b35a7f7e1002e495320b1a701c2f7cf9f3f55d74d449aa81b5a39552f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a90ca6ed0a3dc371980385fe1a20c7ffe8b2a890791ede214d548390990f8a0f = $this->env->getExtension("native_profiler");
        $__internal_a90ca6ed0a3dc371980385fe1a20c7ffe8b2a890791ede214d548390990f8a0f->enter($__internal_a90ca6ed0a3dc371980385fe1a20c7ffe8b2a890791ede214d548390990f8a0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_a90ca6ed0a3dc371980385fe1a20c7ffe8b2a890791ede214d548390990f8a0f->leave($__internal_a90ca6ed0a3dc371980385fe1a20c7ffe8b2a890791ede214d548390990f8a0f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
