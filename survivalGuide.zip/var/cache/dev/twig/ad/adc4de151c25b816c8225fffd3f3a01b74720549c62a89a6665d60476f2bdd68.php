<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_41dc90b35a7f7e1002e495320b1a701c2f7cf9f3f55d74d449aa81b5a39552f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8eba5b3fa332e5b0d7ef01293fe81a646762ad4d9f4df9f3c6610596be118b09 = $this->env->getExtension("native_profiler");
        $__internal_8eba5b3fa332e5b0d7ef01293fe81a646762ad4d9f4df9f3c6610596be118b09->enter($__internal_8eba5b3fa332e5b0d7ef01293fe81a646762ad4d9f4df9f3c6610596be118b09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_8eba5b3fa332e5b0d7ef01293fe81a646762ad4d9f4df9f3c6610596be118b09->leave($__internal_8eba5b3fa332e5b0d7ef01293fe81a646762ad4d9f4df9f3c6610596be118b09_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
