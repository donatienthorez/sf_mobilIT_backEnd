<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_c27acdd28ae6d86a44a6a28f5b11892eb140b4d1747a605ad45ffd46da7769c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d018550eecdf1770ee45a2e3dd7665085c91de2b4722e77e7eb1bf1ccd61e647 = $this->env->getExtension("native_profiler");
        $__internal_d018550eecdf1770ee45a2e3dd7665085c91de2b4722e77e7eb1bf1ccd61e647->enter($__internal_d018550eecdf1770ee45a2e3dd7665085c91de2b4722e77e7eb1bf1ccd61e647_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_d018550eecdf1770ee45a2e3dd7665085c91de2b4722e77e7eb1bf1ccd61e647->leave($__internal_d018550eecdf1770ee45a2e3dd7665085c91de2b4722e77e7eb1bf1ccd61e647_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
