<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_57e22418020f80218e84e748f64b3605908369d423d458e1ca19559f2def60e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa7da5770f458b0aad71f57fb4a26c51fc4e2d9114ed9eb2dfa6948e75c28616 = $this->env->getExtension("native_profiler");
        $__internal_aa7da5770f458b0aad71f57fb4a26c51fc4e2d9114ed9eb2dfa6948e75c28616->enter($__internal_aa7da5770f458b0aad71f57fb4a26c51fc4e2d9114ed9eb2dfa6948e75c28616_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_aa7da5770f458b0aad71f57fb4a26c51fc4e2d9114ed9eb2dfa6948e75c28616->leave($__internal_aa7da5770f458b0aad71f57fb4a26c51fc4e2d9114ed9eb2dfa6948e75c28616_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
