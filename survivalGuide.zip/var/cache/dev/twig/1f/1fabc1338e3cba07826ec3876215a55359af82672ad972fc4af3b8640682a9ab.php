<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_57e22418020f80218e84e748f64b3605908369d423d458e1ca19559f2def60e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a95d406ad00576597f5fdb17073f305e0c7634b86ac74c1b4c5e2772c5437130 = $this->env->getExtension("native_profiler");
        $__internal_a95d406ad00576597f5fdb17073f305e0c7634b86ac74c1b4c5e2772c5437130->enter($__internal_a95d406ad00576597f5fdb17073f305e0c7634b86ac74c1b4c5e2772c5437130_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_a95d406ad00576597f5fdb17073f305e0c7634b86ac74c1b4c5e2772c5437130->leave($__internal_a95d406ad00576597f5fdb17073f305e0c7634b86ac74c1b4c5e2772c5437130_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
