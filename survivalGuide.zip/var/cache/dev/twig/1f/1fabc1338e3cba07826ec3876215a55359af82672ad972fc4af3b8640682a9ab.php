<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_57e22418020f80218e84e748f64b3605908369d423d458e1ca19559f2def60e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_965788e269b06400c5056c345b0f5f9487b249c57079ab97029f80bcb6874e60 = $this->env->getExtension("native_profiler");
        $__internal_965788e269b06400c5056c345b0f5f9487b249c57079ab97029f80bcb6874e60->enter($__internal_965788e269b06400c5056c345b0f5f9487b249c57079ab97029f80bcb6874e60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_965788e269b06400c5056c345b0f5f9487b249c57079ab97029f80bcb6874e60->leave($__internal_965788e269b06400c5056c345b0f5f9487b249c57079ab97029f80bcb6874e60_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
