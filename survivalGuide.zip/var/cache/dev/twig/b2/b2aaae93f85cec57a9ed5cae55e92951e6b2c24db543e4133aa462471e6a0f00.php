<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_cd523995c96b26dbe576438095beb0de745de03d7f53b7a892590289fe8fd018 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ea9ddd861c68c8843804686db50cc6873686d343d2462c5149a6a43724bf5e0 = $this->env->getExtension("native_profiler");
        $__internal_5ea9ddd861c68c8843804686db50cc6873686d343d2462c5149a6a43724bf5e0->enter($__internal_5ea9ddd861c68c8843804686db50cc6873686d343d2462c5149a6a43724bf5e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_5ea9ddd861c68c8843804686db50cc6873686d343d2462c5149a6a43724bf5e0->leave($__internal_5ea9ddd861c68c8843804686db50cc6873686d343d2462c5149a6a43724bf5e0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
