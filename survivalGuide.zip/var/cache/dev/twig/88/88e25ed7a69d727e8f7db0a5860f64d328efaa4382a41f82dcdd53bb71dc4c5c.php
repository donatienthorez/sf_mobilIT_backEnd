<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_b291b87175326d39f524f678e7f03faf185d84c53cd59a7c8291151d0f9e449c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e4ee968a8604ae487bf5c1565817b22088880bc6d2a3ec13ea097d49b1b0f63e = $this->env->getExtension("native_profiler");
        $__internal_e4ee968a8604ae487bf5c1565817b22088880bc6d2a3ec13ea097d49b1b0f63e->enter($__internal_e4ee968a8604ae487bf5c1565817b22088880bc6d2a3ec13ea097d49b1b0f63e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_e4ee968a8604ae487bf5c1565817b22088880bc6d2a3ec13ea097d49b1b0f63e->leave($__internal_e4ee968a8604ae487bf5c1565817b22088880bc6d2a3ec13ea097d49b1b0f63e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
