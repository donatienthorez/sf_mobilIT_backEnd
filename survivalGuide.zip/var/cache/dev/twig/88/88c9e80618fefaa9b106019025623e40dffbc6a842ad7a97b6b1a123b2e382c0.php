<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_c8ccc3f4291abc1c677701dc08cf5eb8e504c6bd4a2eed2afd659d0ac428ecea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_381804fba43634295434d73135f8aa24b0129343570885bb7213a0124e76e4f4 = $this->env->getExtension("native_profiler");
        $__internal_381804fba43634295434d73135f8aa24b0129343570885bb7213a0124e76e4f4->enter($__internal_381804fba43634295434d73135f8aa24b0129343570885bb7213a0124e76e4f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_381804fba43634295434d73135f8aa24b0129343570885bb7213a0124e76e4f4->leave($__internal_381804fba43634295434d73135f8aa24b0129343570885bb7213a0124e76e4f4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
