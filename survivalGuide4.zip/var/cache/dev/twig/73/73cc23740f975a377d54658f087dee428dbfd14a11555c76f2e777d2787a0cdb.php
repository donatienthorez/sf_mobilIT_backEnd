<?php

/* MainBundle:Guide:index.html.twig */
class __TwigTemplate_ff2d3c6f4bf96b925d7d7e3740b6f20b6daa55d8c94efc4d0d51039d4b03db6c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("MainBundle::base.html.twig", "MainBundle:Guide:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "MainBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_37464209c269d9bbcdd028c9e0ab4013ee1d0c77b1ed93f663140fa7861dee08 = $this->env->getExtension("native_profiler");
        $__internal_37464209c269d9bbcdd028c9e0ab4013ee1d0c77b1ed93f663140fa7861dee08->enter($__internal_37464209c269d9bbcdd028c9e0ab4013ee1d0c77b1ed93f663140fa7861dee08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle:Guide:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_37464209c269d9bbcdd028c9e0ab4013ee1d0c77b1ed93f663140fa7861dee08->leave($__internal_37464209c269d9bbcdd028c9e0ab4013ee1d0c77b1ed93f663140fa7861dee08_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_e2766ec6e4ab181dabd497d586e8be10f0264a9eba167e1dbcd0da09e58608b6 = $this->env->getExtension("native_profiler");
        $__internal_e2766ec6e4ab181dabd497d586e8be10f0264a9eba167e1dbcd0da09e58608b6->enter($__internal_e2766ec6e4ab181dabd497d586e8be10f0264a9eba167e1dbcd0da09e58608b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_e2766ec6e4ab181dabd497d586e8be10f0264a9eba167e1dbcd0da09e58608b6->leave($__internal_e2766ec6e4ab181dabd497d586e8be10f0264a9eba167e1dbcd0da09e58608b6_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle:Guide:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 2,  11 => 1,);
    }
}
/* {% extends 'MainBundle::base.html.twig' %}*/
/* {% block body %}*/
/* {% endblock %}*/
