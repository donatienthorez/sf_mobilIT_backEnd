<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_221566fc8f77f967eabbc55ce86251880c28df409a56d25e0d8bbb4d8d2805e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_768c80ab9f97eedd1775bbd10744977639d52e77a16f5af5c873f4a69a4df26c = $this->env->getExtension("native_profiler");
        $__internal_768c80ab9f97eedd1775bbd10744977639d52e77a16f5af5c873f4a69a4df26c->enter($__internal_768c80ab9f97eedd1775bbd10744977639d52e77a16f5af5c873f4a69a4df26c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_768c80ab9f97eedd1775bbd10744977639d52e77a16f5af5c873f4a69a4df26c->leave($__internal_768c80ab9f97eedd1775bbd10744977639d52e77a16f5af5c873f4a69a4df26c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
