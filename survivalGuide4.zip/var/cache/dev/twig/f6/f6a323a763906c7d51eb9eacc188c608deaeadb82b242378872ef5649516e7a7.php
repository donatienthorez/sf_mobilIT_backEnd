<?php

/* FOSUserBundle:Resetting:checkEmail.html.twig */
class __TwigTemplate_fe0db8f5a55d779c072d31f0fc95f6d52995e9ea9d2ab1ef9e73d271e55f5d26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c72137fc90be577f6a82f73ae4c33d0d147b5e28f539d30b4f345c961c2e9243 = $this->env->getExtension("native_profiler");
        $__internal_c72137fc90be577f6a82f73ae4c33d0d147b5e28f539d30b4f345c961c2e9243->enter($__internal_c72137fc90be577f6a82f73ae4c33d0d147b5e28f539d30b4f345c961c2e9243_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c72137fc90be577f6a82f73ae4c33d0d147b5e28f539d30b4f345c961c2e9243->leave($__internal_c72137fc90be577f6a82f73ae4c33d0d147b5e28f539d30b4f345c961c2e9243_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_64c22a32521cc909835e46649c8078de34f7aed875a74a657d52c91ae976977a = $this->env->getExtension("native_profiler");
        $__internal_64c22a32521cc909835e46649c8078de34f7aed875a74a657d52c91ae976977a->enter($__internal_64c22a32521cc909835e46649c8078de34f7aed875a74a657d52c91ae976977a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.check_email", array("%email%" => (isset($context["email"]) ? $context["email"] : $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "
</p>
";
        
        $__internal_64c22a32521cc909835e46649c8078de34f7aed875a74a657d52c91ae976977a->leave($__internal_64c22a32521cc909835e46649c8078de34f7aed875a74a657d52c91ae976977a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>*/
/* {{ 'resetting.check_email'|trans({'%email%': email}) }}*/
/* </p>*/
/* {% endblock %}*/
/* */
