<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_024a8d03591cfe2f94bd9edd4f5a17b80ace794cc8b1ac13381dcb8a0b7367cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d3005e07f80f210b0dda2930b5b64d46efefbb75f1a51059597bbad67175d69e = $this->env->getExtension("native_profiler");
        $__internal_d3005e07f80f210b0dda2930b5b64d46efefbb75f1a51059597bbad67175d69e->enter($__internal_d3005e07f80f210b0dda2930b5b64d46efefbb75f1a51059597bbad67175d69e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d3005e07f80f210b0dda2930b5b64d46efefbb75f1a51059597bbad67175d69e->leave($__internal_d3005e07f80f210b0dda2930b5b64d46efefbb75f1a51059597bbad67175d69e_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4e4ff6099729c0723fabd455118b06192150fc619aa4ebf1f4c72ea0fddfaba8 = $this->env->getExtension("native_profiler");
        $__internal_4e4ff6099729c0723fabd455118b06192150fc619aa4ebf1f4c72ea0fddfaba8->enter($__internal_4e4ff6099729c0723fabd455118b06192150fc619aa4ebf1f4c72ea0fddfaba8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_4e4ff6099729c0723fabd455118b06192150fc619aa4ebf1f4c72ea0fddfaba8->leave($__internal_4e4ff6099729c0723fabd455118b06192150fc619aa4ebf1f4c72ea0fddfaba8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
