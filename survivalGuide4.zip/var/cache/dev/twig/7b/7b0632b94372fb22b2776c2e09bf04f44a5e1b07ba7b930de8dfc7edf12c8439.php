<?php

/* FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig */
class __TwigTemplate_8ddff223eceee0196c6ca6a26f0aa8a09d15b9bf2017d2252c78bdcc777ac149 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae1146cb10bad173c70769c63c23bca6cf70a98dfaa324d7e444e14b13827294 = $this->env->getExtension("native_profiler");
        $__internal_ae1146cb10bad173c70769c63c23bca6cf70a98dfaa324d7e444e14b13827294->enter($__internal_ae1146cb10bad173c70769c63c23bca6cf70a98dfaa324d7e444e14b13827294_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ae1146cb10bad173c70769c63c23bca6cf70a98dfaa324d7e444e14b13827294->leave($__internal_ae1146cb10bad173c70769c63c23bca6cf70a98dfaa324d7e444e14b13827294_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_8280517b8565cabb8173ee2a231aaa6dc655d0b15d9dc9df41710eca0cf7bf37 = $this->env->getExtension("native_profiler");
        $__internal_8280517b8565cabb8173ee2a231aaa6dc655d0b15d9dc9df41710eca0cf7bf37->enter($__internal_8280517b8565cabb8173ee2a231aaa6dc655d0b15d9dc9df41710eca0cf7bf37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_8280517b8565cabb8173ee2a231aaa6dc655d0b15d9dc9df41710eca0cf7bf37->leave($__internal_8280517b8565cabb8173ee2a231aaa6dc655d0b15d9dc9df41710eca0cf7bf37_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
