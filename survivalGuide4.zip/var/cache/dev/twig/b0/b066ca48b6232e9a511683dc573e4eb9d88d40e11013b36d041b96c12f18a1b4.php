<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_bb6762351bc7a81fc435dcfd76dd032cd416fc8f3efa73a2f669c777393f95cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_775fb8f0911687c712b3defdade4e4e66f8d6740b83224c03ddb559289207a0c = $this->env->getExtension("native_profiler");
        $__internal_775fb8f0911687c712b3defdade4e4e66f8d6740b83224c03ddb559289207a0c->enter($__internal_775fb8f0911687c712b3defdade4e4e66f8d6740b83224c03ddb559289207a0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_775fb8f0911687c712b3defdade4e4e66f8d6740b83224c03ddb559289207a0c->leave($__internal_775fb8f0911687c712b3defdade4e4e66f8d6740b83224c03ddb559289207a0c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
