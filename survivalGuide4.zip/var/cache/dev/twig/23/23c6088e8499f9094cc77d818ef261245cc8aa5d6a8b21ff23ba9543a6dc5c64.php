<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_f2547324f09635cfe47b93ad6f7cf18b249626a38cd498e5eba060f07fc2dd4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_61e0980dae2c41cadf920b3f9fe9fefa706133fc574e5f094c0a06a44bd18c58 = $this->env->getExtension("native_profiler");
        $__internal_61e0980dae2c41cadf920b3f9fe9fefa706133fc574e5f094c0a06a44bd18c58->enter($__internal_61e0980dae2c41cadf920b3f9fe9fefa706133fc574e5f094c0a06a44bd18c58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_61e0980dae2c41cadf920b3f9fe9fefa706133fc574e5f094c0a06a44bd18c58->leave($__internal_61e0980dae2c41cadf920b3f9fe9fefa706133fc574e5f094c0a06a44bd18c58_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_9498ee62cc91755f67557d52cab45e8990d6508eab385967d418a3f5a2ac3b04 = $this->env->getExtension("native_profiler");
        $__internal_9498ee62cc91755f67557d52cab45e8990d6508eab385967d418a3f5a2ac3b04->enter($__internal_9498ee62cc91755f67557d52cab45e8990d6508eab385967d418a3f5a2ac3b04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_9498ee62cc91755f67557d52cab45e8990d6508eab385967d418a3f5a2ac3b04->leave($__internal_9498ee62cc91755f67557d52cab45e8990d6508eab385967d418a3f5a2ac3b04_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_d17581005cc9a375b092f53207f0cdf19797790beb046e140129d1c88e5e9208 = $this->env->getExtension("native_profiler");
        $__internal_d17581005cc9a375b092f53207f0cdf19797790beb046e140129d1c88e5e9208->enter($__internal_d17581005cc9a375b092f53207f0cdf19797790beb046e140129d1c88e5e9208_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_d17581005cc9a375b092f53207f0cdf19797790beb046e140129d1c88e5e9208->leave($__internal_d17581005cc9a375b092f53207f0cdf19797790beb046e140129d1c88e5e9208_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
