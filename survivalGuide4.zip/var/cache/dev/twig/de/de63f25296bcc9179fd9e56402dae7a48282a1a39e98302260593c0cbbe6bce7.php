<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_99c8d7eba8b83bbd00375d5c77f69fa4c7c6ca1973202e4011507d0fb9e7de11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bfa89dcb262cc04fb06bdcd6b72d63370bfca6a06889e3587c448cc050dc8593 = $this->env->getExtension("native_profiler");
        $__internal_bfa89dcb262cc04fb06bdcd6b72d63370bfca6a06889e3587c448cc050dc8593->enter($__internal_bfa89dcb262cc04fb06bdcd6b72d63370bfca6a06889e3587c448cc050dc8593_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_bfa89dcb262cc04fb06bdcd6b72d63370bfca6a06889e3587c448cc050dc8593->leave($__internal_bfa89dcb262cc04fb06bdcd6b72d63370bfca6a06889e3587c448cc050dc8593_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
