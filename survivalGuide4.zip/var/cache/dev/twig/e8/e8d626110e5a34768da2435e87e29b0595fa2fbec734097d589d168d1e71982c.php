<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_0f3f102a36e0820baeac7adaeade4f3b106e07792ec0e6fabdaa1c1912d3f908 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9da1938d9c84b8dc5bd4bb8ea651c24e90689984bd8aa02e96b823e0fec90af2 = $this->env->getExtension("native_profiler");
        $__internal_9da1938d9c84b8dc5bd4bb8ea651c24e90689984bd8aa02e96b823e0fec90af2->enter($__internal_9da1938d9c84b8dc5bd4bb8ea651c24e90689984bd8aa02e96b823e0fec90af2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_9da1938d9c84b8dc5bd4bb8ea651c24e90689984bd8aa02e96b823e0fec90af2->leave($__internal_9da1938d9c84b8dc5bd4bb8ea651c24e90689984bd8aa02e96b823e0fec90af2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */
