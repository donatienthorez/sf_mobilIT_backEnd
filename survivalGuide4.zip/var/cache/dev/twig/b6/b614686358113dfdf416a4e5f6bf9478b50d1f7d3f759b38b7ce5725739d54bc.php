<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_8d07e55f849b1b8078cc74da932e58be6f59e2ec6b78905c19342897e31133c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7aa5973aa97a6cc4c241e14b30d9b76df551ba81e615c6c15d618e3f78f98af6 = $this->env->getExtension("native_profiler");
        $__internal_7aa5973aa97a6cc4c241e14b30d9b76df551ba81e615c6c15d618e3f78f98af6->enter($__internal_7aa5973aa97a6cc4c241e14b30d9b76df551ba81e615c6c15d618e3f78f98af6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_7aa5973aa97a6cc4c241e14b30d9b76df551ba81e615c6c15d618e3f78f98af6->leave($__internal_7aa5973aa97a6cc4c241e14b30d9b76df551ba81e615c6c15d618e3f78f98af6_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_37ac8d7bbb25e0284f0a0459366dd68c76ca81759836e7685442f3654f5ad8bf = $this->env->getExtension("native_profiler");
        $__internal_37ac8d7bbb25e0284f0a0459366dd68c76ca81759836e7685442f3654f5ad8bf->enter($__internal_37ac8d7bbb25e0284f0a0459366dd68c76ca81759836e7685442f3654f5ad8bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_37ac8d7bbb25e0284f0a0459366dd68c76ca81759836e7685442f3654f5ad8bf->leave($__internal_37ac8d7bbb25e0284f0a0459366dd68c76ca81759836e7685442f3654f5ad8bf_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
