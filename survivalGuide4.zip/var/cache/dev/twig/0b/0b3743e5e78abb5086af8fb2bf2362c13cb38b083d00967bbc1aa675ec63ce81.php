<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_c27acdd28ae6d86a44a6a28f5b11892eb140b4d1747a605ad45ffd46da7769c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3961dd929bd22d6c9d22b66dece92a35893aa12a24606286d92c48df32aa5622 = $this->env->getExtension("native_profiler");
        $__internal_3961dd929bd22d6c9d22b66dece92a35893aa12a24606286d92c48df32aa5622->enter($__internal_3961dd929bd22d6c9d22b66dece92a35893aa12a24606286d92c48df32aa5622_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_3961dd929bd22d6c9d22b66dece92a35893aa12a24606286d92c48df32aa5622->leave($__internal_3961dd929bd22d6c9d22b66dece92a35893aa12a24606286d92c48df32aa5622_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
