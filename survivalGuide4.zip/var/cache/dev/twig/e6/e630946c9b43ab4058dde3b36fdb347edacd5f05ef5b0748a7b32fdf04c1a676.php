<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_ea923cbfb32920843e568747b6b3c5482c24e01ee7db5a98e662e67a0932ba8d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b357a6585326e49cd5f2e52b12c01498a9e0ff46b814db2979c5f4855d996978 = $this->env->getExtension("native_profiler");
        $__internal_b357a6585326e49cd5f2e52b12c01498a9e0ff46b814db2979c5f4855d996978->enter($__internal_b357a6585326e49cd5f2e52b12c01498a9e0ff46b814db2979c5f4855d996978_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_b357a6585326e49cd5f2e52b12c01498a9e0ff46b814db2979c5f4855d996978->leave($__internal_b357a6585326e49cd5f2e52b12c01498a9e0ff46b814db2979c5f4855d996978_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
