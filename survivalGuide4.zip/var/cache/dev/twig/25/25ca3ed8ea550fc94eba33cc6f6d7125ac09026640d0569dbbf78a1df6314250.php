<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_5361bfd9f0866dd8d801ad0a803fc0e713d117fa1c8192881755387f40bb8ba0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ac28576465289a873267ad0e99714bced90c13ad4f153d51f4d6d97fd085971 = $this->env->getExtension("native_profiler");
        $__internal_3ac28576465289a873267ad0e99714bced90c13ad4f153d51f4d6d97fd085971->enter($__internal_3ac28576465289a873267ad0e99714bced90c13ad4f153d51f4d6d97fd085971_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_3ac28576465289a873267ad0e99714bced90c13ad4f153d51f4d6d97fd085971->leave($__internal_3ac28576465289a873267ad0e99714bced90c13ad4f153d51f4d6d97fd085971_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
