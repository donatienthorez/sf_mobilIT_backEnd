<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_d8bc8d0563e5f28b78d721d6ac8bf6d8d65e563dcf8e5c82aa02fbc80d732e3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_77238830a0a4379ddf082e709c64cca81b30a53713f39bef324b5eba505c7495 = $this->env->getExtension("native_profiler");
        $__internal_77238830a0a4379ddf082e709c64cca81b30a53713f39bef324b5eba505c7495->enter($__internal_77238830a0a4379ddf082e709c64cca81b30a53713f39bef324b5eba505c7495_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_77238830a0a4379ddf082e709c64cca81b30a53713f39bef324b5eba505c7495->leave($__internal_77238830a0a4379ddf082e709c64cca81b30a53713f39bef324b5eba505c7495_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
