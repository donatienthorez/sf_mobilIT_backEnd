<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_3c087e4c4dd49a13df30318564d8c09e87018cc11af4c729104b76d79d5c0528 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3a6db8a4e4fff91971af2847740cd01c08683e27c7c54cd40a398f6c1c043585 = $this->env->getExtension("native_profiler");
        $__internal_3a6db8a4e4fff91971af2847740cd01c08683e27c7c54cd40a398f6c1c043585->enter($__internal_3a6db8a4e4fff91971af2847740cd01c08683e27c7c54cd40a398f6c1c043585_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_3a6db8a4e4fff91971af2847740cd01c08683e27c7c54cd40a398f6c1c043585->leave($__internal_3a6db8a4e4fff91971af2847740cd01c08683e27c7c54cd40a398f6c1c043585_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
