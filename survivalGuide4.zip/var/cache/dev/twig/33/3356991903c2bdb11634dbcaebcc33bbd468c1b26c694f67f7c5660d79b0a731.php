<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_e4b3aaf407f92c7b08cbc25af8d48cdd77f68a2a157d637b0c6633449ff47b73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_30e0e039582e09384be9273f9c18e9ef25caa35c06d198b5c5b7baa96daf9274 = $this->env->getExtension("native_profiler");
        $__internal_30e0e039582e09384be9273f9c18e9ef25caa35c06d198b5c5b7baa96daf9274->enter($__internal_30e0e039582e09384be9273f9c18e9ef25caa35c06d198b5c5b7baa96daf9274_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_30e0e039582e09384be9273f9c18e9ef25caa35c06d198b5c5b7baa96daf9274->leave($__internal_30e0e039582e09384be9273f9c18e9ef25caa35c06d198b5c5b7baa96daf9274_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_0ac267372a96bc26b4109b19bce8fa2e05f84473ad428abd561373b78e4ea283 = $this->env->getExtension("native_profiler");
        $__internal_0ac267372a96bc26b4109b19bce8fa2e05f84473ad428abd561373b78e4ea283->enter($__internal_0ac267372a96bc26b4109b19bce8fa2e05f84473ad428abd561373b78e4ea283_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_0ac267372a96bc26b4109b19bce8fa2e05f84473ad428abd561373b78e4ea283->leave($__internal_0ac267372a96bc26b4109b19bce8fa2e05f84473ad428abd561373b78e4ea283_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_32bb39d2e64bc069285438618f7d778ce3d0cdedf258925596da71fe14294d27 = $this->env->getExtension("native_profiler");
        $__internal_32bb39d2e64bc069285438618f7d778ce3d0cdedf258925596da71fe14294d27->enter($__internal_32bb39d2e64bc069285438618f7d778ce3d0cdedf258925596da71fe14294d27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_32bb39d2e64bc069285438618f7d778ce3d0cdedf258925596da71fe14294d27->leave($__internal_32bb39d2e64bc069285438618f7d778ce3d0cdedf258925596da71fe14294d27_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_97f6b2d53cee12140ea81c634c209ff5d5e77a13bedf45d5cdf9bc7bcffd6a44 = $this->env->getExtension("native_profiler");
        $__internal_97f6b2d53cee12140ea81c634c209ff5d5e77a13bedf45d5cdf9bc7bcffd6a44->enter($__internal_97f6b2d53cee12140ea81c634c209ff5d5e77a13bedf45d5cdf9bc7bcffd6a44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_97f6b2d53cee12140ea81c634c209ff5d5e77a13bedf45d5cdf9bc7bcffd6a44->leave($__internal_97f6b2d53cee12140ea81c634c209ff5d5e77a13bedf45d5cdf9bc7bcffd6a44_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
