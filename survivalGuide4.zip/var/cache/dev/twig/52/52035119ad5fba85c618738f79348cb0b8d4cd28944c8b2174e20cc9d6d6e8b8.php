<?php

/* FOSUserBundle:Registration:checkEmail.html.twig */
class __TwigTemplate_253c1459f8c4a7d1c5f56a7e1c11180d188e41b20e419772d984a117c3af87fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4a018b3152cd838e60c4de46e8fe8b73dbed05d324ba9879b8876f87015266af = $this->env->getExtension("native_profiler");
        $__internal_4a018b3152cd838e60c4de46e8fe8b73dbed05d324ba9879b8876f87015266af->enter($__internal_4a018b3152cd838e60c4de46e8fe8b73dbed05d324ba9879b8876f87015266af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4a018b3152cd838e60c4de46e8fe8b73dbed05d324ba9879b8876f87015266af->leave($__internal_4a018b3152cd838e60c4de46e8fe8b73dbed05d324ba9879b8876f87015266af_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_0d51c6cc7854551fa9914e01695e38c7f3f859935286582ad905169b8fc124fa = $this->env->getExtension("native_profiler");
        $__internal_0d51c6cc7854551fa9914e01695e38c7f3f859935286582ad905169b8fc124fa->enter($__internal_0d51c6cc7854551fa9914e01695e38c7f3f859935286582ad905169b8fc124fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_0d51c6cc7854551fa9914e01695e38c7f3f859935286582ad905169b8fc124fa->leave($__internal_0d51c6cc7854551fa9914e01695e38c7f3f859935286582ad905169b8fc124fa_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/*     <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
