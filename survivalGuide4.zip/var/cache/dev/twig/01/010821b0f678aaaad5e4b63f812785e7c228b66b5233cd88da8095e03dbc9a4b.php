<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_fd5e63096fa431f7c5d839c8a9b9a27dc171cef9f789c294e3855d1c0c9e9f69 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c59568cb17d97e4292c55ce2bbbf8c6234b33b0b9000e9a3b3d6cc945b2572be = $this->env->getExtension("native_profiler");
        $__internal_c59568cb17d97e4292c55ce2bbbf8c6234b33b0b9000e9a3b3d6cc945b2572be->enter($__internal_c59568cb17d97e4292c55ce2bbbf8c6234b33b0b9000e9a3b3d6cc945b2572be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_c59568cb17d97e4292c55ce2bbbf8c6234b33b0b9000e9a3b3d6cc945b2572be->leave($__internal_c59568cb17d97e4292c55ce2bbbf8c6234b33b0b9000e9a3b3d6cc945b2572be_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
