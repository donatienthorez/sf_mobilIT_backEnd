<?php

/* FOSUserBundle:ChangePassword:changePassword.html.twig */
class __TwigTemplate_c6b0f1157c4b550f55ebae78fbd3b83fbc08e76a65e60ca82ea427a269df3063 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9dd8210da4b20e98f008260080f740588ae80e78fccdd0d181c2836ffc0918be = $this->env->getExtension("native_profiler");
        $__internal_9dd8210da4b20e98f008260080f740588ae80e78fccdd0d181c2836ffc0918be->enter($__internal_9dd8210da4b20e98f008260080f740588ae80e78fccdd0d181c2836ffc0918be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:changePassword.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9dd8210da4b20e98f008260080f740588ae80e78fccdd0d181c2836ffc0918be->leave($__internal_9dd8210da4b20e98f008260080f740588ae80e78fccdd0d181c2836ffc0918be_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a6a2734f09c739b548a1004c7c738646797c781cf415bce648f60a7d804e3600 = $this->env->getExtension("native_profiler");
        $__internal_a6a2734f09c739b548a1004c7c738646797c781cf415bce648f60a7d804e3600->enter($__internal_a6a2734f09c739b548a1004c7c738646797c781cf415bce648f60a7d804e3600_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:changePassword_content.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 4)->display($context);
        
        $__internal_a6a2734f09c739b548a1004c7c738646797c781cf415bce648f60a7d804e3600->leave($__internal_a6a2734f09c739b548a1004c7c738646797c781cf415bce648f60a7d804e3600_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:changePassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:ChangePassword:changePassword_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
