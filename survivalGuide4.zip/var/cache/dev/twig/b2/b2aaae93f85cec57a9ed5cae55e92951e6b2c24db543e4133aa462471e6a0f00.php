<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_cd523995c96b26dbe576438095beb0de745de03d7f53b7a892590289fe8fd018 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c7c950dfbdfa381c641783aae7d6886f1237faf893da87bbf95bde1a92a4208 = $this->env->getExtension("native_profiler");
        $__internal_9c7c950dfbdfa381c641783aae7d6886f1237faf893da87bbf95bde1a92a4208->enter($__internal_9c7c950dfbdfa381c641783aae7d6886f1237faf893da87bbf95bde1a92a4208_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_9c7c950dfbdfa381c641783aae7d6886f1237faf893da87bbf95bde1a92a4208->leave($__internal_9c7c950dfbdfa381c641783aae7d6886f1237faf893da87bbf95bde1a92a4208_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
