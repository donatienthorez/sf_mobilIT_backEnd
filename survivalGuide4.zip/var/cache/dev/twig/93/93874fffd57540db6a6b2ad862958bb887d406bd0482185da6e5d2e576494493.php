<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_a181fdf6b09a17da7f5c9bf18c5c5a3af6cbee4210a1060d27191c2141a00ae2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e66ad148d952fefb6f3c8489227de57d16c9d9770feb1ca951f89cf1c8067e9 = $this->env->getExtension("native_profiler");
        $__internal_2e66ad148d952fefb6f3c8489227de57d16c9d9770feb1ca951f89cf1c8067e9->enter($__internal_2e66ad148d952fefb6f3c8489227de57d16c9d9770feb1ca951f89cf1c8067e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_2e66ad148d952fefb6f3c8489227de57d16c9d9770feb1ca951f89cf1c8067e9->leave($__internal_2e66ad148d952fefb6f3c8489227de57d16c9d9770feb1ca951f89cf1c8067e9_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
