<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_b4e9878c795ffcf130fa932b42a41d3f2e9b0cfed5ddd1f3bc5d6b0bfbc82a61 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2dd6ebaac03346b31d944bd66b61ee9050c9b84ab4c644f85369f8cb33d3312f = $this->env->getExtension("native_profiler");
        $__internal_2dd6ebaac03346b31d944bd66b61ee9050c9b84ab4c644f85369f8cb33d3312f->enter($__internal_2dd6ebaac03346b31d944bd66b61ee9050c9b84ab4c644f85369f8cb33d3312f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_2dd6ebaac03346b31d944bd66b61ee9050c9b84ab4c644f85369f8cb33d3312f->leave($__internal_2dd6ebaac03346b31d944bd66b61ee9050c9b84ab4c644f85369f8cb33d3312f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
