<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_c68bf6fb8b779b1bdaf5f8ed3439402d845a40120b7fa36a6a91b80e44b1eb5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f2dc3405ba2d036e74d9a73efaa139dedc4474cc5b924134f6abe2921bf837fa = $this->env->getExtension("native_profiler");
        $__internal_f2dc3405ba2d036e74d9a73efaa139dedc4474cc5b924134f6abe2921bf837fa->enter($__internal_f2dc3405ba2d036e74d9a73efaa139dedc4474cc5b924134f6abe2921bf837fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_f2dc3405ba2d036e74d9a73efaa139dedc4474cc5b924134f6abe2921bf837fa->leave($__internal_f2dc3405ba2d036e74d9a73efaa139dedc4474cc5b924134f6abe2921bf837fa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
