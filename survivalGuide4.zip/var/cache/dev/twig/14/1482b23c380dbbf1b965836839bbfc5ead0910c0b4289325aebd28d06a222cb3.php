<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_8e88ff60d3fa5faf7692c6630b2e0de99a7f3a1372e6074025075f42717da2d4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c22128bfa68d341f91664d3f479d5e857fe747118bd4ad71b25ebeda61c9c578 = $this->env->getExtension("native_profiler");
        $__internal_c22128bfa68d341f91664d3f479d5e857fe747118bd4ad71b25ebeda61c9c578->enter($__internal_c22128bfa68d341f91664d3f479d5e857fe747118bd4ad71b25ebeda61c9c578_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_c22128bfa68d341f91664d3f479d5e857fe747118bd4ad71b25ebeda61c9c578->leave($__internal_c22128bfa68d341f91664d3f479d5e857fe747118bd4ad71b25ebeda61c9c578_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
