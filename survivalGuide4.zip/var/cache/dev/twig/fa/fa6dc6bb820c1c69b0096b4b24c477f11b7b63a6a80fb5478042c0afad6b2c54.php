<?php

/* MainBundle::subnavbar.html.twig */
class __TwigTemplate_8de61fa05dc462227ba650e04c1322d6c2ec6a10495c048302ca4d84c8970fc4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b5c7237bd2140fc27f7ed532ceb62b60ea026cfc63a53c28478b6a11c2d47a7e = $this->env->getExtension("native_profiler");
        $__internal_b5c7237bd2140fc27f7ed532ceb62b60ea026cfc63a53c28478b6a11c2d47a7e->enter($__internal_b5c7237bd2140fc27f7ed532ceb62b60ea026cfc63a53c28478b6a11c2d47a7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MainBundle::subnavbar.html.twig"));

        // line 1
        echo "<div class=\"subnavbar\">
    <div class=\"subnavbar-inner\">
        <div class=\"container\">
            <ul class=\"mainnav\">
                <li class=\"";
        // line 5
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "esn_guide")) {
            echo "active";
        }
        echo "\">
                    <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("esn_guide");
        echo "\">
                        <i class=\"icon-list-alt\"></i>
                        <span>";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.guide"), "html", null, true);
        echo "</span>
                    </a>
                </li>
                <li class=\"";
        // line 11
        if (($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "attributes", array()), "get", array(0 => "_route"), "method") == "esn_notifications")) {
            echo "active";
        }
        echo "\">
                    <a href=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("esn_notifications");
        echo "\">
                        <i class=\"icon-exclamation-sign\"></i>
                        <span>";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("menu.notifications"), "html", null, true);
        echo "</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>";
        
        $__internal_b5c7237bd2140fc27f7ed532ceb62b60ea026cfc63a53c28478b6a11c2d47a7e->leave($__internal_b5c7237bd2140fc27f7ed532ceb62b60ea026cfc63a53c28478b6a11c2d47a7e_prof);

    }

    public function getTemplateName()
    {
        return "MainBundle::subnavbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 14,  51 => 12,  45 => 11,  39 => 8,  34 => 6,  28 => 5,  22 => 1,);
    }
}
/* <div class="subnavbar">*/
/*     <div class="subnavbar-inner">*/
/*         <div class="container">*/
/*             <ul class="mainnav">*/
/*                 <li class="{% if app.request.attributes.get('_route') == 'esn_guide' %}active{% endif %}">*/
/*                     <a href="{{ path('esn_guide') }}">*/
/*                         <i class="icon-list-alt"></i>*/
/*                         <span>{{ 'menu.guide' | trans }}</span>*/
/*                     </a>*/
/*                 </li>*/
/*                 <li class="{% if app.request.attributes.get('_route') == 'esn_notifications' %}active{% endif %}">*/
/*                     <a href="{{ path('esn_notifications') }}">*/
/*                         <i class="icon-exclamation-sign"></i>*/
/*                         <span>{{ 'menu.notifications' | trans }}</span>*/
/*                     </a>*/
/*                 </li>*/
/*             </ul>*/
/*         </div>*/
/*     </div>*/
/* </div>*/
