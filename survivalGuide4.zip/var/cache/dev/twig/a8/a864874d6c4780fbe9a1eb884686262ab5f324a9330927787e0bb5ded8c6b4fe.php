<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_1888027003dd94835a5f04aa224c67f1dba5d327712497fc64f4f2ced18cbdb1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b445d10c9d51bdb3eacd7128fe4071046b5df5411fb8269089c4bb1a9e32d692 = $this->env->getExtension("native_profiler");
        $__internal_b445d10c9d51bdb3eacd7128fe4071046b5df5411fb8269089c4bb1a9e32d692->enter($__internal_b445d10c9d51bdb3eacd7128fe4071046b5df5411fb8269089c4bb1a9e32d692_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b445d10c9d51bdb3eacd7128fe4071046b5df5411fb8269089c4bb1a9e32d692->leave($__internal_b445d10c9d51bdb3eacd7128fe4071046b5df5411fb8269089c4bb1a9e32d692_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_915dc93bddc9b63cf50de53cb8c6422ee908a20d0eeea2574a712bc6ba6e6bc0 = $this->env->getExtension("native_profiler");
        $__internal_915dc93bddc9b63cf50de53cb8c6422ee908a20d0eeea2574a712bc6ba6e6bc0->enter($__internal_915dc93bddc9b63cf50de53cb8c6422ee908a20d0eeea2574a712bc6ba6e6bc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_915dc93bddc9b63cf50de53cb8c6422ee908a20d0eeea2574a712bc6ba6e6bc0->leave($__internal_915dc93bddc9b63cf50de53cb8c6422ee908a20d0eeea2574a712bc6ba6e6bc0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:request_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
