<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_d1a523f20b4f2fc966b41df74311ea6bcd754830541e17863d88a17812d65ee0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c886b74f0f12e86ef1832b4fa3da12debf49275907cbdb46da376c35e4ed2933 = $this->env->getExtension("native_profiler");
        $__internal_c886b74f0f12e86ef1832b4fa3da12debf49275907cbdb46da376c35e4ed2933->enter($__internal_c886b74f0f12e86ef1832b4fa3da12debf49275907cbdb46da376c35e4ed2933_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_c886b74f0f12e86ef1832b4fa3da12debf49275907cbdb46da376c35e4ed2933->leave($__internal_c886b74f0f12e86ef1832b4fa3da12debf49275907cbdb46da376c35e4ed2933_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
