<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_de150d6fdde96d4289c5ba9af8983b9921ea162db3ee5b5e0743ebc6ef88c855 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ddcad9fa31c18153a44203ae16614a2e245665e755a3e12251faaeb1fe691239 = $this->env->getExtension("native_profiler");
        $__internal_ddcad9fa31c18153a44203ae16614a2e245665e755a3e12251faaeb1fe691239->enter($__internal_ddcad9fa31c18153a44203ae16614a2e245665e755a3e12251faaeb1fe691239_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_ddcad9fa31c18153a44203ae16614a2e245665e755a3e12251faaeb1fe691239->leave($__internal_ddcad9fa31c18153a44203ae16614a2e245665e755a3e12251faaeb1fe691239_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
