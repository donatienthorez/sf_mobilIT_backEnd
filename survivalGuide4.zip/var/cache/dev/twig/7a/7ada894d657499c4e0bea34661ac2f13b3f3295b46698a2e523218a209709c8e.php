<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_375e4510f10f553f3219a5555bb03350dee4008cd900393be0e9ab37055ea9e7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ad8ae569905a9ddf33852a12140a2062c3a121ec2a609e203478ff36cc9c4fcb = $this->env->getExtension("native_profiler");
        $__internal_ad8ae569905a9ddf33852a12140a2062c3a121ec2a609e203478ff36cc9c4fcb->enter($__internal_ad8ae569905a9ddf33852a12140a2062c3a121ec2a609e203478ff36cc9c4fcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_ad8ae569905a9ddf33852a12140a2062c3a121ec2a609e203478ff36cc9c4fcb->leave($__internal_ad8ae569905a9ddf33852a12140a2062c3a121ec2a609e203478ff36cc9c4fcb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
