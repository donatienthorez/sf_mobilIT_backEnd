<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_73d7b82cca68d64999d7c455581d2a253b843851a7538956f4db5e628b4a92da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6437ea5ca6da3f31f41a0154edde7fc6d71140e2e4654f51427cb4c13dca6b5f = $this->env->getExtension("native_profiler");
        $__internal_6437ea5ca6da3f31f41a0154edde7fc6d71140e2e4654f51427cb4c13dca6b5f->enter($__internal_6437ea5ca6da3f31f41a0154edde7fc6d71140e2e4654f51427cb4c13dca6b5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6437ea5ca6da3f31f41a0154edde7fc6d71140e2e4654f51427cb4c13dca6b5f->leave($__internal_6437ea5ca6da3f31f41a0154edde7fc6d71140e2e4654f51427cb4c13dca6b5f_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_31a27329068bdd1e0daa5d1c0db8557e8f6f95f313e2612350d9483729efaf67 = $this->env->getExtension("native_profiler");
        $__internal_31a27329068bdd1e0daa5d1c0db8557e8f6f95f313e2612350d9483729efaf67->enter($__internal_31a27329068bdd1e0daa5d1c0db8557e8f6f95f313e2612350d9483729efaf67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_31a27329068bdd1e0daa5d1c0db8557e8f6f95f313e2612350d9483729efaf67->leave($__internal_31a27329068bdd1e0daa5d1c0db8557e8f6f95f313e2612350d9483729efaf67_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
