<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_57e22418020f80218e84e748f64b3605908369d423d458e1ca19559f2def60e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fdb9710f6d7739527176cc76e07930a9c918c3670b5ca70ca3cf57a3949af4e7 = $this->env->getExtension("native_profiler");
        $__internal_fdb9710f6d7739527176cc76e07930a9c918c3670b5ca70ca3cf57a3949af4e7->enter($__internal_fdb9710f6d7739527176cc76e07930a9c918c3670b5ca70ca3cf57a3949af4e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_fdb9710f6d7739527176cc76e07930a9c918c3670b5ca70ca3cf57a3949af4e7->leave($__internal_fdb9710f6d7739527176cc76e07930a9c918c3670b5ca70ca3cf57a3949af4e7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
