<?php

// WebProfilerBundle:Profiler:info.html.twig
return array (
);
