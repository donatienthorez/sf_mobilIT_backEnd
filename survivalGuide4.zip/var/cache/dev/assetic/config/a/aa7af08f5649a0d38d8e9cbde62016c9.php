<?php

// FOSUserBundle:Registration:checkEmail.html.twig
return array (
);
